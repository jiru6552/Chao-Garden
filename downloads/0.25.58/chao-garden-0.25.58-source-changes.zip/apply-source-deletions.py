#!/usr/bin/env python3
"""Apply explicit source deletions; never touches Minecraft saves."""
from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser(description=__doc__);p.add_argument('project_root',type=Path);p.add_argument('--verify-only',action='store_true');a=p.parse_args();root=a.project_root.resolve()
assert (root/'gradle.properties').is_file() and (root/'src/main').is_dir(),'Use the full source root'
d=json.loads(Path(__file__).with_name('SOURCE_MANIFEST.json').read_text());pending=[]
for name in d['deleted_files']:
 rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts;path=root/rel
 assert not path.is_symlink() and root in path.resolve().parents
 if not path.exists():continue
 assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() in d['deleted_file_previous_sha256'][name],'Locally changed source; review deletion: '+name
 pending.append(path)
for path in pending:
 print(('Would remove ' if a.verify_only else 'Removing ')+str(path.relative_to(root)))
 if not a.verify_only:path.unlink()
print('Verified' if a.verify_only else 'Applied',len(pending),'source deletions')
