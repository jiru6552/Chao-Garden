#!/usr/bin/env python3
"""Prepare isolated .82 baby alignment client argfiles/instructions. Never launches Java or Gradle.

Root must first finish normal prepareClientRun with the intended optional runtime
and freeze compiled classes/resources. Invoke with a fresh private output folder.
The excluded BabyAlignmentVisualSmoke082 helper must be compiled before root launches these commands.
"""
from pathlib import Path
import argparse,hashlib,json,uuid,zipfile

ROOT=Path('/workspace/Chao-Garden')
JDK=Path('/workspace/.tools/jdk-21.0.9+10/bin/java')
P=ROOT/'build/moddev'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def q(text):return '"'+str(text).replace('\\','\\\\').replace('"','\\"')+'"'
def offline_uuid(name):return str(uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+name).encode()).digest(),version=3))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--display',default=':97')
    parser.add_argument('--port',type=int,default=25584)
    parser.add_argument('--reuse-host-game-dir',type=Path)
    parser.add_argument('--reopen-world',default='')
    parser.add_argument('--reopen-expectations',type=Path)
    parser.add_argument('--resolved-classpath',type=Path,required=True,
                        help='Fresh resolved native client JavaExec classpath metadata from root-owned preparation')
    args=parser.parse_args();out=args.output.resolve()
    assert not args.reopen_world and not args.reuse_host_game_dir and not args.reopen_expectations,'Baby082 helper has no reopen mode; native tests cover reconnect separately'
    assert str(out).startswith('/workspace/.setup/') and not out.exists(),'Use a fresh private output folder'
    assert JDK.is_file() and 1024<=args.port<=65535
    vm=P/'clientRunVmArgs.txt';program=P/'clientRunProgramArgs.txt';classpath=P/'clientLegacyClasspath.txt'
    assert all(p.is_file() for p in [vm,program,classpath])
    resolved=args.resolved_classpath.resolve();launch_metadata=json.loads(resolved.read_text())
    actual_java=Path(launch_metadata.get('javaExecutable',str(JDK))).resolve()
    assert actual_java.is_file(),'Resolved launch Java executable must exist'
    actual_classpath=[Path(p) for p in launch_metadata['classpath']]
    assert actual_classpath and all(p.exists() for p in actual_classpath),'Resolved JavaExec classpath entries must exist'
    def contains_server(path):
        if path.is_dir():return (path/'net/minecraft/server/MinecraftServer.class').is_file()
        if not zipfile.is_zipfile(path):return False
        with zipfile.ZipFile(path) as jar:return 'net/minecraft/server/MinecraftServer.class' in jar.namelist()
    assert any(contains_server(p) for p in actual_classpath),'Exact resolved classpath must include the native MinecraftServer class'
    assert 'cpw.mods.bootstraplauncher.BootstrapLauncher' in program.read_text()
    modroots=[ROOT/'build/classes/java/main',ROOT/'build/resources/main']
    assert all(p.is_dir() for p in modroots)
    if args.reopen_world:
        assert args.reuse_host_game_dir and args.reopen_expectations and args.reopen_expectations.is_file()
        assert (args.reuse_host_game_dir/'saves'/args.reopen_world).is_dir(), 'Actual prior test save must exist'
    args_program=program.read_text().splitlines();assert '--gameDir' in args_program
    out.mkdir();shared=out/'shared';shared.mkdir()
    manifest={'scope':'Prepared-only root client launch arguments; no process/test/client result inferred.',
              'prepared_java':str(actual_java),'port':args.port,'display':args.display,
              'inputs':{str(p):sha(p) for p in [vm,program,classpath,resolved]},
              'resolved_javaexec_classpath':[str(p) for p in actual_classpath],
              'mod_source_mapping':'Source-inspected ModDevGradle2.0.148 ModFoldersProvider: mod%%absolute-folder joined with platform path separator.',
              'clients':[]}
    roles=[('host','Baby82Host',0)] if args.reopen_world else [('host','Baby82Host',0),('observer','Baby82Observer',960)]
    for role,name,x in roles:
        home=out/role;home.mkdir()
        gamehome=args.reuse_host_game_dir.resolve() if role=='host' and args.reuse_host_game_dir else home
        # ModDev's ModFoldersProvider is a dynamic JavaExec argument provider,
        # so its -D flag is not contained in the generated VM argfile itself.
        v=vm.read_text().rstrip('\n')+'\n'
        dynamic=launch_metadata.get('dynamicJvmArguments',[])
        if not any(arg.startswith('-Dfml.modFolders=') for arg in dynamic):
            dynamic.append('-Dfml.modFolders='+':'.join('chao_garden%%'+str(p) for p in modroots))
        v+='\n'.join(q(arg) for arg in dynamic)+'\n'
        # This JavaExec classpath is additional to generated LegacyClasspath;
        # the latter omits merged Minecraft/NeoForge and optional runtime jars.
        v+='-cp\n'+q(':'.join(str(p) for p in actual_classpath))+'\n'
        v+='-Xmx2G\n-XX:ActiveProcessorCount=3\n'
        v+='-Dchao_garden.toy02527=\n'
        vp=home/'vm.args';vp.write_text(v)
        a=args_program.copy();a[a.index('--gameDir')+1]=q(gamehome)
        a+=['--username',name,'--uuid',offline_uuid(name),'--accessToken','0','--width','960','--height','666']
        ap=home/'program.args';ap.write_text('\n'.join(a)+'\n')
        # Explicitly disable the stage1-3 helper in a two-client run.
        env={'DISPLAY':args.display,'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2','ALSOFT_DRIVERS':'null',
             'CHAO_TOYS080_SMOKE':'false','CHAO_FLOAT080_SMOKE':'false','CHAO_TOYS080_REMOTE_ROLE':'',
             'CHAO_GARDEN081_ROLE':'','CHAO_BABY082_ROLE':role,'CHAO_BABY082_SHARED':str(shared),'CHAO_BABY082_PORT':str(args.port),
             'CHAO_GARDEN081_REOPEN_WORLD':'','CHAO_GARDEN081_REOPEN_EXPECTATIONS':''}
        manifest['clients'].append({'role':role,'profile':name,'offline_uuid':offline_uuid(name),'cwd':str(gamehome),'argfile_directory':str(home),
             'command':[str(actual_java),'@'+str(vp),'@'+str(ap)],'environment':env,
             'suggested_window_position':[x,0],'vm_args_sha256':sha(vp),'program_args_sha256':sha(ap)})
    (out/'launch-plan.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'result':'PREPARED_ONLY','output':str(out),'clients':len(roles),'processes_launched':0}))

if __name__=='__main__':main()
