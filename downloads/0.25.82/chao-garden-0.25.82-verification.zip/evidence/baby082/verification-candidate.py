#!/usr/bin/env python3
"""Prepare a private .82 evidence inventory from an explicit collection plan.

Never creates an archive, runs a test/build, edits public sources or infers a test
pass from process exit. Use a fresh --output after each final evidence change.
"""
from __future__ import annotations
import argparse,importlib.util,json,re
from pathlib import Path
PRIVATE=Path('/workspace/.setup/baby082')
PREP=PRIVATE/'verification-prep'
spec=importlib.util.spec_from_file_location('baby082_evidence_checks',PRIVATE/'package-verification.py')
pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)

def meta(path):
    b=pack.read_payload(str(path));return {'source':str(path),'bytes':len(b),'sha256':pack.sha(b)}
def private_output(path):
    pack.nonsymlink(path);pack.require(path.parent.resolve().is_relative_to(PRIVATE.resolve()),'Candidate output must remain in private baby082 folder')
def write_derived(label,content):
    raw=content.encode() if isinstance(content,str) else content
    path=PREP/(pack.sha(raw)[:16]+'-'+label);private_output(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():pack.require(path.read_bytes()==raw,'Derived evidence name collision')
    else:path.write_bytes(raw)
    return path

def excerpt_log(source):
    raw=pack.read_payload(str(source));lines=raw.decode('utf-8',errors='replace').splitlines()
    pattern=re.compile(r'tests (?:are now running|are now done|complete|failed|passed)|required tests|GAME TESTS COMPLETE|failed at|BUILD (?:SUCCESSFUL|FAILED)|\bException\b|\bERROR\b',re.I)
    selected=set(range(min(50,len(lines))))|set(range(max(0,len(lines)-200),len(lines)))
    important=[n for n,line in enumerate(lines) if pattern.search(line)]
    for n in important[:140]+important[-140:]:selected.update(range(max(0,n-1),min(len(lines),n+2)))
    text=f'# BOUNDED EXCERPT, not the full original log\n# Original: {source}\n# Original bytes: {len(raw)}\n# Original SHA256: {pack.sha(raw)}\n# Original lines: {len(lines)}\n'
    retained=[]
    for n in sorted(selected):
        line=f'{n+1}: {lines[n][:2200]}\n'
        if len(text.encode())+len(line.encode())>500_000:break
        text+=line;retained.append(n+1)
    p=write_derived(source.name+'.excerpt.txt',text)
    return p,{'original_source':str(source),'original_bytes':len(raw),'original_sha256':pack.sha(raw),'original_lines':len(lines),'retained_line_numbers':retained,'scope':'Bounded selected-line excerpt; full original omitted from ZIP.'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',type=Path,default=PRIVATE/'verification-plan.json');p.add_argument('--output',type=Path,default=PRIVATE/'verification-candidate.json');a=p.parse_args()
    plan_path=a.plan.absolute();pack.nonsymlink(plan_path);plan_raw=pack.read_payload(str(plan_path));plan=json.loads(plan_raw)
    pack.require(plan.get('version')=='0.25.82','Wrong collection-plan version')
    output=a.output.absolute();private_output(output);pack.require(not output.exists(),'Preserve earlier candidates: use a fresh --output')
    payloads={};missing=[];errors=[];omitted=[]
    def add(path,kind,entry=None,required=False,extra=None):
        path=Path(path).absolute()
        if not path.is_file():
            if required:missing.append(str(path))
            return
        if entry is None:
            pack.require(path.is_relative_to(pack.SETUP),'Implicit archive names require .setup input')
            entry='evidence/'+str(path.relative_to(pack.SETUP))
        pack.canonical_entry(entry);item={**meta(path),'kind':kind}
        if extra:item.update(extra)
        pack.require(entry not in payloads or payloads[entry]['sha256']==item['sha256'],f'Conflicting evidence entry: {entry}')
        payloads[entry]=item
    if plan.get('awaiting_final_plan',False):missing.append('ROOT_FINAL_COLLECTION_PLAN_REQUIRED')
    for name in plan.get('required_inputs',[]):
        path=Path(name).absolute();pack.nonsymlink(path)
        if not path.is_file():missing.append(str(path))
    add(plan_path,'explicit collection plan; not a runtime result','evidence/COLLECTION_PLAN.json',required=True)
    for item in plan.get('includes',[]):add(item['source'],item.get('kind','explicit selected evidence'),item.get('entry'),item.get('required',False))
    for tree in plan.get('trees',[]):
        root=Path(tree['source']).absolute();pack.nonsymlink(root)
        pack.require(root.is_relative_to(pack.SETUP),'Evidence tree must remain in .setup')
        if not root.is_dir():
            if tree.get('required'):missing.append(str(root))
            continue
        pattern=tree.get('pattern','*.json');paths=root.rglob(pattern) if tree.get('recursive',False) else root.glob(pattern)
        prefix=tree.get('entry_prefix','evidence/'+str(root.relative_to(pack.SETUP))).rstrip('/')
        for path in sorted(paths):
            if path.is_file():add(path,tree.get('kind','recorded structured capture; inspect its own completeness'),prefix+'/'+str(path.relative_to(root)))
    for item in plan.get('logs',[]):
        if isinstance(item,str):item={'source':item}
        source=Path(item['source']).absolute()
        if not source.is_file():
            if item.get('required'):missing.append(str(source))
            continue
        if source.stat().st_size>plan.get('full_log_byte_limit',2_000_000):
            excerpt,original=excerpt_log(source);omitted.append(original)
            add(excerpt,'bounded numbered original-log excerpt',item.get('entry','logs/excerpts/'+excerpt.name),extra=original)
        else:add(source,'complete selected process log',item.get('entry','logs/'+source.name))
    attempts=[]
    for root_spec in plan.get('receipt_roots',[]):
        if isinstance(root_spec,str):root_spec={'source':root_spec}
        root=Path(root_spec['source']).absolute();pack.nonsymlink(root);pack.require(root.is_relative_to(pack.SETUP),'Receipt root must remain in .setup')
        pattern=root_spec.get('pattern','*-receipt.started.json');paths=root.rglob(pattern) if root_spec.get('recursive',False) else root.glob(pattern)
        for started in sorted(paths):
            if not started.is_file():continue
            initial=json.loads(pack.read_payload(str(started)));final=started.with_name(started.name.removesuffix('.started.json')+'.json')
            final_data=json.loads(pack.read_payload(str(final))) if final.is_file() else None
            status='NO_FINAL_EXIT_RECEIPT' if final_data is None else 'EXITED_ZERO' if final_data.get('exit_code')==0 else 'EXITED_NONZERO'
            record={'name':initial.get('name',started.stem),'started_receipt':meta(started),'final_receipt':meta(final) if final_data is not None else None,'process_status':status,'exit_code':None if final_data is None else final_data.get('exit_code'),'scope':'Process state only; no native/harness/visual/multiplayer PASS inferred.'}
            add(started,'actual process-start receipt')
            if final_data is not None:add(final,'actual process-exit receipt; not a test/harness verdict')
            log=Path((final_data or initial).get('log','')).absolute()
            if log.is_file() and log.is_relative_to(pack.SETUP):
                record['log']=meta(log);record['log']['full_log_included']=any(m['source']==str(log) for m in payloads.values())
                if final_data is not None and final_data.get('log_sha256') and final_data['log_sha256']!=record['log']['sha256']:errors.append(f'Final receipt/log SHA mismatch: {final}')
            attempts.append(record)
    attempt_file=write_derived('INCOMPLETE_ATTEMPTS.json',(json.dumps({'version':'0.25.82','scope':'Actual process and omitted-log inventory; failed attempts remain visible.','attempts':attempts},indent=2,sort_keys=True)+'\n').encode())
    add(attempt_file,'process history, including incomplete/failed attempts','evidence/INCOMPLETE_ATTEMPTS.json')
    add(pack.REPORT,'final development report','development-report.md',required=True)
    readme=write_derived('VERIFICATION_README.md','''# Chao Garden 0.25.82 development verification

The root-reviewed manifest and development report define actual outcomes and limitations. Process exit, native GameTest results, capture hashes, actual image inspection and multiplayer observations remain separate scopes. A zero process exit alone does not prove that a client cohort or a test passed. Failed/partial attempts are preserved in INCOMPLETE_ATTEMPTS.json; their selected full logs or bounded excerpts are identified by bytes and SHA256.

The collection plan explicitly selects payloads and required completion inputs. It does not execute tests or infer visual approval. Structured frame records may refer to original PNGs that are retained in the workspace but omitted from this archive; the manifest and plan identify selected actual-image sheets or originals. Runtime installation, saved test worlds, account caches and unselected files are not part of this bundle. Public-server latency or hardware/touch verification must not be inferred from native fixtures or a local development client.
''')
    add(readme,'evidence interpretation and omissions','VERIFICATION_README.md')
    result={'version':'0.25.82','candidate_only':True,'reviewer':None,'coordinator_reviewed':False,'final_review_complete':False,'review_notes':'','plan_sha256':pack.sha(plan_raw),'missing_required_inputs':sorted(set(missing)),'candidate_errors':errors,'canonical_evidence':plan.get('canonical_evidence',{}),'historical_assessments':plan.get('historical_assessments',{}),'final_assessments':{},'limitations':plan.get('limitations',[]),'omissions':{'large_full_logs':omitted,'unselected_files':'Only exact explicitly collected payloads are included; original worlds/runtimes/account data are omitted.'},'payloads':payloads,'counts':{'payloads':len(payloads),'payload_bytes':sum(m['bytes'] for m in payloads.values()),'attempts':len(attempts)},'next_step':'Root finishes tests/report, updates explicit plan with required final receipts and actual image sheets, regenerates fresh candidate, reviews exact hashes and assessments, then writes verification-allowlist.json with explicit root final seal. No ZIP was created.'}
    output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'candidate':str(output),'counts':result['counts'],'missing_required_inputs':result['missing_required_inputs'],'candidate_errors':errors}))
if __name__=='__main__':main()
