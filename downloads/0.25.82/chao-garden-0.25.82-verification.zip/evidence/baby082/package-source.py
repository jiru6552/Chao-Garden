#!/usr/bin/env python3
"""Root-reviewed cumulative .82 source overlay. No build, Git mutation or publication.

Private coordinator helper. This script only packages when /root has finalized
its allowlist/report and explicitly invokes --reviewed-by-root. --check-only
performs the same source validation without creating an archive or inventory.
"""
from __future__ import annotations
from pathlib import Path
import argparse, importlib.util, json, re, shutil, tempfile, zipfile

PRIVATE = Path('/workspace/.setup/baby082')
ROOT = Path('/workspace/Chao-Garden')
OUT = Path('/workspace/artifacts/chao-garden-0.25.82')
PARENT = Path('/workspace/.setup/garden081/source-inventory-final01.json')
PARENT_SHA = '579f76feee0d660d384511475418ebbfb85778ea414a038b2aaa1f0c357e0c69'
ZIP = Path('/workspace/artifacts/chao-garden-0.25.81/chao-garden-0.25.81-source-changes.zip')
ZIP_SHA = '200f6d178bcceba4610e2a24a7aa9be01b560f8344b2aa2033d996fc607539ce'
BASE = 'fcde2f9d012499b2e2cb1ec1d50a7f58d4dc3ca2'
ALLOW = PRIVATE / 'source-allowlist.json'
REPORT = 'docs/EQUIPPED_BABY_ALIGNMENT_02582_DEV.md'
INVENTORY = PRIVATE / 'source-inventory-final01.json'
DESTINATION = OUT / 'chao-garden-0.25.82-source-changes.zip'
CONTROLS = {'SOURCE_MANIFEST.json', 'SOURCE_DELETIONS.txt', 'apply-source-deletions.py', 'SOURCE_CHANGES.txt'}
SOURCE_DIRECTORIES = ('src', 'docs', 'scripts', 'art', 'gradle')
spec = importlib.util.spec_from_file_location('accepted_source_checks082', PRIVATE / 'source_checks.py')
safe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(safe)
sha, require = safe.sha, safe.require


def accepted_parent():
    """Validate exact accepted source lineage, payloads and all deletion guards."""
    for path in (ROOT, PARENT, ZIP): safe.nonsymlink(path)
    require(ROOT.is_dir() and not ROOT.is_symlink(), 'ROOT must be the real source directory')
    parent_raw = PARENT.read_bytes()
    require(sha(parent_raw) == PARENT_SHA, 'Accepted .81 inventory pin mismatch')
    require(sha(ZIP.read_bytes()) == ZIP_SHA, 'Accepted .81 source ZIP pin mismatch')
    parent = json.loads(parent_raw)
    require(parent['version'] == '0.25.81' and parent['base'] == '0.25.43'
            and parent['base_commit'] == BASE and parent['coordinator_reviewed'] is True
            and parent['reviewer'] == '/root', 'Accepted .81 lineage/review mismatch')
    require(len(parent['files']) == 996, 'Accepted .81 must retain all 996 sources')
    deleted, guards = parent['deleted_files'], parent['deleted_file_previous_sha256']
    require(len(deleted) == len(set(deleted)) == 21 and set(deleted) == set(guards)
            and not (set(parent['files']) & set(deleted)), 'Inherited 21 deletion guards are incomplete')
    for name in set(parent['files']) | set(deleted):
        safe.check_name(name)
    for name, values in guards.items():
        require(isinstance(values, list) and values and len(values) == len(set(values))
                and all(re.fullmatch(r'[0-9a-f]{64}', value) for value in values),
                f'Invalid inherited exact deletion guards: {name}')
    with zipfile.ZipFile(ZIP) as archive:
        require(archive.read('SOURCE_MANIFEST.json') == parent_raw, 'Accepted .81 ZIP/manifest mismatch')
        inherited = {name: archive.read(name) for name in CONTROLS}
    safe.verify_archive(ZIP, parent['files'], inherited)
    return parent, inherited


def source_catalog():
    """Read-only Git/rg inventory; never stages, checks out, deletes or rewrites."""
    tracked = safe.nul_paths(['git', 'diff', '--no-ext-diff', '--name-only', '--no-renames', '-z', BASE, '--'])
    basefiles = safe.nul_paths(['git', 'ls-tree', '-r', '--name-only', '-z', BASE])
    directories = [name for name in SOURCE_DIRECTORIES if (ROOT / name).is_dir()]
    candidates = safe.nul_paths(['rg', '--files', '--hidden', '-0', '-g', '!**/__pycache__/**',
                                '-g', '!**/.gradle/**', '-g', '!**/build/**', '--', *directories])
    candidates |= {path.name for path in ROOT.iterdir() if path.is_file() or path.is_symlink()}
    return tracked, basefiles, candidates


def prepare():
    parent, inherited = accepted_parent()
    safe.nonsymlink(ALLOW)
    allow_raw = ALLOW.read_bytes()
    scope = json.loads(allow_raw)
    require(scope['reviewer'] == '/root' and scope['version'] == '0.25.82'
            and scope.get('coordinator_reviewed') is True and scope.get('final_review_complete') is True,
            'Final source review by /root required')
    require(isinstance(scope.get('review_notes'), str) and bool(scope['review_notes'].strip()), 'Root review notes required')
    modified_list, added_list = scope['modified_parent_files'], scope['added_overlay_files']
    require(isinstance(modified_list, list) and isinstance(added_list, list), 'Scope paths must be lists')
    modified, added = set(modified_list), set(added_list)
    require(len(modified) == len(modified_list) and len(added) == len(added_list), 'Duplicate paths in reviewed scope')
    require(modified <= parent['files'].keys() and not (added & parent['files'].keys()), 'Bad scope partition')
    names = set(parent['files']) | added
    require(REPORT in names and not (names & CONTROLS), 'Missing development report or source/control overlap')
    require(len({name.casefold() for name in names | CONTROLS}) == len(names) + len(CONTROLS), 'Case-colliding source/control paths')
    raw = {name: safe.read_source(name) for name in sorted(names)}
    files = {name: sha(content) for name, content in raw.items()}
    require(scope.get('reviewed_files') == files, 'Source bytes differ from the final root-reviewed file hashes; regenerate candidate and review')
    changed = {name for name, digest in parent['files'].items() if files[name] != digest}
    require(changed == modified, f'Unexpected parent modifications: {sorted(changed ^ modified)}')
    require(not re.search(r'TODO_FINAL_|AWAITING_FINAL|\b(?:TODO|TBD)\b', raw[REPORT].decode('utf-8'), re.I), 'Finalize development report before packaging')
    deleted, guards = parent['deleted_files'], parent['deleted_file_previous_sha256']
    for name in deleted:
        require(not (ROOT / name).exists() and not (ROOT / name).is_symlink(), f'Deleted source resource reappeared: {name}')
    tracked, basefiles, candidates = source_catalog()
    require(tracked <= names | set(deleted), f'Unaccounted tracked source changes: {sorted(tracked - names - set(deleted))}')
    require(candidates <= basefiles | names, f'Unaccounted new source paths: {sorted(candidates - basefiles - names)}')
    require(added <= candidates | tracked, f'Reviewed additions absent from source catalog: {sorted(added - candidates - tracked)}')
    manifest = {
        'version': '0.25.82', 'base': '0.25.43', 'base_commit': BASE, 'parent_version': '0.25.81',
        'coordinator_reviewed': True, 'reviewer': '/root', 'review_notes': scope['review_notes'],
        'pins': {'accepted_081_inventory_sha256': PARENT_SHA, 'accepted_081_source_zip_sha256': ZIP_SHA,
                 'reviewed_scope_sha256': sha(allow_raw),
                 'source_checks_sha256': sha((PRIVATE / 'source_checks.py').read_bytes()),
                 'packager_sha256': sha(Path(__file__).read_bytes())},
        'files': files, 'deleted_files': deleted, 'deleted_file_previous_sha256': guards,
        'modified_parent_files': sorted(modified), 'added_overlay_files': sorted(added), 'update_files': sorted(modified | added),
        'parent_preservation': {'source_paths': len(parent['files']), 'unchanged_paths': len(parent['files']) - len(modified),
                                'modified_paths': len(modified), 'added_overlay_paths': len(added),
                                'new_files': len(added - basefiles), 'newly_overlaid_base_paths': len(added & basefiles)},
    }
    mbytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    controls = {
        'SOURCE_MANIFEST.json': mbytes,
        'SOURCE_DELETIONS.txt': inherited['SOURCE_DELETIONS.txt'],
        'apply-source-deletions.py': inherited['apply-source-deletions.py'],
        'SOURCE_CHANGES.txt': (
            f'Cumulative Chao Garden 0.25.82 source overlay onto complete 0.25.43 source at {BASE}.\n'
            f'{len(files)} source paths plus four controls; retains all {len(parent["files"])} accepted .81 paths.\n'
            f'See {REPORT} for development verification and limitations.\n'
            'Read SOURCE_MANIFEST.json and apply-source-deletions.py --help for the 21 inherited exact source-resource deletion guards. Existing worlds are not scanned.\n'
        ).encode(),
    }
    return manifest, mbytes, raw, files, controls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reviewed-by-root', action='store_true', help='Coordinator source-review seal; not a build or runtime verification claim')
    parser.add_argument('--check-only', action='store_true', help='Validate reviewed source catalog without creating output files')
    args = parser.parse_args()
    require(args.reviewed_by_root, 'Final source review by /root required')
    manifest, mbytes, raw, files, controls = prepare()
    if args.check_only:
        print(json.dumps({'checked_only': True, 'sources': len(files), 'entries': len(files) + 4,
                          'parent_preservation': manifest['parent_preservation'], 'deletion_guards': 21}))
        return
    for path in (OUT, DESTINATION, INVENTORY): safe.nonsymlink(path)
    require(not OUT.is_symlink(), 'Output directory is a symlink')
    require(not DESTINATION.exists() and not DESTINATION.is_symlink()
            and not INVENTORY.exists() and not INVENTORY.is_symlink(), 'Preserve existing completed outputs')
    OUT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='baby082-source-', dir=PRIVATE) as temp:
        staged = Path(temp) / DESTINATION.name
        with zipfile.ZipFile(staged, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, content in list(raw.items()) + sorted(controls.items()):
                entry = zipfile.ZipInfo(name, (2026, 11, 15, 0, 0, 0))
                entry.create_system = 3
                entry.external_attr = (0o100755 if name == 'apply-source-deletions.py' else 0o100644) << 16
                archive.writestr(entry, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        safe.verify_archive(staged, files, controls)
        require(all(sha(safe.read_source(name)) == digest for name, digest in files.items()), 'Sources changed during packaging')
        with DESTINATION.open('xb') as out, staged.open('rb') as source:
            shutil.copyfileobj(source, out)
    with INVENTORY.open('xb') as out:
        out.write(mbytes)
    print(json.dumps({'source_zip': str(DESTINATION), 'inventory': str(INVENTORY), 'sha256': sha(DESTINATION.read_bytes()),
                      'bytes': DESTINATION.stat().st_size, 'sources': len(files), 'entries': len(files) + 4,
                      'parent_preservation': manifest['parent_preservation']}))


if __name__ == '__main__':
    main()
