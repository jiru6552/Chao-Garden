#!/usr/bin/env python3
"""Independently extract completed Baby082 native results. Never runs Java or tests."""
from pathlib import Path
import argparse
import hashlib
import json
import re

BASELINE = Path('/workspace/.setup/garden081/full-native02-independent.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def namespaces(receipt):
    return set(next((a.split('=', 1)[1] for a in receipt.get('command', [])
                     if a.startswith('-PchaoGameTestNamespaces=')), '').split(','))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--log', type=Path, required=True)
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--expected-total', type=int, required=True)
    p.add_argument('--full', action='store_true')
    a = p.parse_args()
    assert not a.output.exists(), 'Preserve earlier audit artifacts'
    r = json.loads(a.receipt.read_text())
    lines = a.log.read_text(errors='replace').splitlines()
    assert r['log_sha256'] == sha(a.log), 'Actual process log hash differs'
    failures = {}
    totals = []
    reported_failures = []
    core = []
    for number, line in enumerate(lines, 1):
        m = re.search(r'LogTestReporter\]: (\S+) failed at (.*?)! (.*)$', line)
        if m:
            failures.setdefault(m[1], []).append({'line': number, 'position': m[2], 'reason': m[3]})
        m = re.search(r'=+ (\d+) GAME TESTS COMPLETE', line)
        if m:
            totals.append(int(m[1]))
        m = re.search(r'GameTestServer\]: (\d+) required tests failed', line)
        if m:
            reported_failures.append(int(m[1]))
        if re.search(r'(?:[Cc]hecks|[Tt]ests) passed|Equipped baby alignment082:', line):
            core.append({'line': number, 'text': line})
    assert totals, 'No completed native summary'
    total = totals[-1]
    assert total == a.expected_total, f'Unexpected selected test count {total}'
    assert (reported_failures[-1] if reported_failures else 0) == len(failures), 'Summary/failure names differ'
    assert r['exit_code'] == (1 if failures else 0), 'Actual process exit contradicts native summary'
    comparison = None
    if a.full:
        b = json.loads(BASELINE.read_text())
        old = b['current_081']['failures']
        previous_receipt = json.loads(Path(b['current_081']['receipt']).read_text())
        assert namespaces(previous_receipt) <= namespaces(r), 'Full run omits prior accepted namespaces'
        unchanged = sorted(n for n in failures.keys() & old.keys()
                           if {x['reason'] for x in failures[n]} == {x['reason'] for x in old[n]})
        comparison = {
            'baseline_path': str(BASELINE), 'baseline_sha256': sha(BASELINE),
            'all_baseline_namespaces_selected': True,
            'new_failure_names': sorted(failures.keys() - old.keys()),
            'inherited_unchanged_failure_names': unchanged,
            'inherited_changed_reason_failure_names': sorted(failures.keys() & old.keys() - set(unchanged)),
            'absent_baseline_failures_not_claimed_fixed': sorted(old.keys() - failures.keys()),
        }
    result = {
        'scope': 'Independent immutable process/native-result extraction; no launch, client visual judgment or optional-mod presence inferred.',
        'status': 'COMPLETE_CONSISTENT', 'tests_passed': not failures,
        'total': total, 'passed': total - len(failures), 'failure_count': len(failures),
        'failures': failures, 'process_exit_code': r['exit_code'],
        'receipt': str(a.receipt), 'receipt_sha256': sha(a.receipt),
        'log': str(a.log), 'log_sha256': sha(a.log), 'core_report_lines': core,
        'namespaces_selected': sorted(namespaces(r)), 'comparison': comparison,
        'limitations': ['A completed extraction is not a passing test suite when failures are present.',
                        'Real optional Aether installation and dimension loading require their own runtime/dependency proof.',
                        'Embedded native connections are distinct from actual TCP client and process-restart verification.'],
    }
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'tests_passed', 'total', 'passed', 'failure_count', 'failures', 'comparison')}))


if __name__ == '__main__':
    main()
