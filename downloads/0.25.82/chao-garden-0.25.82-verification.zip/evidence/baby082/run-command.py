#!/usr/bin/env python3
"""Keep an actual subprocess exit receipt even if the chat session loses its handle."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--name', required=True)
p.add_argument('--cwd', type=Path, default=Path('/workspace/Chao-Garden'))
p.add_argument('--log', type=Path, required=True)
p.add_argument('--receipt', type=Path, required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
assert command and a.cwd.is_dir()
started = a.receipt.with_name(a.receipt.stem + '.started.json')
assert not any(x.exists() for x in [a.log, a.receipt, started]), 'Preserve prior attempts; use fresh paths'
for x in [a.log, a.receipt]:
    x.parent.mkdir(parents=True, exist_ok=True)
begin = time.time()
with a.log.open('x') as output:
    child = subprocess.Popen(command, cwd=a.cwd, stdout=output, stderr=subprocess.STDOUT)
    record = {
        'version': next(line.split('=',1)[1].strip() for line in Path('/workspace/Chao-Garden/gradle.properties').read_text().splitlines() if line.startswith('mod_version=')), 'task_version': '0.25.82', 'scope': 'Actual equipped baby alignment subprocess launch/exit; visual and multiplayer results require their own evidence.',
        'name': a.name, 'runner_pid': os.getpid(), 'child_pid': child.pid,
        'cwd': str(a.cwd), 'command': command, 'started_epoch_millis': int(begin * 1000),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'log': str(a.log.resolve()),
        'capture_environment': {k: v for k, v in os.environ.items() if k.startswith('CHAO_') or k in {'DISPLAY', 'LIBGL_ALWAYS_SOFTWARE', 'ALSOFT_DRIVERS', 'LP_NUM_THREADS'}},
    }
    started.write_text(json.dumps(record, indent=2) + '\n')
    print('START', a.name, 'child', child.pid, flush=True)
    result = child.wait()
record.update({
    'exit_code': result, 'ended_epoch_millis': int(time.time() * 1000),
    'elapsed_seconds': time.time() - begin,
    'log_sha256': hashlib.sha256(a.log.read_bytes()).hexdigest(),
})
with a.receipt.open('x') as output:
    output.write(json.dumps(record, indent=2) + '\n')
print('COMPLETE', a.name, 'exit', result, 'receipt', a.receipt, flush=True)
sys.exit(result)
