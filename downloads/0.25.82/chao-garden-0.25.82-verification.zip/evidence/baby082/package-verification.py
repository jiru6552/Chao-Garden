#!/usr/bin/env python3
"""Root-sealed .82 development evidence bundle. Never runs tests/builds or publishes.

Uses the exact reviewed payload hashes from verification-allowlist.json. Outcomes
must be assessed explicitly by /root: process exit, capture hash and a harness
label are different evidence scopes. Existing outputs are never overwritten.
"""
from __future__ import annotations
import argparse,hashlib,json,shutil,stat,tempfile,zipfile
from pathlib import Path,PurePosixPath

PRIVATE=Path('/workspace/.setup/baby082')
SETUP=Path('/workspace/.setup')
ROOT=Path('/workspace/Chao-Garden')
REPORT=ROOT/'docs/EQUIPPED_BABY_ALIGNMENT_02582_DEV.md'
OUT=Path('/workspace/artifacts/chao-garden-0.25.82')
ALLOW=PRIVATE/'verification-allowlist.json'
DESTINATION=OUT/'chao-garden-0.25.82-verification.zip'
FINAL_MANIFEST=PRIVATE/'verification-manifest-final01.json'
CONTROL='VERIFICATION_MANIFEST.json'
FORBIDDEN={'.git','.aws','.codex','node_modules','saves','world','worlds','playerdata','region','entities','usercache.json','usernamecache.json','servers.dat','accounts','profilekeys','launcher_accounts.json','launcher_profiles.json','tokens.json','credentials'}
FORBIDDEN_SUFFIXES={'.jar','.zip','.7z','.tar','.gz','.class','.mca','.mcr','.nbt','.dat'}

def require(condition,message):
    if not condition:raise RuntimeError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def nonsymlink(path):
    require(path.is_absolute(),'Absolute path required')
    cursor=Path(path.anchor)
    for part in path.parts[1:]:
        cursor/=part;require(not cursor.is_symlink(),f'Symlink in path: {path}')
def canonical_entry(name):
    require(isinstance(name,str) and bool(name),'Empty archive path')
    p=PurePosixPath(name)
    require(not p.is_absolute() and str(p)==name and '..' not in p.parts and '\\' not in name and ':' not in name and '\x00' not in name,f'Unsafe archive path: {name!r}')
    require(not any(part.casefold() in FORBIDDEN for part in p.parts),f'Forbidden archive path: {name}')
    require(p.suffix.casefold() not in FORBIDDEN_SUFFIXES,f'Forbidden binary/runtime/world evidence payload: {name}')
def read_payload(source):
    p=Path(source);nonsymlink(p)
    require(p.is_relative_to(SETUP) or p==REPORT,f'Unapproved evidence root: {p}')
    require(not any(part.casefold() in FORBIDDEN for part in p.parts),f'Forbidden evidence source: {p}')
    require(p.suffix.casefold() not in FORBIDDEN_SUFFIXES,f'Forbidden binary/runtime/world source: {p}')
    require(p.is_file() and p.resolve().is_relative_to(Path('/workspace')),f'Invalid evidence source: {p}')
    return p.read_bytes()
def prepare():
    nonsymlink(ALLOW);scope_raw=ALLOW.read_bytes();scope=json.loads(scope_raw)
    require(scope.get('version')=='0.25.82' and scope.get('reviewer')=='/root' and scope.get('coordinator_reviewed') is True and scope.get('final_review_complete') is True,'Final root evidence review seal required')
    require(isinstance(scope.get('review_notes'),str) and bool(scope['review_notes'].strip()),'Root review notes required')
    require(not scope.get('missing_required_inputs'),'Required evidence inputs remain missing')
    require(not scope.get('candidate_errors'),'Candidate has unresolved receipt/hash errors')
    require(isinstance(scope.get('final_assessments'),dict) and scope['final_assessments'],'Explicit root final assessments required; process success is not an assessment')
    payloads=scope.get('payloads');require(isinstance(payloads,dict) and payloads,'Empty payload map')
    require(CONTROL not in payloads and len({n.casefold() for n in set(payloads)|{CONTROL}})==len(payloads)+1,'Control overlap or case-colliding evidence paths')
    raw={}
    for name,meta in sorted(payloads.items()):
        canonical_entry(name);content=read_payload(meta['source'])
        require(meta['bytes']==len(content) and meta['sha256']==sha(content),f'Payload changed after root review: {name}')
        raw[name]=content
    require('evidence/INCOMPLETE_ATTEMPTS.json' in raw and 'VERIFICATION_README.md' in raw and 'development-report.md' in raw,'Attempt inventory, explanation and final report required')
    import re
    require(not re.search(r'TODO_FINAL_|AWAITING_FINAL|\b(?:TODO|TBD)\b',raw['development-report.md'].decode('utf-8'),re.I),'Finalize the development report before evidence packaging')
    manifest={'version':'0.25.82','kind':'development verification bundle','reviewer':'/root','coordinator_reviewed':True,
              'review_notes':scope['review_notes'],'reviewed_allowlist_sha256':sha(scope_raw),
              'canonical_evidence':scope.get('canonical_evidence',{}),'historical_assessments':scope.get('historical_assessments',{}),
              'final_assessments':scope['final_assessments'],'limitations':scope.get('limitations',[]),
              'files':payloads,'payload_count':len(payloads),'payload_bytes':sum(map(len,raw.values())),
              'omissions':scope.get('omissions',{}),'plan_sha256':scope.get('plan_sha256')}
    return manifest,(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode(),raw

def verify_archive(path,expected):
    with zipfile.ZipFile(path) as z:
        names=z.namelist();require(len(names)==len(set(names))==len(expected) and set(names)==set(expected),'Wrong or duplicate verification entries')
        require(z.testzip() is None,'Verification ZIP CRC failure')
        for e in z.infolist():
            canonical_entry(e.filename);require(not e.is_dir() and not(e.flag_bits&1) and not stat.S_ISLNK(e.external_attr>>16),f'Invalid ZIP entry: {e.filename}')
            require(z.read(e.filename)==expected[e.filename],f'ZIP payload mismatch: {e.filename}')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reviewed-by-root',action='store_true');p.add_argument('--check-only',action='store_true');a=p.parse_args()
    require(a.reviewed_by_root,'Final review by /root required');m,mb,raw=prepare()
    if a.check_only:
        print(json.dumps({'checked_only':True,'payloads':len(raw),'payload_bytes':m['payload_bytes']}));return
    nonsymlink(OUT);nonsymlink(FINAL_MANIFEST)
    require(not DESTINATION.exists() and not DESTINATION.is_symlink() and not FINAL_MANIFEST.exists() and not FINAL_MANIFEST.is_symlink(),'Preserve completed evidence outputs')
    OUT.mkdir(parents=True,exist_ok=True);expected={**raw,CONTROL:mb}
    with tempfile.TemporaryDirectory(prefix='verification-',dir=PRIVATE) as temp:
        staged=Path(temp)/DESTINATION.name
        with zipfile.ZipFile(staged,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for name,content in sorted(expected.items()):
                e=zipfile.ZipInfo(name,(2026,11,15,0,0,0));e.create_system=3;e.external_attr=0o100644<<16
                z.writestr(e,content,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        verify_archive(staged,expected)
        require(all(sha(read_payload(meta['source']))==meta['sha256'] for meta in m['files'].values()),'Evidence changed during packaging')
        with DESTINATION.open('xb') as out,staged.open('rb') as src:shutil.copyfileobj(src,out)
    with FINAL_MANIFEST.open('xb') as out:out.write(mb)
    print(json.dumps({'verification_zip':str(DESTINATION),'bytes':DESTINATION.stat().st_size,'sha256':sha(DESTINATION.read_bytes()),'entries':len(expected),'manifest':str(FINAL_MANIFEST)}))
if __name__=='__main__':main()
