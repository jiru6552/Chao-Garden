#!/usr/bin/env python3
"""Read-only actual loader/version and optional Aether provenance audit."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

OPTIONAL = Path('/workspace/.setup/baby082-aether')
RUNTIME = Path('/workspace/.setup/dark071-optional-runtime')


def digest(path, algorithm='sha256'):
    return hashlib.new(algorithm, path.read_bytes()).hexdigest()


def fileproof(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('--native-audit', type=Path, required=True)
    p.add_argument('--mode', choices=['present', 'absent'], required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--generated-fixture', type=Path, default=Path('/workspace/Chao-Garden/build/resources/gameTestDimensions/data/minecraft/worldgen/world_preset/flat.json'))
    a = p.parse_args()
    assert not a.output.exists(), 'Keep earlier runtime proofs immutable'
    r = json.loads(a.receipt.read_text())
    n = json.loads(a.native_audit.read_text())
    log = Path(r['log'])
    assert digest(log) == r['log_sha256'] == n['log_sha256']
    assert n['status'] == 'COMPLETE_CONSISTENT' and n['total'] == 14
    assert r['exit_code'] == (0 if n['tests_passed'] else 1)
    lines = log.read_text(errors='replace').splitlines()
    sections = []
    for i, line in enumerate(lines):
        if line.strip() != 'Mod List:':
            continue
        mods = {}
        rows = []
        for j in range(i + 1, len(lines)):
            value = lines[j]
            if not value.strip() or value.strip() == 'Name Version (Mod Id)':
                continue
            m = re.fullmatch(r'\s+(.+) (\S+) \(([^()]+)\)', value)
            if not m:
                break
            assert m[3] not in mods, 'Duplicate resolved mod id'
            mods[m[3]] = {'name': m[1], 'version': m[2]}
            rows.append({'line': j + 1, 'text': value})
        if mods:
            sections.append({'header_line': i + 1, 'mods': mods, 'actual_log_rows': rows})
    assert sections, 'No actual resolved loader Mod List'
    selected = sections[-1]
    mods = selected['mods']
    for key, version in {'chao_garden': '0.25.82', 'minecraft': '1.21.1',
                         'neoforge': '21.1.219', 'accessories': '1.1.0-beta.54+1.21.1',
                         'owo': '0.12.15.6-beta.1+1.21'}.items():
        assert mods.get(key, {}).get('version') == version, f'Actual selected {key} version differs'
    command = r['command']
    inits = [Path(command[i + 1]) for i, value in enumerate(command[:-1]) if value == '-I']
    init = OPTIONAL / 'with-aether02.init.gradle'
    aether = OPTIONAL / 'aether-1.21.1-1.5.10-neoforge.jar'
    external = [RUNTIME / 'accessories-neoforge-1.1.0-beta.54+1.21.1.jar',
                RUNTIME / 'owo-lib-neoforge-0.12.15.6-beta.1+1.21.jar']
    assert all(path.is_file() for path in external)
    optional_proof = None
    if a.mode == 'absent':
        assert 'aether' not in mods, 'Aether actually loaded in absence control'
        assert not any(path.parent == OPTIONAL for path in inits), 'Absence control invoked optional init'
    else:
        assert mods.get('aether', {}).get('version') == '1.5.10'
        assert mods.get('cumulus_menus', {}).get('version') == '2.0.7'
        assert mods.get('nitrogen_internals', {}).get('version') == '1.1.25'
        assert init in inits
        prepared = OPTIONAL / 'PREPARED_RUNTIME02_MANIFEST.json'
        assert digest(init) == json.loads(prepared.read_text())['sha256']
        metadata = json.loads((OPTIONAL / 'modrinth-aether-version.json').read_text())
        download = json.loads((OPTIONAL / 'DOWNLOAD_MANIFEST.json').read_text())
        assert digest(aether) == download['sha256']
        publisher = next(x for x in metadata['files'] if x['filename'] == aether.name)
        for algorithm in ('sha512', 'sha1'):
            assert digest(aether, algorithm) == publisher['hashes'][algorithm]
        with zipfile.ZipFile(aether) as jar:
            embedded = json.loads(jar.read('META-INF/jarjar/metadata.json'))
            official_dimension = json.loads(jar.read('data/aether/dimension/the_aether.json'))
            bad = jar.testzip()
        assert bad is None
        embedded_accessories = next(x['version']['artifactVersion'] for x in embedded['jars']
                                    if x['identifier']['artifact'] == 'accessories-neoforge')
        assert embedded_accessories == '1.1.0-beta.48+1.21.1'
        assert embedded_accessories != mods['accessories']['version']
        flat = a.generated_fixture
        fixture = json.loads(flat.read_text())
        base = Path('/workspace/Chao-Garden/src/gameTestDimensions/resources/data/minecraft/worldgen/world_preset/flat.json')
        base_dimensions = json.loads(base.read_text())['dimensions']
        assert len(base_dimensions) == 8
        assert fixture['dimensions'].keys() == base_dimensions.keys() | {'aether:the_aether'}
        assert all(fixture['dimensions'][key] == value for key, value in base_dimensions.items())
        assert fixture['dimensions']['aether:the_aether'] == official_dimension
        snapshot = a.output.with_suffix('.generated-flat.json')
        assert not snapshot.exists()
        snapshot.write_bytes(flat.read_bytes())
        optional_proof = {
            'official_jar': fileproof(aether), 'publisher_sha512_and_sha1_match': True,
            'zip_crc_check': 'PASS', 'init_used': fileproof(init),
            'publisher_metadata': fileproof(OPTIONAL / 'modrinth-aether-version.json'),
            'download_manifest': fileproof(OPTIONAL / 'DOWNLOAD_MANIFEST.json'),
            'prepared_manifest': fileproof(prepared),
            'official_dimension_definition_matches_actual_development_fixture': True,
            'all_eight_original_development_dimensions_unchanged': True,
            'base_development_fixture': fileproof(base),
            'development_flat_fixture': fileproof(flat),
            'immutable_generated_fixture_snapshot': fileproof(snapshot),
            'embedded_dependency_metadata': embedded,
            'embedded_accessories_version': embedded_accessories,
            'selected_accessories_version': mods['accessories']['version'],
            'embedded_accessories_is_not_the_selected_version': True,
        }
    result = {
        'scope': 'Actual complete native test process, resolved loader Mod List, exact dependency versions and file provenance; not flags-only detection.',
        'status': 'PASS', 'aether_mode': a.mode, 'actual_resolved_loader': selected,
        'status_applies_only_to_runtime_provenance': True,
        'native_test_outcome': {'total': n['total'], 'passed': n['passed'],
                                'tests_passed': n['tests_passed'], 'failures': n['failures'],
                                'process_exit_code': r['exit_code']},
        'receipt': fileproof(a.receipt), 'native_audit': fileproof(a.native_audit),
        'actual_log': fileproof(log), 'actual_command': command,
        'external_runtime_files': [fileproof(path) for path in external],
        'optional_proof': optional_proof,
        'runtime_exercise': ('Selected14 native cases executed with real loaded Aether; successful applicable conditional cases require the real Aether level and registered hostile/passive/ambiguous entities. Native failures remain explicit above.' if a.mode == 'present' else 'Selected14 native cases executed without loaded Aether; absent-mod conditional selects real vanilla End. Native failures remain explicit above.'),
        'limitations': ['This is a native dedicated development GameTest process with embedded player connections, not an actual client visual check.',
                        'Third-party runtime JARs are private test dependencies and must not be bundled in the mod delivery.'],
    }
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'aether_mode': a.mode,
                      'loaded_mods': mods, 'output': str(a.output), 'sha256': digest(a.output)}))


if __name__ == '__main__':
    main()
