#!/usr/bin/env python3
"""Read-only actual Baby082 TCP/client evidence audit. Never launches games.

Checks exact relevant replicated fields and production native-render receipts;
full care-state strings are retained but may legitimately continue to advance.
Root's screenshot judgment remains a separate scope.
"""
from pathlib import Path
import argparse,hashlib,json,struct

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--shared',type=Path,required=True)
    p.add_argument('--host-receipt',type=Path,required=True)
    p.add_argument('--observer-receipt',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert not a.output.exists(),'Preserve prior audits'
    shared=a.shared.resolve();errors=[];rows=[];receipts=[];uuids={};freezes=set()
    def check(value,message):
        if not value:errors.append(message)
    def near(x,y):
        try:return abs(float(x)-float(y))<.000002
        except (TypeError,ValueError):return False
    check(not list(shared.glob('*failure*.json')),'Actual cohort recorded a failure')
    for role,path in [('host',a.host_receipt),('observer',a.observer_receipt)]:
        check(path.is_file(),f'{role} process exit receipt missing')
        if not path.is_file():continue
        r=read(path);log=Path(r.get('log',''))
        check(r.get('exit_code')==0,f'{role} process exited nonzero')
        check(log.is_file() and digest(log)==r.get('log_sha256'),f'{role} actual log/exit receipt hash mismatch')
        env=r.get('capture_environment',{});check(env.get('CHAO_BABY082_ROLE')==role,f'{role} receipt environment role mismatch')
        freezes.add(env.get('CHAO_BABY082_SOURCE_FREEZE'))
        receipts.append({'role':role,'path':str(path),'sha256':digest(path),'exit_code':r.get('exit_code')})
    snapshots={}
    for stage in range(5):
        sp=shared/f'server-stage-{stage}-snapshot.json';check(sp.is_file(),f'Server stage{stage} absent')
        if not sp.is_file():continue
        server=read(sp);snapshots[stage]=server;freezes.add(server.get('source_freeze'))
        for role in ['host','observer']:
            done=shared/f'{role}-stage-{stage}-done.json';check(done.is_file(),f'{role} stage{stage} completion absent')
            if done.is_file():check(read(done).get('status')=='PASS',f'{role} stage{stage} nonpass')
            frame=shared/f'{role}-stage-{stage}-view.json';check(frame.is_file(),f'{role} stage{stage} frame absent')
            if not frame.is_file():continue
            d=read(frame);proof=d.get('actual_render_proof',{});freezes.add(d.get('source_freeze'))
            uuids.setdefault(role,set()).add(d.get('peer_uuid'))
            for key in ['actor_uuid','adult','first_type','dimension']:
                check(d.get(key)==server.get(key),f'{role} stage{stage} replicated {key} differs')
            for key in ['alignment','locked_alignment']:
                check(near(d.get(key),server.get(key)),f'{role} stage{stage} replicated {key} differs')
            check(d.get('peer_uuid')==server.get('owner_uuid' if role=='host' else 'observer_uuid'),f'{role} stage{stage} actual peer identity differs')
            check(proof.get('actual_production_living_render') is True and proof.get('renderer')=='com.chaogarden.client.ChaoRenderer',f'{role} stage{stage} no production Chao renderer proof')
            check(proof.get('actor_uuid')==server.get('actor_uuid'),f'{role} stage{stage} renderer submitted another actor')
            check(d.get('native_render_frames',0)>=25,f'{role} stage{stage} too few native render frames')
            check(sha_text(d.get('actual_client_state',''))==d.get('actual_client_state_sha256'),f'{role} stage{stage} retained full state hash differs')
            image=Path(d.get('png_path',''));check(image.is_file(),f'Native PNG missing {image}');size=None
            if image.is_file():
                raw=image.read_bytes();check(raw[:8]==b'\x89PNG\r\n\x1a\n',f'Invalid PNG {image}');check(digest(image)==d.get('png_sha256'),f'PNG hash differs {image}');size=list(struct.unpack('>II',raw[16:24]));check(min(size)>=600,f'Native PNG too small {image}')
            rows.append({'role':role,'stage':stage,'actor_uuid':d.get('actor_uuid'),'alignment':d.get('alignment'),'frame':str(frame),'frame_sha256':digest(frame),'png':str(image),'png_sha256':d.get('png_sha256'),'dimensions':size})
    for role in ['host','observer']:
        path=shared/f'{role}-complete.json';check(path.is_file(),f'{role} final completion absent')
        if path.is_file():d=read(path);check(d.get('status')=='PASS',f'{role} final nonpass');freezes.add(d.get('source_freeze'))
    cp=shared/'server-complete.json';check(cp.is_file(),'Server final completion absent');complete=read(cp) if cp.is_file() else {}
    check(complete.get('status')=='PASS','Server final nonpass');freezes.add(complete.get('source_freeze'))
    proofs={d.get('stage'):d for d in complete.get('stages',[])}
    for name in ['accepted_hostile_death_once','accepted_peaceful_death_once','adult_identity_and_mirror_unchanged','actual_passive_hero_dimension']:check(name in proofs,f'Actual server proof absent: {name}')
    if len(snapshots)==5:
        s=snapshots;check(s[0]['actor_uuid']==s[1]['actor_uuid']==s[2]['actor_uuid']==s[0]['baby_uuid'],'Baby identity changed across kill stages')
        check(s[3]['adult'] is True and s[3]['actor_uuid']!=s[0]['actor_uuid'],'Adult negative fixture did not use a separate real identity')
        check(near(s[1]['alignment']-s[0]['alignment'],complete.get('hostile_points',0)/100),'Hostile configured point delta differs')
        check(near(s[1]['alignment']-s[2]['alignment'],complete.get('peaceful_points',0)/100),'Peaceful configured point delta differs')
        check(s[4]['actor_uuid']==s[0]['actor_uuid'] and s[4]['adult'] is False,'Passive phase must restore original baby identity')
        selected='aether:the_aether' if complete.get('aether_loaded') else 'minecraft:the_end'
        check(s[4].get('dimension')==selected==complete.get('passive_hero_dimension'),'Passive source did not match actual optional-mod selection')
        passive=proofs.get('actual_passive_hero_dimension',{})
        check(near(s[4]['alignment'],passive.get('after')),'Passive snapshot differs from the actual production tick result')
        check(passive.get('dimension')==selected and passive.get('actor_uuid')==s[0]['actor_uuid'],'Passive server proof uses wrong dimension or identity')
        check(passive.get('actual_entity_ticking') is True and passive.get('elapsed_server_ticks',0)>=1 and passive.get('last_passive_tick',0)>passive.get('seed_server_tick',0),'Passive body did not receive a real tick after destination readiness')
        check(near(passive.get('after',0)-passive.get('before',0),.01),'Passive server point delta differs')
        seed_path=shared/'passive-hero-seed.json';check(seed_path.is_file(),'Passive readiness/seed receipt missing')
        if seed_path.is_file():
            seed=read(seed_path)
            check(near(passive.get('before'),seed.get('alignment_before')) and passive.get('seed_server_tick')==seed.get('server_tick'),'Passive proof does not begin at the actual readiness seed')
            before_delta=float(seed.get('alignment_before',0))-float(s[2]['alignment'])
            check(before_delta>=-.000002 and near(before_delta,round(before_delta/.01)*.01),'Pre-seed loaded Hero time must remain whole positive alignment points')
            check(seed.get('dimension')==selected and seed.get('baby_uuid')==s[0]['actor_uuid'] and seed.get('hero_ticks_seeded')==1199 and seed.get('actual_entity_ticking') is True,'Passive fixture seeded before actual body/dimension/ticking readiness')
            check(passive.get('paused_age')==seed.get('age_before') and passive.get('paused_adult_age')==seed.get('adult_age_before'),'Passive source changed paused life counters')
        for role in ['host','observer']:
            ack_path=shared/f'{role}-hero-dimension-ready.json';check(ack_path.is_file(),f'Actual {role} destination acknowledgement missing')
            if ack_path.is_file():
                ack=read(ack_path);check(ack.get('actual_dimension')==selected and ack.get('peer_uuid') in uuids.get(role,set()),f'{role} acknowledged wrong Hero destination or identity')

    check(len(uuids.get('host',set()))==len(uuids.get('observer',set()))==1 and not(uuids.get('host',set())&uuids.get('observer',set())),'Distinct consistent TCP peer identities required')
    check(len(freezes)==1 and None not in freezes and 'unrecorded' not in freezes,'One recorded final frozen runtime required')
    check((shared/'world-details.json').is_file(),'Normal actual save identity receipt absent')
    result={'scope':'Actual TCP peer identity/alignment/age-category/first-type replication and production native-render proof, including actual dimension tickets and a seeded1199→1200 passive boundary. Full continuing care-state equality, root image judgment and process restart are separate scopes.','status':'FAIL' if errors else 'PASS','errors':errors,'expected_pngs':10,'actual_recorded_pngs':len(rows),'source_freezes':list(freezes),'peer_uuids':{k:sorted(v) for k,v in uuids.items()},'process_receipts':receipts,'captures':rows,'server_complete_sha256':digest(cp) if cp.is_file() else None}
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['captures','process_receipts']}));raise SystemExit(1 if errors else 0)
def sha_text(value):return hashlib.sha256(value.encode()).hexdigest()
if __name__=='__main__':main()
