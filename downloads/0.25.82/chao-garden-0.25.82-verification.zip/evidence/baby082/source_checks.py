#!/usr/bin/env python3
"""Private .82 source safety primitives. Read-only until explicitly packaging.

Copied and scoped from the accepted source packaging checks; self-contained.
"""
from __future__ import annotations
import hashlib
from pathlib import Path, PurePosixPath
import stat, subprocess, zipfile
ROOT=Path('/workspace/Chao-Garden')
FORBIDDEN_COMPONENTS = {
    '.git', '.gradle', '.setup', '.codex', '.agents', '.aws', '__pycache__',
    'build', 'out', 'target', 'node_modules', 'run', 'runs', 'logs', 'saves',
    'screenshots', 'captures', 'artifacts', 'private', 'privateassets',
    'private_assets', 'private-assets',
}
FORBIDDEN_SUFFIXES = {'.class', '.pyc', '.pyo', '.jar', '.zip', '.7z', '.tar', '.gz', '.log', '.mp4', '.webm'}

def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def check_name(name: str) -> None:
    require(isinstance(name, str) and bool(name), f'Invalid path: {name!r}')
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name and '\\' not in name
            and '\x00' not in name and '..' not in path.parts and ':' not in name,
            f'Noncanonical or unsafe source path: {name!r}')
    require(not any(part.casefold() in FORBIDDEN_COMPONENTS for part in path.parts),
            f'Forbidden source path: {name}')
    require(path.suffix.casefold() not in FORBIDDEN_SUFFIXES,
            f'Forbidden source payload: {name}')


def nonsymlink(path: Path) -> None:
    require(path.is_absolute(), 'Absolute path required')
    cursor = Path(path.anchor)
    for part in path.parts[1:]:
        cursor /= part
        require(not cursor.is_symlink(), f'Symlink in path: {path}')


def read_source(name: str) -> bytes:
    check_name(name)
    path = ROOT
    for part in PurePosixPath(name).parts:
        path /= part
        require(not path.is_symlink(), f'Symlink in source path: {name}')
    require(path.is_file() and path.resolve().is_relative_to(ROOT.resolve()),
            f'Source is missing or is not a regular file under ROOT: {name}')
    return path.read_bytes()


def nul_paths(command: list[str]) -> set[str]:
    raw = subprocess.check_output(command, cwd=ROOT)
    return {entry.decode('utf-8') for entry in raw.split(b'\0') if entry}


def verify_archive(path: Path, sources: dict[str, str], controls: dict[str, bytes]) -> None:
    expected = set(sources) | set(controls)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) == len(expected), 'Duplicate or wrong ZIP entry count')
        require(set(names) == expected, f'Unexpected ZIP entries: {set(names) ^ expected}')
        require(len({name.casefold() for name in names}) == len(names), 'Case-colliding ZIP entries')
        for entry in archive.infolist():
            check_name(entry.filename)
            require(not entry.is_dir() and not (entry.flag_bits & 1), f'Invalid ZIP entry: {entry.filename}')
            require(not stat.S_ISLNK(entry.external_attr >> 16), f'ZIP symlink: {entry.filename}')
        require(archive.testzip() is None, 'ZIP CRC verification failed')
        for name, expected_sha in sources.items():
            require(sha(archive.read(name)) == expected_sha, f'ZIP source hash mismatch: {name}')
        for name, expected_bytes in controls.items():
            require(archive.read(name) == expected_bytes, f'ZIP control bytes differ: {name}')

