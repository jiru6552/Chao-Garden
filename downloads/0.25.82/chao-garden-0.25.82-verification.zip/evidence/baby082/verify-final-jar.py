#!/usr/bin/env python3
"""Read-only delivered-JAR integrity and production/runtime binding audit."""
from pathlib import Path
import argparse,hashlib,json,zipfile
p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,required=True);p.add_argument('--freeze',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert not a.output.exists();sha=lambda b:hashlib.sha256(b).hexdigest();root=Path('/workspace/Chao-Garden');f=json.loads(a.freeze.read_text());files=f['files'];bindings=[];mismatches=[];forbidden=[]
with zipfile.ZipFile(a.jar) as z:
 names=z.namelist();assert len(names)==len(set(names));assert z.testzip() is None
 for n in names:
  if n.startswith('com/chaogarden/test/') or ('com/chaogarden/client/' in n and any(x in n for x in ['VisualSmoke','VisualStudy','CaptureStudy','PoseProbe','VisualProbe'])) or any(n.startswith('data/'+x+'/') for x in ['chao_jack80','chao_float80','chao_bonus80','chao_garden_effect81','chao_unlock81','chao_unlock_fresh81','chao_lobby81','chao_baby_align82']):forbidden.append(n)
  if n.endswith('/') :continue
  candidates=['build/classes/java/main/'+n,'build/resources/main/'+n]
  source=next((c for c in candidates if c in files),None)
  if source:
   actual=sha(z.read(n));current=root/source
   good=actual==files[source] and current.is_file() and sha(current.read_bytes())==actual
   bindings.append({'entry':n,'sha256':actual,'recorded_runtime_path':source,'matches_recorded_runtime_and_final_compiled':good})
   if not good:mismatches.append(n)
 mods=z.read('META-INF/neoforge.mods.toml').decode();assert '0.25.82' in mods and '1.21.1' in mods
 assert 'com/chaogarden/mixin/BabyAlignmentDeathMixin082.class' in names
 assert all('com/chaogarden/mixin/'+n+'.class' in names for n in ['EquippedPlayerAttackMixin080','EquippedHurtKnockbackMixin080','EquippedTrackerMotionMixin080','EquippedMovementValidationMixin080'])
assert not forbidden and not mismatches, (forbidden,mismatches)
r={'scope':'All CRCs/unique entries and recorded development runtime to final production payload binding; not an installed-JAR playthrough.','version':'0.25.82','jar':str(a.jar),'bytes':a.jar.stat().st_size,'sha256':sha(a.jar.read_bytes()),'freeze':str(a.freeze),'freeze_sha256':sha(a.freeze.read_bytes()),'entries':len(names),'runtime_bound_entries':len(bindings),'production_classes':sum(x['entry'].endswith('.class') for x in bindings),'forbidden_entries':forbidden,'mismatches':mismatches,'bindings':bindings,'status':'PASS'}
a.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='bindings'}))
