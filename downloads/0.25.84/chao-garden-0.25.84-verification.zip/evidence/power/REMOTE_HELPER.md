# PowerRemoteVisualSmoke084 — source-only launch contract

No client, Java, Gradle or server was launched by the author. Root must compile the helper, bind fresh classes/resources and the final freeze, create a fresh shared directory and independently audit actual output. Existing `*VisualSmoke*` release exclusions cover the class and nested Case; no public guide/tooltips/registered content are added.

Use the same resolved ordinary client classpath/VM/game arguments as the other .84 actual clients, replacing only each role's fresh game directory, profile/UUID and explicit helper environment. Do not replay an older version's frozen boot arguments or add GameTestDimensions resources.

| Role | Profile | Environment |
|---|---|---|
| host | `Power84Host` | `CHAO_POWER084_ROLE=host` |
| observer | `Power84Observer` | `CHAO_POWER084_ROLE=observer` |

Both roles require the same fresh absolute `CHAO_POWER084_SHARED`, `CHAO_POWER084_PORT` (default25594) and exact `CHAO_POWER084_SOURCE_FREEZE`. Generate matching offline profile UUIDs using the existing launcher convention. The host creates a new `Power084Remote-*` ordinary NORMAL flat world and publishes it. The observer waits for `observer-connect.json` and connects to127.0.0.1. This is **two actual client processes, one integrated local connection and one remote TCP connection**; it is not a dedicated server or two TCP peers.

The host constructs a real1200-block smooth-stone open runway, holds its adjacent z-chunks loaded and waits80actual server ticks after the observer joins, preserving natural login-protection timing. All teleports, health/cooldown/motion resets are labelled preparation. Both actual clients must track the actor/victim, verify state/tier and acknowledge prepared PNG callbacks. Detached cameras are used only for static preparation views; the camera returns to the actual player before movement.

Seven contexts run in order:

1. Current equipped Neutral Power/X99 companion naturally attacks a real Cow at maximum; keeper's accepted pre-hit establishes only the existing Mob target selection. Cow health/cooldown/motion are then reset before both ready snapshots. The actual Chao drive produces the measured hit.
2. The same actual AI path with saved zero tier.
3. Eligible owner's ordinary player attack on Cow, with companion AI disabled, proving player-origin force is not the secret actor.
4. Actual eligible Chao direct MOB_ATTACK dispatch to the real remote player at maximum. This is explicitly a controlled damage fixture, not natural AI PvP: production targeting intentionally accepts Mob only.
5. The same controlled remote-player path with saved zero tier.
6. Remote observer equips Run/X99 with balanced Fly99/Swim99, uses exactly one native keyUp tick on the ground, and supplies actual non-owner movement-handler diagnostics.
7. The remote observer's Creative flying case uses one native keyJump tick, raw flying speed0.05, actual synced1000modifier/1001multiplier and the same server diagnostic. No fake player movement packet is sent by this helper.

Damage events record actual causing/direct entity UUIDs, MOB_ATTACK classification and accepted damage (Chao11; owner1). Boosted server snapshots verify the exact immutable production Impact.vector is armed for the same victim and adds400.4 horizontal impulse after subtracting native prior-half-motion. Read-only reflection records the real ChunkMap tracker; reflection failure is explicit metadata, not invented tracker proof. Native player movement checks and actor/victim positions are recorded each measured tick.

The measurement window is two server ticks. There is no victim position or velocity forcing inside it. Afterward Power fixtures explicitly unequip and stop motion once with a native zero packet, so they are **not** a full natural-flight/settling test. Run revoke only unequips and leaves momentum to normal drag; it does not zero or teleport the player. After the remote client observes multiplier1 it supplies two ordinary native input ticks while recording residual velocity, actual server packet/position/teleport fields and both traces. No acceptance claim is made if vanilla rolls the player back. Both roles record another20server-tick observation interval before advancing.

Clients sample actual UUID-specific entities at client pre/post and render-pre hooks. Private CLIENT_SEEN is read only: its sequence, entity ID, dimension and expiry are acceptance evidence from the production receiver. No sendImpulse, receive, cycle or clearClient method is invoked. Untracked victims remain `tracked=false`, never substituted zero vectors. A400.4 hit can leave ordinary tracking range in one tick despite the loaded runway.

`COMPLETE`/`OBSERVED` are collection statuses, **not test PASS**. Root must audit source/runtime binding, native11damage, exact server400.4, actual client peaks/displacements, tracker/native movement results, rejected rollbacks and revoke. A boosted packet receipt without an active client horizontal sample above3.9 is explicitly `PACKET_ACCEPTED_ACTIVE_MOTION_SAMPLE_MISSING`; never claim that case verified client400.4. Even a larger sampled peak may already include normal decay: state exact observed value, not the server vector. Zero/owner checks reject new sequences while allowing an earlier entry to expire normally.

The helper writes case catalog, shared phase/ready/armed/done files, actual PNG hashes, per-client pre/render/post traces, actual input/release records, server event/impact/tracker/movement traces, explicit post-window intervention and server/client completion. Error files terminate peers; zero process exit alone proves nothing. Original world saves/runtime/dependency/account files stay private and must not enter evidence exports. No audio, touch/manual controls, shaderpack, production-JAR-installed or dedicated-server result is inferred.

Selected follow-up: set `CHAO_POWER084_CASES=2,3,4,5,6` on BOTH roles to run the ordinary-owner control, two controlled companion→remote cases and two remote Run cases. Catalog and completion explicitly list omitted0/1 as NOT_RUN_IN_THIS_SELECTED_COHORT. Pair03 retained camera readiness success but unresolved natural-AI active timeout; that failure is not erased by selecting other contexts. The actual observer footing defect (z4.5 outside oldz±3) is fixed by widening this fresh finite runway toz±8; it alone does not explain the Chao AI stall. Periodic server active-gate JSON now records actual actor/goal/currenttarget/cooldown/state/carry/authority, target age, and real remote packet/teleport/movement diagnostics before any accepted hit, without calling or bypassing AI gates.
