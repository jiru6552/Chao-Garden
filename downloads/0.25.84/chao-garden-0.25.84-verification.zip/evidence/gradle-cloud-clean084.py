#!/usr/bin/env python3
import os, sys, subprocess, urllib.parse
p=urllib.parse.urlsplit(os.environ['HTTPS_PROXY'])
e=os.environ.copy()
e['JAVA_HOME']='/workspace/.tools/jdk-21.0.9+10'
e['PATH']=e['JAVA_HOME']+'/bin:'+e['PATH']
e['GRADLE_USER_HOME']='/workspace/.gradle'
e['JAVA_TOOL_OPTIONS']=e.get('JAVA_TOOL_OPTIONS','')+f' -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Dhttps.proxyHost={p.hostname} -Dhttps.proxyPort={p.port} -Dhttp.proxyHost={p.hostname} -Dhttp.proxyPort={p.port} -Dhttp.nonProxyHosts=localhost|127.*|[::1]'
sys.exit(subprocess.call(['bash','gradlew','--no-daemon','--max-workers=4',*sys.argv[1:]],env=e,cwd='/workspace/.setup/fixes084/clean-project01'))
