"""Prepare two current-runtime Power/Run probe clients; never launch a client."""
from pathlib import Path
import argparse,json,subprocess,sys,hashlib,socket

S=Path('/workspace/.setup/fixes084')
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--resolved-classpath',type=Path,required=True)
p.add_argument('--source-freeze',type=Path,required=True)
p.add_argument('--source-freeze-sha256',required=True)
p.add_argument('--port',type=int,default=25594)
a=p.parse_args();out=a.output.resolve()
assert out.is_relative_to(S) and not out.exists()
assert 1024<=a.port<=65535
with socket.socket() as check:check.bind(('127.0.0.1',a.port))
freeze=json.loads(a.source_freeze.read_text())
assert 'build/classes/java/main/com/chaogarden/client/PowerRemoteVisualSmoke084.class' in freeze['files']
out.mkdir();shared=out/'shared';shared.mkdir()
plans=[]
for role,profile in [('host','Power84Host'),('observer','Power84Observer')]:
    dest=out/role
    command=[sys.executable,str(S/'prepare_client_launch.py'),'--mode','fixes','--output',str(dest),
             '--resolved-classpath',str(a.resolved_classpath),'--source-freeze',str(a.source_freeze),
             '--source-freeze-sha256',a.source_freeze_sha256,'--profile',profile,'--display',':98',
             '--width','960','--height','666']
    subprocess.run(command,check=True)
    path=dest/'launch-plan.json';d=json.loads(path.read_text())
    env={k:v for k,v in d['client']['environment'].items() if not k.startswith('CHAO_')}
    env.update(CHAO_POWER084_ROLE=role,CHAO_POWER084_SHARED=str(shared),
               CHAO_POWER084_PORT=str(a.port),CHAO_POWER084_SOURCE_FREEZE=a.source_freeze_sha256)
    d.update(mode='power_'+role,evidence_directory=str(shared),
             scope='Two actual development client processes: integrated local host and one independent TCP observer; normal dimensions. Preparation only.',
             limits=['Root owns all launches. Process exit/completion is not physical motion or visual acceptance.',
                     'One integrated local host plus one TCP observer; not two TCP connections or a dedicated-server client session.',
                     'Controlled direct Chao attacks on the remote player are labelled fixtures, not natural AI PvP.',
                     'Software GL and null audio; no listening, shaderpack, phone or installed-production-JAR claim.'])
    d['client']['environment']=env
    d['client']['environment_policy']='Strip all inherited CHAO_*; enable only this role/shared/freeze environment.'
    d['power_role']=role;d['power_shared_directory']=str(shared);d['power_port']=a.port
    path.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
    plans.append({'role':role,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
record={'status':'PREPARED_NOT_LAUNCHED','version':'0.25.84','topology':'integrated local host and one independent TCP observer',
        'shared':str(shared),'source_freeze_sha256':a.source_freeze_sha256,'port':a.port,'clients':plans,
        'bootstrap_reuse':'Fresh actual .84 generic launcher; only helper activation/evidence metadata replaced after verifying compiled PowerRemote helper.',
        'processes_launched':0}
(out/'pair-plan.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
