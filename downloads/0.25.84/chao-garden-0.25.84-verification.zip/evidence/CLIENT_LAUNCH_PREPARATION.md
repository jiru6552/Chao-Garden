# Private .84 native client preparation

These scripts were prepared without launching Java, Gradle or a display. They use fresh actual ModDev JavaExec classpath metadata, generated current `build/moddev/clientRun*` files and the final source-freeze pin. No .83 argument snapshot, original world or account cache is copied.

Root first performs ordinary `prepareClientRun` with actual Accessories/owo/Lionfish runtime, dumps fresh resolved runClient metadata and freezes current compiled source/resources. Do not include `runGameTestServer` or its dimension source set in that preparation. `prepare_client_launch.py` refuses missing metadata/freeze, changed frozen bytes, GameTest flat overrides, missing actual dependencies/helpers and existing output folders. All generated-bootstrap arguments are retained; only fresh game/profile/window values change. `-Dfml.modFolders` comes from actual dynamic argument-provider metadata, never a guessed old mapping.

Prepare the two sequential single-client cohorts after their actual .84 helpers compile:

```sh
python3 -B /workspace/.setup/fixes084/prepare_client_launch.py --mode fixes --output /workspace/.setup/fixes084/fixes-client01 --resolved-classpath /workspace/.setup/fixes084/client-classpath01.json --source-freeze /workspace/.setup/fixes084/runtime-freeze01.json --source-freeze-sha256 ROOT_FINAL_PIN
python3 -B /workspace/.setup/fixes084/prepare_client_launch.py --mode run --output /workspace/.setup/fixes084/run-client01 --resolved-classpath /workspace/.setup/fixes084/client-classpath01.json --source-freeze /workspace/.setup/fixes084/runtime-freeze01.json --source-freeze-sha256 ROOT_FINAL_PIN
```

`--display` defaults to root-owned `:98`; both use software GL and null audio. Profiles default to `Fix84View`/`Run84View`. Framebuffer request is 1440×1000; CLI may change it, and a helper may explicitly resize its own window. Output/evidence and game directories are separate new subfolders. Neither cohort claims multiplayer or installed-JAR execution.

Root may then invoke `launch_prepared_client.py --plan .../launch-plan.json --name fixes084-fixes-client01 --log .../fixes-client01.log --receipt .../fixes-client01-receipt.json` (and corresponding run cohort) after starting its display. The adapter re-verifies all input/JAR/frozen bytes, removes every inherited `CHAO_*` variable, sets only the chosen helper's `SMOKE`, `OUTPUT` and `SOURCE_FREEZE`, and delegates to existing root `run-command.py` for actual process receipts. It refuses a game directory with an existing saves folder, preserving failed attempts and old worlds. Do not invoke this launcher merely to prepare a plan.

Input hashes/classpath files/directories, exact dynamic JVM arguments, profile, environment policy and commands are retained in each `launch-plan.json`. A prepared plan is not test success; root must inspect actual helper completions, render/native-input evidence, process result and images. No new active plans were generated while classpath/freeze inputs were absent.
