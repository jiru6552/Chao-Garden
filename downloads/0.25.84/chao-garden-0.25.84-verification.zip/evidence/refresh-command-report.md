# .84 current-appearance refresh command

Source inspection found that Chao do not save an old baked gameplay model per creature. The current renderer selects current assets/features from the existing saved biological/training state every frame. Two persisted presentation overrides can deliberately pin an old official-reference model: `OfficialComparison` and `SourceReferenceRig`. Re-decoding current state alone does not clear those overrides and cannot safely invent missing maturity/first-type history.

## Implemented scope

- `/chao refresh ~` refreshes one unambiguously nearest actual living Chao within the existing spherical12-block range in the source dimension.
- `/chao refresh "My Chao"` uses the existing exact-name selector, case-insensitive over loaded actual Chao in the source dimension. Missing/duplicate names and nearest ties fail without silently selecting another creature. Names are suggested with quotes.
- `/chao refresh held` handles only the actual filled Chao item in the operator's main hand. A Chao literally named `held` is selected with `/chao refresh "held"`.
- Server operator permission level2 is required, including direct helper entry points. Creative without that permission is insufficient. Console can use loaded name/nearest coordinates; held mode requires an actual online player.
- Loaded refresh clears the two official/reference overrides, force-publishes tracked defaults/current state, and invokes the established managed-body→actual-carrier snapshot transaction. It does not replace the entity, re-derive first type, alter age/visual strength/training, reroll genes/faces/personality, move the entity, change gear or interrupt toy sessions. Cocoons, construction, active activities and operator previews are rejected until safe, preserving their normal restoration contract.
- Held refresh changes only those two appearance keys in the saved entity compound. Its raw `Chao` encoded string, UUID, ownership, counters, unknown NBT and all other item components/count remain untouched. Existing release/recovery/keeper admission is retained. Actual live, managed, presummon or hidden-body identity conflicts reject a stale held copy. Normal supported legacy decoding remains owned by ordinary release/load.
- No `all`, offline-player inventory scan, unknown-chunk load, replacement world data or forced global world save is introduced. Normal entity autosave/unload and item/player save retain the change; command feedback does not claim a forced disk flush.
- This command does not reload client resource packs, download new models or convert an intrinsically unavailable form. Matching updated JAR/assets are still required on clients. It intentionally does not reconstruct undocumented missing mature strength from stats or make a baby/adult biologically older.

Production files: new `ChaoRefreshCommands084`; one `GardenCommands` registration call; `EditingCommands056.loadedNames` visibility shared for suggestions; narrow `ChaoEntity.refreshGardenAppearance084` force-tracking API. The ability owner added `CompanionContent.hasManagedIdentity084(UUID)` as a read-only authoritative-identity guard. No client imports enter the new common command.

## Native tests prepared (root executes)

`ChaoRefreshGameTests084` generates5 cases. Four core cases use existing `chao_fixes84:activity_test`. The actual Accessories case uses existing `chao_bonus80:activity_test`, selected only in the actual optional-runtime suites. A minimal-runtime attempt initially selected all5 and produced54/55 with the explicit missing-Accessories assertion; that failed attempt is retained. The one optional registration was then moved to its proper existing namespace/template; no gameplay code, skip or optional assertion was weakened.

1. All15 adult alignment/first-type families plus3 baby alignments: exact valid encoded state, full entity NBT except the two presentation keys, persistent foreign/counter data, equipped items and native entity reload retained. Already-garden case verifies forced native metadata publication even when state bytes are unchanged.
2. Native dispatcher/direct-handler permission0 Creative rejection; exact case-insensitive unique name, nearest, duplicate-name and equally-near ambiguity, quoted reserved `held`, and no actual target.
3. Missing usage/name/target and cocoon/construction atomic rejection.
4. Actual main-hand carrier: live duplicate and non-op rejection, exact expected item/component/raw-state conservation, carrier serialization/reload, foreign keeper and missing identity rejection. Existing recovery-ticket policy is reused, not replaced; the unchanged recovery suites remain relevant additional coverage.
5. Actual Accessories slot projection refresh: same managed body/carrier UUID, current exact state, unchanged token and immediate appearance-key snapshot; held duplicate denied; native reload retained. A missing Accessories installation fails instead of claiming a skipped coverage case.

These fixtures test server/native serialization/tracking-data behavior. They do not establish a new actual second client, physical input or visual judgment. No runtime, Gradle or Java launch was performed by this agent. Root owns all execution/results and any actual-client command check.

The earlier client-harness assignment was superseded before any .84 helper files were authored; only read-only inspection/coordination occurred. This command adds no competing renderer, animation or movement implementation.
