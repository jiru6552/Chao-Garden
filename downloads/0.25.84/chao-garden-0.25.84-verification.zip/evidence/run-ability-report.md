# .84 hidden Run ability: implementation and test handoff

## Agreed units and compatibility

The user clarified **+100,000% bonus**, which is **1,001 times the ordinary total**, not 100,000 times normal. `EquippedAbilityRules080.bonus` now maps the existing eleven saved control tiers `1000, 900, …, 0` directly to additive multipliers `1000, 900, …, 0` for both Run and Power. Thus one activation now changes the bonus by 10,000 percentage points. The existing trait keys, default, cycling transaction, full-trait-map rejection and zero-to-maximum wrap stay intact. No saved schema migration or reroll occurs. Root's separate Power work changes the attacking actor; this agent did not edit those Power hooks or their shared legacy native-test file.

Eligibility still requires the actual equipped adult's expressed X rank, level 99, locked first Run type and exact current Run specialization. Alignment remains unrestricted. Fatigue adds no new secret Run eligibility gate. Current server authorization remains separate from client prediction; the client recognizes only the exact synchronized secret modifier tiers 100..1000, excluding the ordinary trained Run modifier 0..1.

## Flight and movement design

The actual NeoForge 1.21.1 movement attribute maximum is 1024. Normal Player base .1 with total1001 yields100.1, below that cap; no global attribute cap change was added. Other mods or unusual base attributes may still encounter the native cap.

Creative flight uses `Abilities.getFlyingSpeed`, independent of the land movement attribute. New stateless wrappers multiply only its reads in `Player.getFlyingSpeed` (horizontal/sprint) and `LocalPlayer.aiStep` (jump/crouch vertical input). Underlying custom `abilities.flySpeed`, saved data and flight permissions are untouched, so no restore markers or guessed default are needed on unequip/reconnect. No new `mayfly` permission is granted.

Companion and native elytra use the fall-flying travel branch. Its final physical `move` displacement is scaled once; the stored aerodynamic delta, steering/drag calculations and subsequent native collision/wall/landing handling stay unscaled/native. This avoids exponential multiplication every tick. The mixin targets ordinal2, the third direct `LivingEntity.move` call in NeoForge1.21.219 `LivingEntity.travel`, after the water and lava branches. Exact source scope and the compiled owner/descriptor were inspected read-only; root must validate mixin application in actual runtimes.

The existing native expected-motion hook now composes its Power-impulse allowance with a Run-only envelope derived from current real-slot authority. It does not use the client-requested target to create allowance, and it preserves native collision, coordinate clamps, teleport acknowledgment, wrong-move and other validation. Pending packet burst is still capped to native1..5, with overflow falling back to1. Ground bounds use actual movement attribute/support friction and native acceleration/drag recurrences; Creative uses actual custom flySpeed and .91/.6 horizontal/vertical recurrences; glide allows a bounded native steering/gravity update around the server's unscaled aerodynamic velocity. Actual two-client default-speed movement must verify these bounds, especially client/server glide velocity parity and transitions.

Read-only diagnostics: `EquippedRun084.movementCheck(ServerPlayer)` records last actual expected-motion evaluation (mode, current multiplier, envelope, bounded burst, ordinary and authorized terms); it returns null when current authority is lost. The server rechecks current eligibility for every physical/helper/validation evaluation; no persistent movement exemption is installed.

## Implemented helpers for adjacent work

- `CompanionContent.hasManagedIdentity084(UUID)` rejects stale held refresh copies if any Active record still owns that UUID, including a hidden/non-ticking live projection or a pre-summon saved stack.
- `CompanionContent.secretRunBonus084(ServerPlayer)` resolves current authenticated Run authority.
- `CompanionContent.secretPowerBonus084(ChaoEntity)` resolves only the exact current equipped projection and keeper/slot authority. Natural/unmanaged garden Chao and player attacks are not authorized through this helper. Root's Power owner uses it.

## Test handoff (no launches by this agent)

The existing core ability test was updated for the new bonus units while preserving all eligibility, save/reload, eleven-tier cycling and saturated-save tests. It also invokes a new pure numerical suite (`EquippedRun084Test`) for malformed/ordinary modifier exclusion, custom flight values, native ground/Creative recurrence bounds and capped packet bursts. Numerical checks do not prove actual input or collision behavior.

New `chao_run84` native namespace contains six cases using actual Accessories slots and a root-provided excluded chao_run84 fixture:

1. Three alignment cases verify the real movement attribute ratio1001, actual Player flight getter, unchanged stored flySpeed and immediate rank-loss revocation.
2. Paired actual native Creative travel uses a small custom flySpeed .00005 to keep moves inside a bounded arena, checks1001 displacement ratio and exact custom stored ability retention across unequip.
3. Actual earned companion glide checks1001 physical displacement relative to unscaled aerodynamic velocity, a second tick without exponential growth, immediate unequip removal and unchanged Creative permissions.
4. Actual inbound native movement packets accept an authorized20-block step, reject an unbounded100000-block request and reject30 blocks after unequip. Its short swept corridor is explicitly warmed and retains collision.

Root must run core/build/dedicated client separation, `chao_run84`, migrated existing `chao_bonus80` and final regressions. The old shared native Run expectations require1000/900/800 bonuses and1001/901 total ratios; root's Power/native-test owner was notified rather than competing on that file.

Remaining actual-client probes: normal default-speed keyboard ground/Creative horizontal and vertical movement; real companion/native elytra movement from actual input; two-player non-owner server validation without correction; collisions, rank/secondary loss, cycle/zero, unequip, reconnect and dimension changes. No FPS/TPS, long-distance chunk performance, shader/modpack or completed actual-client claim is made here. Extremely large requested travel can still create substantial vanilla chunk/collision work; no chunk-teleport bypass was introduced.

## Actual-client study implementation (not yet launched)

`RunVisualSmoke084` is opt-in via `CHAO_RUN084_SMOKE=true`, `CHAO_RUN084_OUTPUT=<fresh absolute folder>` and `CHAO_RUN084_SOURCE_FREEZE=<recorded SHA>`. It creates a disposable ordinary flat integrated world; there is no hardcoded player name, external server or TCP observer. Default raw `abilities.flySpeed=.05` is retained throughout. Nine fixture cases yield ten captures including the extra live-inertia revocation subcase: ground, Creative horizontal, Creative vertical and companion glide each compare saved zero/maximum tiers, followed by ordinary trained-Run Creative flight. An actual max Creative flight is unequipped without resetting momentum; the following real ordinary forward input must add only the normal .05*.98 acceleration after native drag.

Each measured action uses one actual LocalPlayer tick and ordinary KeyMapping input, not a direct travel/position boost. Glide uses the same unscaled .2 initial control velocity in both paired fixtures and the normal companion launch gate/START_FALL_FLYING packet. Initial fixture setup teleports and resets between cases only. A finite 512-block real floor/collision corridor is warmed. The excluded harness immediately pauses the integrated game after the one measured tick, using a transparent capture screen plus the client's pause flag to stop slow-frame catch-up ticks; this bounds the extreme movement and provides actual native framebuffer PNGs. This scheduler control is not part of the mod's gameplay and does not grant a movement, collision or permission bypass. It is explicitly not a continuous motion soak or a non-owner anti-cheat proof.

The study records actual default-speed modifier/input fields, UUID/locked identity and carrier/body agreement, client tick count, before/after position and aerodynamic velocity, server acknowledgment and native movement diagnostics, sampled traces, untouched raw flySpeed, PNG hashes and four paired physical distance ratios. A successful run must have exactly one native player tick per measurement and approximately1001x distance ratios. Root must compile/launch and independently review these results; no success is implied by this implementation.

The first native Creative reference attempt used custom .00005 flySpeed and produced zero ordinary displacement below Entity.move's small-motion squared threshold1e-7. It was an invalid denominator fixture, not proof of a production flight bug. The reference now uses .001 and explicitly asserts ordinary displacement positive before comparison. Production behavior was not changed for that failed test.
