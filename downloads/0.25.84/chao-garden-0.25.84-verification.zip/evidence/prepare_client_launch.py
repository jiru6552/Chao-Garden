#!/usr/bin/env python3
"""Prepare one fresh .84 native-client cohort. Never launch Java/Gradle/display.

Uses the fresh ModDev JavaExec metadata and generated native bootstrap argfiles;
no prior-version classpath, saved world, account cache or VM-argument snapshot is
copied. Root invokes this only after final compilation/runtime freeze.
"""
from pathlib import Path
import argparse,hashlib,json,os,shlex,uuid,zipfile

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def quoted(v):return '"'+str(v).replace('\\','\\\\').replace('"','\\"')+'"'
def offline(name):return str(uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+name).encode()).digest(),version=3))
def main():
 a=argparse.ArgumentParser(description=__doc__)
 a.add_argument('--mode',choices=['fixes','run'],required=True)
 a.add_argument('--output',type=Path,required=True,help='New private cohort folder; refuses existing attempts')
 a.add_argument('--resolved-classpath',type=Path,required=True)
 a.add_argument('--source-freeze',type=Path,required=True)
 a.add_argument('--source-freeze-sha256',required=True)
 a.add_argument('--project',type=Path,default=Path('/workspace/Chao-Garden'))
 a.add_argument('--runtime-directory',type=Path,help='Fresh build/moddev folder; defaults to current project')
 a.add_argument('--display',default=':98')
 a.add_argument('--profile',help='New offline development profile; defaults Fix84View/Run84View')
 a.add_argument('--width',type=int,default=1440)
 a.add_argument('--height',type=int,default=1000)
 args=a.parse_args();root=args.project.resolve();out=args.output.resolve();resolved=args.resolved_classpath.resolve();freeze_path=args.source_freeze.resolve();runtime=(args.runtime_directory or root/'build/moddev').resolve()
 assert out.is_relative_to(Path('/workspace/.setup')) and not out.exists(),'Use a new private cohort folder'
 assert resolved.is_file() and freeze_path.is_file(),'Prepare fresh actual classpath and final source freeze first; no plan was written'
 assert sha(freeze_path)==args.source_freeze_sha256 and len(args.source_freeze_sha256)==64,'Exact root-reviewed freeze pin required'
 freeze=json.loads(freeze_path.read_text());assert freeze.get('version')=='0.25.84','Use .84 final runtime freeze'
 assert 320<=args.width<=4096 and 240<=args.height<=2160
 profile=args.profile or ('Fix84View'if args.mode=='fixes'else'Run84View');assert 1<=len(profile)<=16 and profile.replace('_','').isalnum(),'Use ordinary offline development profile'
 metadata=json.loads(resolved.read_text());assert metadata['task'].split(':')[-1]=='runClient'
 cp=[Path(n).resolve() for n in metadata['classpath']];assert cp and len(cp)==len(set(cp)) and all(p.exists()for p in cp),'Fresh resolved classpath entries must exist and be unique'
 java=Path(metadata['javaExecutable']).resolve();assert java.is_file(),'Use the actual resolved Java launcher'
 vm=runtime/'clientRunVmArgs.txt';program=runtime/'clientRunProgramArgs.txt';legacy=runtime/'clientLegacyClasspath.txt'
 assert all(p.is_file()for p in (vm,program,legacy)),'Fresh prepareClientRun argfiles required'
 dynamic=list(metadata.get('dynamicJvmArguments',[]));folders=[v for v in dynamic if v.startswith('-Dfml.modFolders=')]
 assert len(folders)==1,'Require actual dynamic ModDev modFolders mapping; never guess it'
 assert not any('gametestdimensions'in str(p).lower()for p in cp) and 'gametestdimensions'not in folders[0].lower(),'Development GameTest dimensions cannot enter an ordinary client cohort'
 assert not(root/'build/resources/main/data/minecraft/worldgen/world_preset/flat.json').exists(),'Main runtime must not contain the GameTest flat preset'
 assert any('accessories'in p.name.lower()and p.suffix=='.jar'for p in cp),'Actual optional Accessories runtime required'
 assert any('owo-lib'in p.name.lower()and p.suffix=='.jar'for p in cp),'Actual owo dependency required'
 assert any('lionfishapi'in p.name.lower()and p.suffix=='.jar'for p in cp),'Actual external Lionfish API required'
 def includes(p,name):
  if p.is_dir():return(p/name).is_file()
  if p.suffix!='.jar':return False
  with zipfile.ZipFile(p)as z:
   try:z.getinfo(name);return True
   except KeyError:return False
 assert any(includes(p,'net/minecraft/server/MinecraftServer.class')for p in cp),'Resolved native client CP lacks actual merged Minecraft server class'
 helper='com/chaogarden/client/'+('FixesVisualSmoke084'if args.mode=='fixes'else'RunVisualSmoke084')
 assert any(includes(p,helper+'.class')for p in cp),'Compile the selected opt-in .84 helper before preparing a plan'
 version=next(l.split('=',1)[1].strip()for l in(root/'gradle.properties').read_text().splitlines()if l.startswith('mod_version='));assert version=='0.25.84'
 source_mismatches=[]
 for n,h in freeze['files'].items():
  p=root/n
  if not p.is_file()or sha(p)!=h:source_mismatches.append(n)
 assert not source_mismatches,('Frozen source/class/resource bytes changed',source_mismatches[:8])
 program_args=shlex.split(program.read_text(),comments=True,posix=True)
 assert program_args and program_args[0]=='cpw.mods.bootstraplauncher.BootstrapLauncher','Preserve actual generated NeoForge BootstrapLauncher main'
 assert '--launchTarget'in program_args and program_args[program_args.index('--launchTarget')+1]=='forgeclientdev','Ordinary actual client bootstrap required'
 assert '--gameDir'in program_args
 # Preserve all bootstrap/runtime options, replacing only explicit development
 # profile/window/game directory arguments. Never copy old .83 argument files.
 def option(key,value):
  if key in program_args:program_args[program_args.index(key)+1]=str(value)
  else:program_args.extend([key,str(value)])
 home=out/'host';evidence=out/'evidence';option('--gameDir',home);option('--username',profile);option('--uuid',offline(profile));option('--accessToken','0');option('--width',args.width);option('--height',args.height)
 inputs={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in(vm,program,legacy,resolved,freeze_path,root/'gradle.properties',root/'build.gradle',java,Path(__file__).resolve(),Path(__file__).with_name('launch_prepared_client.py'),Path(__file__).with_name('run-command.py'))}
 # Follow actual generated VM file references; these files remain pinned even
 # though the generated argfile itself is copied into this private cohort.
 for v in shlex.split(vm.read_text(),comments=True,posix=True):
  if v.startswith(('-Dlog4j2.configurationFile=','-DlegacyClassPath.file=')):
   p=Path(v.split('=',1)[1]);assert p.is_file();inputs[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
 cp_files={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in cp if p.is_file()}
 cp_dirs={}
 for p in cp:
  if p.is_dir():
   prefix=p.relative_to(root).as_posix()+'/'if p.is_relative_to(root)else None
   entries={n:h for n,h in freeze['files'].items()if prefix and n.startswith(prefix)}
   assert entries,'Classpath directory lacks exact root freeze coverage: '+str(p)
   cp_dirs[str(p)]={'recorded_files':len(entries),'freeze_subset_sha256':hashlib.sha256(json.dumps(entries,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
 out.mkdir();home.mkdir();evidence.mkdir()
 vm_out=home/'vm.args';program_out=home/'program.args'
 text=vm.read_text().rstrip('\n')+'\n'+'\n'.join(quoted(v)for v in dynamic)+'\n-cp\n'+quoted(os.pathsep.join(str(p)for p in cp))+'\n-Xmx2G\n-XX:ActiveProcessorCount=3\n'
 vm_out.write_text(text);program_out.write_text('\n'.join(quoted(v)for v in program_args)+'\n')
 stem='CHAO_FIXES084'if args.mode=='fixes'else'CHAO_RUN084'
 env={'DISPLAY':args.display,'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2','ALSOFT_DRIVERS':'null',stem+'_SMOKE':'true',stem+'_OUTPUT':str(evidence),stem+'_SOURCE_FREEZE':args.source_freeze_sha256}
 plan={'status':'PREPARED_NOT_LAUNCHED','version':'0.25.84','mode':args.mode,'scope':'Fresh ordinary native development client with real optional runtime; no GameTest flat override, saved-world reuse, process/test/visual verdict or installed-JAR claim.',
  'project':str(root),'source_freeze':str(freeze_path),'source_freeze_sha256':args.source_freeze_sha256,'source_freeze_paths_verified':len(freeze['files']),'inputs':inputs,'resolved_classpath':list(map(str,cp)),'classpath_files':cp_files,'classpath_directories':cp_dirs,'actual_dynamic_jvm_arguments':dynamic,'bootstrap_main':program_args[0],
  'client':{'profile':profile,'offline_uuid':offline(profile),'cwd':str(home),'command':[str(java),'@'+str(vm_out),'@'+str(program_out)],'environment':env,'environment_policy':'Remove ALL inherited CHAO_* variables first, then set only this selected helper environment. Keep normal unrelated OS variables.','argument_files':{str(p):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in(vm_out,program_out)},'window_requested':[args.width,args.height]},
  'evidence_directory':str(evidence),'fresh_world_only':True,'world_files_copied':0,'old_profiles_copied':0,'normal_dimension_boundary':True,'actual_aether_on_classpath':any(p.name.lower().startswith('aether-')for p in cp),
  'limits':['Software GL and null audio; no listening or hardware/shaderpack verification.','Single integrated client; no independent non-owner TCP client or remote anti-cheat claim.','Root must start/own display and actual Java process; this preparation launched nothing.'],
  'runner':str(Path(__file__).with_name('launch_prepared_client.py'))}
 plan_path=out/'launch-plan.json';plan_path.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'status':'PREPARED_ONLY','plan':str(plan_path),'mode':args.mode,'classpath_entries':len(cp),'frozen_paths_verified':len(freeze['files']),'processes_launched':0},indent=2))
if __name__=='__main__':main()
