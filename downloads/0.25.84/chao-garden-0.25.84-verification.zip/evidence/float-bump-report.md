# .84 player bumping of physical floats

Inspected FloatToyEntity080, FloatToyContent080, FloatToyGoal080, FloatToyRoutes080, FloatToyGameTests080, fixture helpers and the actual1.21.1 Entity/LivingEntity/Boat collision paths. Existing floats intentionally returned isPushable=false and had no boat-style contact query. Merely making that return true is insufficient: hard collisions stop boxes just short of overlap, and vanilla Entity.push does not accelerate a vehicle carrying a passenger.

## Scoped implementation

Only FloatToyEntity080 production code changed. It now receives server-only player contact from a tight0.04-block horizontal rim with0.02-block upper foot-contact tolerance and the engine push(Entity) callback. This is physical horizontal velocity consumed by existing move(MoverType.SELF), not a setPos/teleport or item/block conversion. Per-player/server-tick dedup prevents its own contact scan and vanilla callbacks from counting the same contact twice. Each contact adds0.04 horizontal impulse; combined horizontal speed is capped0.08blocks/tick when receiving a player bump. Existing0.65drag, real block collision, buoyancy, positional synchronization and occupied swept body/head clearance are retained.

Only unclaimed idle empty toys and stable occupied RIDE accept pushes. BOARD/EXIT anchors, claimed approaches, Chao-controlled PUSH/reposition, held previews and pending removal remain protected. Player spectators, dead players, noPhysics, passengers, remote callbacks and same-vehicle contact are excluded; vanilla team collision policy is respected. Non-player mobs do not acquire a new push behavior.

No new saved fields, entity/item IDs, acquisition rules, occupancy claims, dimensions or reward paths. The queued collision impulse is ephemeral; ordinary entity Motion/position serialization remains the same. No model/animation changes; existing once/loop/stop toy previews stay intact.

## Native cases ready for root execution

FloatToyBumpGameTests084:40 explicit generator TestFunctions, holder/template namespace chao_fixes84, root's development-only existing fixture copy.

-16 ordinary player-contact cases: bothmodels × land/water × fourhorizontal directions. Test player uses actual Entity.move collision; it never calls toy push/move/setPos/setDeltaMovement during the sample. Initial placements are fixtures. Land players use ordinary gravity and downward collision movement; low-ring cases explicitly assert actual auto-step contact. Water players have NoGravity solely to isolate horizontal collision at the waterline; this is not a full client swimming/input test.
-4 occupied cases: bothmodels × baby/adult, real board and entry to RIDE, actual contact displacement, passenger/seat/claim/form/alignment/equipment/buoyancy checks.
-12 protected-controller cases: bothmodels × claimed approach, Chao push, reposition, short BOARD arc, preview-held state and occupied pending removal. Pending case uses a high real pool rim so safe-land route motion cannot be confused with player motion.
-2 remote/spectator rejection cases,2 repeated-contact dedup cases (100callbacks plus own query still produce one0.04 physical step and0.65drag),2 ordinary save/reload/component-preserving single-pickup cases,2 solid-wall physical collision cases.

Tests are not claimed passing until root executes them. Existing .80 float transaction/natural route/entry/exit tests should be rerun for regressions. Actual client input, two-peer replication and visual inspection are root scope. No Gradle/Java/client/server process launched by this agent.

Pre-execution engine review found that ordinary players can auto-step onto the low0.20ring. Contact now includes two centimeters above the actual top to include feet touching that surface, and land fixtures retain ordinary gravity/onGround collision instead of masking step behavior. Hull/head/step attributes remain unchanged.

## First native run and fixture corrections

Root's focused-native01 actually executed100cases,96passed/4failed; three failures belonged to this float matrix. Two dedup cases injected callbacks in GameTest tick3, after that world's real hull tick had already run; hull tick4 then correctly saw another contact in a new server tick. Exact MinecraftServer ordering (world/entities, connections/players, then GameTestTicker) proves that expecting one0.04 step from contacts across those two ticks was invalid. The test now injects100callbacks once from ServerTickEvent.Pre after real hull/chunk readiness, allowing the own hull query in that same server tick; it retains exact0.04 displacement/0.026drag assertions, and additionally checks the actual hull tick/server tick identities. The bounded timeout80 allows readiness, not extra contacts or larger tolerance.

One baby ring rider case was vulnerable to a different test lifecycle bug: GameTestInfo.tickInternal continues remaining due callbacks after h.succeed(), while succeed() immediately removes non-player fixture entities. An unguarded same-tick onEachTick rider assertion could therefore run after successful teardown and overwrite the outcome. Repeating movement/assertion callbacks now return when testInfo.isDone(), preserving all active-rider assertions and adding detailed diagnostic fields on any real failure. No production controller changes were made for these fixture corrections. Rerun results remain root scope.
