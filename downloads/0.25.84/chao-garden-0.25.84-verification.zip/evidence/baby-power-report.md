# Baby Power morphology correction (.84)

## Verified cause

The actual Creative edit writes Power levels/progress and synchronizes them correctly. The approved ordinary baby route only had Neutral/Hero × Run targets, however. `HeroRunMorphology052` clamps `(Run − Power)/480` to the positive Run half-axis; Power99 therefore gave zero Run growth at every visual age. The existing .55 fixed-head surface deliberately bypasses the old generic donor deformation, so no independent Power baby anatomy remained to display. This is missing baby morphology coverage, rather than a lost command edit, a numerical level cap, or a reason to change adult evolution rules.

## Reference and implementation

The reference agent operated the live Chao Island viewer with Child selected, independently changed alignment, Power and age controls, and rotated/captured front/side/back. The Neutral and Hero endpoint originals were also opened by the model author. Reference scope and the first failed TLS attempt are preserved under `reference/FINDINGS.md` and its manifest; no source geometry or game timing formula was imported.

Eight existing separate feature cuboids receive three baby-only Power target sets from `assets/chao_garden/baby_power084.json`: Neutral has a short broad rear lip, front crest and two high blunt side nubs; Hero has two flaring top buds plus a small center lobe; Dark has a bent upright two-piece stem. The original .55 model file and every adult-family JSON remain unchanged. The original 7×6×6 head box, eyes, torso, hands, feet and shared attachment joints are untouched. The separate old tuft retracts smoothly into the head through the same 2.5-pixel mesh-only movement already used by approved Hero/Run; it is not abruptly hidden or substituted for the base skull.

New transforms append to the existing rigid-box sampler: centers, positive sizes and rotations blend before evaluating the original eight corners. Rendering, normals, bounds and attachments therefore share one actual surface, without a second model renderer or vertex-sheared cuboids. Zero Power and adults take the exact previous surface path. The existing bounded twenty-tick client display clock also carries Power growth; edits/reversals begin from the currently displayed value.

`BabyPowerMorphology084.sample(state)` reads current level bars, with `training = clamp((Power − Run)/480, 0, 1)` and `growth = training × child evolutionStrength`. This deliberately reuses the existing provisional Run baby range. Power99 reaches the training target but does not invent visual age. Run can cancel/reverse it without making the Chao younger. There are no new saved fields, stat changes, adult admissions or evolution chooser changes.

Baby-only Power pigments blend on the retained atlas. Natural two-tone Neutral develops coral/orange/mauve/teal accents, Hero retains white with warm cap/limb colors, and Dark develops brown/ochre/red/yellow accents. Baby markers remain spheres; no adult eye inversion or halo is introduced. Genetic/mono body hues and source alpha/facial regions are preserved. Existing dynamic material keys remain identical at zero Power. Colors, fine bands and curved silhouettes are authored blocky approximations, not exact source texture/model copies.

## Checks and remaining verification

No Java/Gradle/Minecraft process was launched by this agent. The root owns actual builds, native dispatcher cases and visual captures.

- Generator syntax and sidecar JSON were checked; the approved .55 SHA remains `77b41d4501cba585b83be91b4052e8c56e03bff02e47db2b209f146d36390f08`.
- A separate Python source-transform/SAT pass covered 378 age/signed-training/alignment cases: all sixteen existing feature boxes stay connected to the fixed head and retain positive volume. This is source geometry evidence, not emitted Java geometry or visual acceptance (`baby-power-source-check01.json`).
- Added and registered core checks cover real Creative edits, drives/combined drives/losses, age independence, signed Power→Run changes, colors/shiny scope, exact encoded round-trips, adult gates/locks and natural first evolution.
- New `BabyPowerRigTest084` exercises 378 emitted geometry cases plus 108 actual Lionfish motion cases, fixed head/eyes/body/compact limb surfaces, SAT attachment/orb/eye clearance, original tuft concealment, edit/reversal continuity, unchanged joints/toy palms and protected pixel alpha. Execution belongs to root; this report does not predeclare its result.
- Root is adding actual dispatcher `/chao ~ <alignment> Power 99`, maturity payload, synchronization/NBT and opposing/evolution selection checks, plus actual client captures.

Remaining visual scope includes all hats/animal combinations, every toy pose, shader packs, physical touch/mouse interaction and source-game timing equivalence. No broad first-type/adult model redesign is part of this correction.
