# Independent read-only review of .84 Run flight/movement

Reviewed EquippedRun084, EquippedRunRules084, all three new Run mixins, existing EquippedMovementValidationMixin080/EquippedMovementRules080, current CompanionContent eligibility/modifier/revocation paths, core/native Run tests, and exact NeoForge1.21.1 Minecraft Entity/LivingEntity/Player/LocalPlayer/ServerGamePacketListenerImpl sources. No edits or Java/Gradle/client/server launches by reviewer.

## Confirmed by source inspection

- Server multiplier revalidates the real current accessory token, UUID, owner, live body, recovery/current-slot status and exact evolved/X-rank99 Run qualification. Client prediction consumes only the synchronized known modifier ID; it is not server authority.
- Ordinary trained modifier amounts0..1 do not grant flight multipliers. Only the existing discrete secret0,100,...1000 tiers produce1,...1001. No arbitrary client multiplier or unbounded saved input is accepted.
- Creative horizontal and vertical hooks multiply the original input getter, preserving custom saved Abilities speeds and existing mayfly/flying permissions. The common hook imports no client class; LocalPlayer's hook remains client-only in mixin configuration.
- Exact native travel has water/lava moves before the third direct move in fall-flying. Only that physical glide displacement is wrapped. Aerodynamic stored delta remains unscaled, so later glide ticks do not exponentiate1001. Collision-induced velocity clipping and native flight/wall logic remain in their original methods.
- Native movement validation retains coordinate finite checks, clamps, teleport acknowledgments, sleeping/passenger handling, mode/permission checks, collision/moved-wrongly handling, world checks and the vanilla fast-movement test. Only the expected-motion scalar is enlarged for a server-authenticated Run state. Native pending-packet allowance remains1..5 and overflow resets1. Existing server-authored knockback authority is preserved as the ordinary input to Run's bound.
- Numerical helpers reject malformed bonus tiers, non-finite or negative base/envelope inputs and invalid friction; expectedSquared rejects overflow/non-finite trusted bounds rather than granting infinite budget. Glide/Creative factor is capped1001. Actual maximum capability still depends on native attribute/engine limits and loaded terrain, so real clients are necessary evidence.
- Authority revokes immediately when rank/current slot/identity no longer qualifies. No saved abilities field or permanent extra modifier is introduced; current modifier cleanup remains CompanionContent's existing path. Weak diagnostic map values do not retain their player keys.

## Ground-envelope/chunk access

The new groundEnvelope code does not walk or generate the requested movement corridor. It reads only the current player's `getOnPos()` block before accepting the requested coordinates. A player's current supporting chunk is ordinarily already loaded. The lookup has no explicit hasChunkAt guard; an artificially stale/unloaded supporting position could synchronously request a block. I did not establish a normal reachable production state for that case and do not label it a verified bug. A conservative hasChunkAt fallback is a reasonable small guard if the owner chooses it.

The selected friction block is getOnPos(), while native travel's acceleration uses getBlockPosBelowThatAffectsMyMovement() (.500001offset). On carpets/slabs/custom blocks these can differ. Current max(speed*3,...) bound still dominates the tested ordinary vanilla frictions, so this is not a demonstrated vanilla rejection. Reusing the exact native friction position would make modded-friction behavior easier to reason about; avoid claiming full modpack friction coverage without tests.

## Runtime gaps to keep explicit

No verified authority/collision/permission bypass or exponential glide bug found in this read-only review. This is not a native pass or actual client test result. Existing native Creative and glide comparisons reset delta before the post-unequip reference; they prove removal of the input/displacement multiplier, not the visible momentum behavior of unequipping at full speed. Native Creative inertia naturally decays after its input multiplier is removed, while the server custom allowance revokes immediately; a real client's correction/settling behavior after a full-speed tier decrease/unequip should be checked. Do not weaken the server authority to paper over that test.

Very high real speed can still impose ordinary terrain streaming/collision costs even though the new bound itself scans no corridor. Shader/modpack mixin compatibility, default-speed sustained flight/glide, tier changes, dimension changes and reconnect behavior require the root's actual native/client evidence.
