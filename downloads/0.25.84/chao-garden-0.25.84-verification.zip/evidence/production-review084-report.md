# .84 production source and persistence review

Read-only review against the exact accepted .83 source inventory and source ZIP, not the cumulative dirty .43 Git diff. No source edits, builds, client/server launches or final packaging were performed by this reviewer.

No blocking issue found in the reviewed .84 delta. This is a bounded code and artifact review, not a runtime acceptance claim.

## Inputs and exact scope

- Accepted .83 inventory: `c2e81bf9de42a7950702c9b623d54b2f769c8712b3ec64fb5a965a23a8e292ae`; 1,020 parent source paths and 21 guarded deletions.
- Accepted .83 source ZIP: `5a60a872d54fd99fd74fc4eb752345ece631f4b7f1f19ef0f18630c04539c330`.
- Current runtime freeze02: `9296659d5cf58ac7a831f1d17a317fcbc031dfdc5c595744a4962783c23bdee2`; 19,159 source/class/resource inputs checked; at review completion, the excluded `PowerRemoteVisualSmoke084.java` helper source had changed from its freeze02 bytes. All other frozen inputs matched. The helper drift was reported immediately to root; it is not a production JAR change. Final runtime/source provenance must use each attempt's exact pins.
- Current .84 JAR: `3b4113840031a7dcd4b20307d60f31d321e6afc044d4708b31d7a7cee90b467c`, 30,711,982 bytes. Matches the freeze pin.
- Snapshot: 28 modified parent paths plus 33 added overlay paths (23 genuinely new files and 10 previously existing base assets newly overlaid); 1,053 cumulative overlay source paths. Final `docs/FIXES_02584_DEV.md` was pending and is not included in these snapshot counts. Root must finalize its own allowlist after report completion.

## Findings

**Refresh command and carrier safety.** `/chao refresh` requires server permission level 2, including direct method invocation. It reuses the existing loaded-dimension selector with explicit ambiguity/no-nearby handling. A Chao named `held` remains addressable as `"held"`; unquoted `held` selects only the main-hand carrier. Loaded refresh clears official/reference flags, forces normal tracked appearance/state publication, and snapshots the actual managed carrier. It neither reconstructs age/strength/type nor rerolls genes. The held path preserves the encoded Chao string and unknown raw NBT/components and modifies only `OfficialComparison` and `SourceReferenceRig`; it rejects missing identity, active/presummon/managed or loaded duplicates, and unavailable keeper/recovery admission. Cocoon, construction, activity and operator preview states are rejected for loaded entities. Saves follow existing autosave paths, without a forced immediate disk flush. This does not reload a client's resource packs or scan offline/world-wide Chao.

**Float physics.** New movement comes from actual nearby server-side player contact, with a narrow local box and bounded 0.04 impulse/0.08 horizontal speed. A player contributes once per server tick. Only ordinary unclaimed idle floats or stable occupied ride states accept bumps; boarding/exiting, land transport, transfers, recovery, previews and pending removal retain validated anchors. Eligibility changes discard queued impulses. Existing route/swept collision checks still constrain occupied float motion. No item or payload duplication path, extra save field, packet-supplied force or world-wide scan was introduced.

**Saved data and IDs.** `ChaoEntity` and `FloatToyEntity080` save/read method bodies are byte-identical to accepted .83. `ChaoState`, `ChaoCarrierItem`, `ChaoGarden` and `CompanionNetwork` remain byte-identical. No removed parent source or resource file, registered item/block/entity/component ID, payload codec, or garden migration change was found. Existing eleven stored ability tiers and keys remain unchanged; their deliberately stronger .84 bonus interpretation is an intentional requested behavior change, not a data-format migration.

**Dedicated-server/client separation and packaging.** New common Run and morphology helpers and shared mixins contain no client imports. The LocalPlayer-specific flight mixin appears only in the client mixin list. JAR inspection found 9,272 unique entries, all CRCs valid, with no capture helper, native test class, test fixture namespace or development flat-dimension override. The complete production `data/` file set is unchanged. The only new production resource file is `assets/chao_garden/baby_power084.json`; ten placed duck/tambourine model files change. An additional ZIP directory entry for existing coffin textures is empty metadata, not a new resource file or registry ID.

## Limits

Actual runtime, visual, dedicated-server and multiplayer outcomes belong to root's separately recorded runs. In particular, this review makes no new .84 old-world restart claim and no authentic .82 partial-minute counter restart claim. The clean build, optional-mod coverage and current Power two-client attempt must be assessed from their own completed receipts. No inherited gameplay, save-compatibility or new protocol blocker was identified in this scoped review.

## Exact changed-file inventory

Modified accepted .83 paths:

- `CHANGELOG.md`
- `README.md`
- `TESTING.md`
- `art/build_cwe_content_019.py`
- `build.gradle`
- `gradle.properties`
- `scripts/generate_sa2_assets_02515.py`
- `src/main/java/com/chaogarden/EditingCommands056.java`
- `src/main/java/com/chaogarden/GardenCommands.java`
- `src/main/java/com/chaogarden/client/BlockyRunBox055.java`
- `src/main/java/com/chaogarden/client/ChaoMeshAsset.java`
- `src/main/java/com/chaogarden/client/HeroRunAppearance052.java`
- `src/main/java/com/chaogarden/client/HeroRunCoatMaterial055.java`
- `src/main/java/com/chaogarden/client/OfficialChaoRig.java`
- `src/main/java/com/chaogarden/companion/CompanionContent.java`
- `src/main/java/com/chaogarden/companion/EquippedKnockback080.java`
- `src/main/java/com/chaogarden/core/EquippedAbilityRules080.java`
- `src/main/java/com/chaogarden/entity/ChaoEntity.java`
- `src/main/java/com/chaogarden/mixin/EquippedHurtKnockbackMixin080.java`
- `src/main/java/com/chaogarden/mixin/EquippedMovementValidationMixin080.java`
- `src/main/java/com/chaogarden/mixin/EquippedPlayerAttackMixin080.java`
- `src/main/java/com/chaogarden/test/EquippedAbilityGameTests080.java`
- `src/main/java/com/chaogarden/toys/FloatToyEntity080.java`
- `src/main/java/com/chaogarden/toys/ToyInteractionRules.java`
- `src/main/resources/chao_garden.mixins.json`
- `src/test/java/com/chaogarden/core/EquippedAbility080Test.java`
- `src/test/java/com/chaogarden/core/MechanicsTestSuite.java`
- `src/test/java/com/chaogarden/toys/ToyInteractionRulesTest.java`

Added overlay paths (the ten noted base assets are changes, not newly registered content):

- `scripts/generate_baby_power_084.py`
- `scripts/test_duck_tambourine_assets_02584.py`
- `src/lionfishTest/java/com/chaogarden/client/BabyPowerRigTest084.java`
- `src/main/java/com/chaogarden/ChaoRefreshCommands084.java`
- `src/main/java/com/chaogarden/client/BabyPowerRegionPaint084.java`
- `src/main/java/com/chaogarden/client/FixesVisualSmoke084.java`
- `src/main/java/com/chaogarden/client/PowerRemoteVisualSmoke084.java`
- `src/main/java/com/chaogarden/client/RunVisualSmoke084.java`
- `src/main/java/com/chaogarden/companion/EquippedRun084.java`
- `src/main/java/com/chaogarden/core/BabyPowerMorphology084.java`
- `src/main/java/com/chaogarden/core/EquippedRunRules084.java`
- `src/main/java/com/chaogarden/mixin/EquippedRunFlightMixin084.java`
- `src/main/java/com/chaogarden/mixin/EquippedRunGlideMixin084.java`
- `src/main/java/com/chaogarden/mixin/EquippedRunLocalFlightMixin084.java`
- `src/main/java/com/chaogarden/test/BabyPowerGameTests084.java`
- `src/main/java/com/chaogarden/test/ChaoRefreshGameTests084.java`
- `src/main/java/com/chaogarden/test/EquippedRunGameTests084.java`
- `src/main/java/com/chaogarden/test/FloatToyBumpGameTests084.java`
- `src/main/resources/assets/chao_garden/baby_power084.json`
- `src/main/resources/assets/chao_garden/models/block/chao_rubber_duck_idle.json`
- `src/main/resources/assets/chao_garden/models/block/chao_rubber_duck_play_0.json`
- `src/main/resources/assets/chao_garden/models/block/chao_rubber_duck_play_1.json`
- `src/main/resources/assets/chao_garden/models/block/chao_rubber_duck_play_2.json`
- `src/main/resources/assets/chao_garden/models/block/chao_rubber_duck_play_3.json`
- `src/main/resources/assets/chao_garden/models/sa2_02515/chao_tambourine_idle.obj`
- `src/main/resources/assets/chao_garden/models/sa2_02515/chao_tambourine_play_0.obj`
- `src/main/resources/assets/chao_garden/models/sa2_02515/chao_tambourine_play_1.obj`
- `src/main/resources/assets/chao_garden/models/sa2_02515/chao_tambourine_play_2.obj`
- `src/main/resources/assets/chao_garden/models/sa2_02515/chao_tambourine_play_3.obj`
- `src/main/resources/data/chao_fixes84/structure/activity_test.nbt`
- `src/main/resources/data/chao_run84/structure/activity_test.nbt`
- `src/test/java/com/chaogarden/core/BabyPowerMorphology084Test.java`
- `src/test/java/com/chaogarden/core/EquippedRun084Test.java`

Machine-readable hashes and checks: `production-review084-inventory.json`. The read-only patch of modified inherited source paths against accepted .83 is `production-review084-change.patch`; separately added paths are listed and hashed in the inventory. Neither is a source/package approval seal.
