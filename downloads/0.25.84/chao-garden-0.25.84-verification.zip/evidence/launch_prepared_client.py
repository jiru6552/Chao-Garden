#!/usr/bin/env python3
"""Root-invoked actual launch adapter; not invoked by preparation or this agent.

Checks exact prepared input/runtime bytes, strips all inherited CHAO_* activation
variables, and delegates receipt capture to the existing root-owned .84 runner.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys

def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--plan',type=Path,required=True);a.add_argument('--name',required=True);a.add_argument('--log',type=Path,required=True);a.add_argument('--receipt',type=Path,required=True);args=a.parse_args()
 p=args.plan.resolve();d=json.loads(p.read_text());assert d['status']=='PREPARED_NOT_LAUNCHED'and d['version']=='0.25.84';root=Path(d['project']);client=d['client'];home=Path(client['cwd']);assert home.is_dir()and not(home/'saves').exists(),'Use each freshly prepared game directory only once'
 for n,v in{**d['inputs'],**d['classpath_files'],**client['argument_files']}.items():
  f=Path(n);assert f.is_file()and f.stat().st_size==v['bytes']and sha(f)==v['sha256'],'Prepared input changed: '+n
 freeze_path=Path(d['source_freeze']);assert sha(freeze_path)==d['source_freeze_sha256'];freeze=json.loads(freeze_path.read_text())
 for n,h in freeze['files'].items():assert(root/n).is_file()and sha(root/n)==h,'Frozen runtime changed: '+n
 assert not(root/'build/resources/main/data/minecraft/worldgen/world_preset/flat.json').exists()
 assert not any('gametestdimensions'in n.lower()for n in d['resolved_classpath'])
 env={k:v for k,v in os.environ.items()if not k.startswith('CHAO_')};env.update(client['environment'])
 runner=Path(__file__).with_name('run-command.py');assert runner.is_file()
 command=[sys.executable,str(runner),'--name',args.name,'--cwd',str(home),'--log',str(args.log.resolve()),'--receipt',str(args.receipt.resolve()),'--',*client['command']]
 # Only root explicitly invokes this adapter. exec preserves the wrapper PID;
 # the existing runner records the actual Java child PID, environment and exit.
 os.execve(sys.executable,command,env)
if __name__=='__main__':main()
