package com.chaogarden.test;

import com.chaogarden.ChaoGarden;
import com.chaogarden.core.AnalyzerStatRules;
import com.chaogarden.core.ChaoState;
import com.chaogarden.core.DriveRules;
import com.chaogarden.core.HeroRunMorphology052;
import com.chaogarden.core.HeroPowerMorphology067;
import com.chaogarden.core.NeutralMorphology056;
import com.chaogarden.care.ChaoCareNetwork;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import com.chaogarden.entity.ChaoEntity;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HexFormat;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Authoritative saved Hero/Power identity and actual training routes.
 * This suite proves server policy/transport, not visual quality or elapsed life timing. */
@GameTestHolder("chao_hero_power67") @PrefixGameTestTemplate(false)
public final class HeroPowerMorphologyGameTests067 {
  private static final String TEMPLATE="chao_morph54:activity_test";
  private static final BlockPos AT=new BlockPos(3,2,3);
  private HeroPowerMorphologyGameTests067() {}

  @GameTestGenerator public static Collection<TestFunction> cases(){
    var tests=new ArrayList<TestFunction>();
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++)for(int age=0;age<=2;age++){
      int r=rp,f=sf,a=age;add(tests,"hero_power_grid_"+(rp+1)+"_"+(sf+1)+"_age_"+(age*50),h->grid(h,r,f,a));
    }
    add(tests,"natural_power_first_evolution_then_real_run_drives",HeroPowerMorphologyGameTests067::firstEvolution);
    for(int stat=0;stat<4;stat++){int selected=stat;add(tests,"earned_first_type_and_latest_ties_"+stat,h->otherFirstType(h,selected));}
    for(int stat=0;stat<4;stat++){int selected=stat;add(tests,"ordinary_combined_and_analyzer_route_"+stat,h->mutationRoutes(h,selected));}
    add(tests,"combined_balanced_gain_and_real_reversal",HeroPowerMorphologyGameTests067::opposition);
    add(tests,"compatible_stat_order_is_not_a_new_form",HeroPowerMorphologyGameTests067::commutative);
    add(tests,"hero_power_adult_identity_remains_locked",HeroPowerMorphologyGameTests067::locked);
    add(tests,"completed_hero_fly_family_is_preserved",HeroPowerMorphologyGameTests067::hero);
    add(tests,"existing_neutral_normal_path_remains_separate",HeroPowerMorphologyGameTests067::neutralRegression);
    add(tests,"completed_neutral_fly_first_policy_is_unchanged",HeroPowerMorphologyGameTests067::flyRegression);
    add(tests,"completed_neutral_run_first_policy_is_unchanged",HeroPowerMorphologyGameTests067::runRegression);
    add(tests,"actual_native_selection_and_invalid_edits_are_readonly",HeroPowerMorphologyGameTests067::selectionFailures);
    add(tests,"actual_native_commands_keep_hero_power_identity",HeroPowerMorphologyGameTests067::commands);
    add(tests,"actual_maturity_payload_keeps_adult_identity",HeroPowerMorphologyGameTests067::maturityPayload);
    add(tests,"actual_analyzer_permissions_and_locked_alignment",HeroPowerMorphologyGameTests067::analyzerPayload);
    add(tests,"named_jewel_and_shiny_inputs_do_not_change_form",HeroPowerMorphologyGameTests067::colors);
    add(tests,"literal_existing_neutral_world_stays_neutral",h->legacy(h,false));
    add(tests,"synthetic_expanded_care21_hero_power_migration",h->legacy(h,true));
    add(tests,"all_actual_combined_drive_tiers_preserve_hero_power",HeroPowerMorphologyGameTests067::allCombinedTiers);
    add(tests,"completed_neutral_power_first_policy_is_unchanged",HeroPowerMorphologyGameTests067::powerRegression);
    add(tests,"latest_completed_hero_swim_family_is_preserved",HeroPowerMorphologyGameTests067::heroSwimRegression);
    add(tests,"approved_baby_052_policy_stays_separate",HeroPowerMorphologyGameTests067::baby);
    add(tests,"completed_hero_run066_family_is_preserved",HeroPowerMorphologyGameTests067::heroRunRegression);
    // Actual server offer/hold/commit paths cross both current-bar thresholds.
    tests.add(new TestFunction("hero_power067_"+(tests.size()/8),
        "actual_held_run_drive_crosses_power_first_threshold",TEMPLATE,180,0,true,h->heldDrive(h,ChaoState.RUN)));
    tests.add(new TestFunction("hero_power067_"+(tests.size()/8),
        "actual_held_swim_drive_crosses_compatible_threshold",TEMPLATE,180,0,true,h->heldDrive(h,ChaoState.SWIM)));
    return tests;
  }
  private static void add(List<TestFunction> tests,String name,java.util.function.Consumer<GameTestHelper> body){
    tests.add(new TestFunction("hero_power067_"+(tests.size()/8),name,TEMPLATE,40,0,true,body));
  }
  private static void cleanup(GameTestHelper h,Runnable action){
    h.testInfo.addListener(new GameTestListener(){
      public void testStructureLoaded(GameTestInfo i){}
      public void testPassed(GameTestInfo i,GameTestRunner r){action.run();}
      public void testFailed(GameTestInfo i,GameTestRunner r){action.run();}
      public void testAddedForRerun(GameTestInfo a,GameTestInfo b,GameTestRunner r){action.run();}
    });
  }
  private static ChaoState adult(){
    var s=new ChaoState();s.adult=true;s.primaryType=ChaoState.POWER_TYPE;s.align=1;s.ageTicks=2345;s.adultAgeTicks=432;
    s.hunger=80;s.energy=100;s.happiness=70;s.setEvolutionStrength(1.2f);s.setTrait("hero_power67.foreign","preserve unrelated earned data");
    return ChaoState.decode(s.encode());
  }
  private static ChaoEntity actor(GameTestHelper h,ChaoState s){
    for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)h.setBlock(AT.offset(x,-1,z),Blocks.STONE);
    var c=ChaoGarden.CHAO.get().create(h.getLevel());h.assertTrue(c!=null,"Production Chao entity creates");
    c.owner=UUID.fromString("06700000-0000-0000-0000-000000000067");c.setState(s);c.setNoAi(true);c.setNoGravity(true);
    c.moveTo(Vec3.atBottomCenterOf(h.absolutePos(AT)));h.getLevel().addFreshEntity(c);cleanup(h,c::discard);return c;
  }
  private static void axis(ChaoState s,int rp,int sf){
    for(int stat=0;stat<4;stat++)DriveRules.setTotal(s,stat,0,new Random(64));
    if(rp!=0)DriveRules.setTotal(s,rp>0?ChaoState.POWER:ChaoState.RUN,Math.abs(rp),new Random(64));
    if(sf!=0)DriveRules.setTotal(s,sf>0?ChaoState.FLY:ChaoState.SWIM,Math.abs(sf),new Random(64));
  }
  private static void near(GameTestHelper h,float actual,float expected,String why){h.assertTrue(Float.isFinite(actual)&&Math.abs(actual-expected)<.00001f,why+": "+actual+" vs "+expected);}
  private static void syncAndNbt(GameTestHelper h,ChaoEntity c){
    c.sync();String encoded=c.state().encode();var input=HeroPowerMorphology067.sample(c.state());
    var updates=c.getEntityData().getNonDefaultValues();
    h.assertTrue(updates!=null&&updates.stream().anyMatch(v->v.value() instanceof String s&&s.equals(encoded)),"Entity synchronization carries complete authoritative age/training/identity data");
    var observer=ChaoGarden.CHAO.get().create(h.getLevel());observer.getEntityData().assignValues(updates);
    h.assertTrue(observer.getEntityData().getNonDefaultValues().stream().anyMatch(v->v.value() instanceof String s&&s.equals(encoded)),"Observer receives exactly the same authoritative serialized record");
    var tag=new CompoundTag();c.saveWithoutId(tag);var restored=ChaoGarden.CHAO.get().create(h.getLevel());restored.load(tag);
    h.assertTrue(restored.state().encode().equals(encoded)&&restored.owner.equals(c.owner)&&restored.getUUID().equals(c.getUUID()),"Real entity NBT retains saved data, UUID and owner");
    h.assertTrue(HeroPowerMorphology067.sample(restored.state()).equals(input),"Reload computes the same independent Hero Power morphology inputs");
    observer.discard();restored.discard();
  }
  private static void grid(GameTestHelper h,int rp,int sf,int age){
    var s=adult();axis(s,rp*960,sf*960);s.setEvolutionStrength(age*.6f);var c=actor(h,s);String encoded=s.encode();
    var p=HeroPowerMorphology067.sample(s);h.assertTrue(p.enabled(),"Each of the nine requested Hero Power combinations uses the new path");
    near(h,p.runPower(),rp,"Run/Power influence reads current opposing bar totals");near(h,p.swimFly(),sf,"Swim/Fly remains a separate compatible axis");near(h,p.maturity(),age*.5f,"Young/intermediate/mature states share independent biological age");
    var weights=HeroPowerMorphology067.weights(p);float sum=0;for(float w:weights){h.assertTrue(Float.isFinite(w)&&w>=0&&w<=1,"Shape weights stay finite and convex");sum+=w;}
    near(h,sum,1,"The complete corner mix has unit mass");near(h,weights[0],1-age*.5f,"A trained young adult cannot jump directly to the mature form");
    near(h,weights[1+(sf+1)*3+(rp+1)],age*.5f,"Only the correct mature corner develops at a grid endpoint");
    h.assertTrue(encoded.equals(s.encode()),"Sampling the renderer inputs has no saved-state side effects");syncAndNbt(h,c);h.succeed();
  }
  private static void firstEvolution(GameTestHelper h){
    var s=new ChaoState();s.align=.8f;s.ageTicks=19;s.points[ChaoState.STAMINA]=9999;s.intelligence=4000;s.luck=4000;s.train(ChaoState.POWER,960,new Random(67));
    h.assertTrue(s.tick(20,100000,new Random(67))==ChaoState.Transition.EVOLVED,"Real trained first Power cocoon completes");
    h.assertTrue(s.adult&&!s.immortal&&s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==.8f,"Hero Power is selected naturally from earned points");
    var p=HeroPowerMorphology067.sample(s);h.assertTrue(p.enabled(),"Natural first Power enters its scoped path");near(h,p.runPower(),1,"Baby Power carries into adult targeting");near(h,p.swimFly(),0,"First Power invents no Fly/Swim training");near(h,p.maturity(),0,"First evolution starts young despite carried training");
    while(s.cocoonTicks>0)s.tick(20,100000,new Random(67));
    for(int i=0;i<40;i++)s.giveDrive(ChaoState.RUN);near(h,HeroPowerMorphology067.sample(s).runPower(),0,"Opposite Run first cancels carried Power to balance");
    for(int i=0;i<40;i++)s.giveDrive(ChaoState.RUN);near(h,HeroPowerMorphology067.sample(s).runPower(),-1,"Excess Run develops the negative secondary influence");
    h.assertTrue(s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==.8f,"Crossing Power to Run keeps locked Hero Power identity");syncAndNbt(h,actor(h,s));h.succeed();
  }
  private static void otherFirstType(GameTestHelper h,int stat){
    var s=new ChaoState();s.ageTicks=19;s.align=1;s.points[stat]=100;s.levels[(stat+1)%4]=99;s.points[ChaoState.STAMINA]=9999;s.intelligence=4000;s.luck=4000;
    h.assertTrue(s.tick(20,100000,new Random(64))==ChaoState.Transition.EVOLVED&&s.lockedPrimaryType()==stat+1,"Highest earned points select first type, excluding Stamina and unrelated higher levels");
    h.assertTrue(HeroPowerMorphology067.sample(s).enabled()==(stat==ChaoState.POWER),"Only the requested Hero Power-first form selects the new renderer");
    for(int earlier=0;earlier<4;earlier++)if(earlier!=stat){var tied=new ChaoState();tied.align=1;tied.train(earlier,1);tied.train(stat,1);tied.points[earlier]=tied.points[stat]=100;tied.points[ChaoState.STAMINA]=9999;tied=ChaoState.decode(tied.encode());tied.ageTicks=19;tied.tick(20,100000,new Random(64));h.assertTrue(tied.lockedPrimaryType()==stat+1,"Actual tied first evolution follows latest raised tied skill after reload");}
    syncAndNbt(h,actor(h,s));h.succeed();
  }
  private static void mutationRoutes(GameTestHelper h,int stat){
    var direct=adult();var ordinary=adult();var combined=adult();var analyzer=adult();
    direct.train(stat,240,new Random(64));for(int i=0;i<10;i++)ordinary.giveDrive(stat);
    h.assertTrue(DriveRules.apply(combined,DriveRules.Tier.SOLID,stat,new Random(64)),"Actual typed combined drive applies");DriveRules.change(combined,stat,140,new Random(64));
    AnalyzerStatRules.apply(analyzer,stat,AnalyzerStatRules.LEVEL,1);AnalyzerStatRules.apply(analyzer,stat,AnalyzerStatRules.LEVEL,1);AnalyzerStatRules.apply(analyzer,stat,AnalyzerStatRules.PROGRESS,40);
    var expected=HeroPowerMorphology067.sample(direct);
    h.assertTrue(expected.equals(HeroPowerMorphology067.sample(ordinary))&&expected.equals(HeroPowerMorphology067.sample(combined))&&expected.equals(HeroPowerMorphology067.sample(analyzer)),"Ordinary, typed combined, direct and Creative training all derive identical morphology from equal current totals");
    near(h,stat<2?expected.swimFly():expected.runPower(),stat==ChaoState.SWIM||stat==ChaoState.RUN?-.25f:.25f,"Correct independent axis expresses the actual training");
    int age=analyzer.ageTicks,adultAge=analyzer.adultAgeTicks;float maturity=analyzer.evolutionStrength();
    AnalyzerStatRules.apply(analyzer,stat,AnalyzerStatRules.PROGRESS,0);AnalyzerStatRules.apply(analyzer,stat,AnalyzerStatRules.LEVEL,-1);
    var reduced=HeroPowerMorphology067.sample(analyzer);near(h,Math.abs(stat<2?reduced.swimFly():reduced.runPower()),100f/960,"Creative level/progress decreases recede this same current-state input");
    h.assertTrue(analyzer.ageTicks==age&&analyzer.adultAgeTicks==adultAge&&analyzer.evolutionStrength()==maturity,"Stat editing does not rewrite chronological age/maturity");
    syncAndNbt(h,actor(h,analyzer));h.succeed();
  }
  private static void opposition(GameTestHelper h){
    var s=adult();axis(s,960,960);s.setEvolutionStrength(.6f);int age=s.ageTicks,adultAge=s.adultAgeTicks;float maturity=s.evolutionStrength();String lineage=s.lineageId();
    h.assertTrue(DriveRules.apply(s,DriveRules.Tier.CHAOTIC,-1,new Random(64)),"Balanced four-stat drive applies");near(h,HeroPowerMorphology067.sample(s).runPower(),1,"Balanced combined drive preserves Power advantage");near(h,HeroPowerMorphology067.sample(s).swimFly(),1,"Balanced combined drive preserves Fly advantage");
    for(int i=0;i<80;i++){
      s.giveDrive(ChaoState.RUN);var p=HeroPowerMorphology067.sample(s);
      near(h,p.runPower(),Math.clamp((960-(i+1)*24)/960f,-1,1),"Opposing Run crosses Power through balance and develops the opposite specialization");near(h,p.swimFly(),1,"Compatible Fly survives the full opposite-Run transition");
      h.assertTrue(s.ageTicks==age&&s.adultAgeTicks==adultAge&&s.evolutionStrength()==maturity&&s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==1&&s.lineageId().equals(lineage),"Opposite Run cannot change age, lineage or first evolution identity");
    }
    for(int i=0;i<80;i++){
      s.giveDrive(ChaoState.SWIM);var p=HeroPowerMorphology067.sample(s);near(h,p.swimFly(),Math.clamp((960-(i+1)*24)/960f,-1,1),"Opposing Swim crosses Fly through balance into Swim");near(h,p.runPower(),-1,"Run survives the other independent signed axis");
    }
    near(h,HeroPowerMorphology067.weights(HeroPowerMorphology067.sample(s))[1],.5f,"Half-mature Run/Swim uses its own shared corner rather than being clamped or re-evolved");
    // Chaotic added an equal baseline to all bars; remove full opponent gains,
    // leaving that equal baseline and the original Power/Fly advantage intact.
    DriveRules.change(s,ChaoState.RUN,-1920,new Random(64));DriveRules.change(s,ChaoState.SWIM,-1920,new Random(64));
    near(h,HeroPowerMorphology067.sample(s).runPower(),1,"Run reductions recover the saved Power advantage");near(h,HeroPowerMorphology067.sample(s).swimFly(),1,"Swim reductions restore later Fly independently");
    h.assertTrue(s.ageTicks==age&&s.adultAgeTicks==adultAge&&s.evolutionStrength()==maturity&&s.lockedPrimaryType()==ChaoState.POWER_TYPE,"Reversal preserves both age inputs and first identity");syncAndNbt(h,actor(h,s));h.succeed();
  }
  private static void commutative(GameTestHelper h){
    for(int a:new int[]{ChaoState.RUN,ChaoState.POWER})for(int b:new int[]{ChaoState.FLY,ChaoState.SWIM}){
      var first=adult();var reverse=adult();for(int i=0;i<40;i++)first.giveDrive(a);for(int i=0;i<40;i++)first.giveDrive(b);
      for(int i=0;i<40;i++)reverse.giveDrive(b);for(int i=0;i<40;i++)reverse.giveDrive(a);
      h.assertTrue(HeroPowerMorphology067.sample(first).equals(HeroPowerMorphology067.sample(reverse)),"Compatible pair order does not create a separate form");
      h.assertTrue(first.lockedPrimaryType()==ChaoState.POWER_TYPE&&reverse.lockedPrimaryType()==ChaoState.POWER_TYPE,"Later recency cannot rewrite either saved first identity");
    }h.succeed();
  }
  private static void locked(GameTestHelper h){
    var s=adult();axis(s,-960,960);var before=HeroPowerMorphology067.sample(s);s.align=-1;s.primaryType=ChaoState.RUN_TYPE;
    h.assertTrue(HeroPowerMorphology067.sample(s).equals(before),"Renderer reads the saved adult identity despite stale public field edits");
    s=ChaoState.decode(s.encode());h.assertTrue(s.align==1&&s.primaryType==ChaoState.POWER_TYPE,"Reload/normalization preserves original Hero alignment and Power first type");syncAndNbt(h,actor(h,s));h.succeed();
  }
  private static void hero(GameTestHelper h){
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++)for(float age:new float[]{0,.5f,1}){
      var s=new ChaoState();s.adult=true;s.primaryType=ChaoState.FLY_TYPE;s.align=1;s.ageTicks=1000;s.adultAgeTicks=300;s.setEvolutionStrength(age*1.2f);s=ChaoState.decode(s.encode());axis(s,rp*960,sf*960);
      var p=com.chaogarden.core.HeroFlyMorphology065.sample(s);h.assertTrue(p.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Completed Hero Fly retains its own production policy");near(h,p.maturity(),age,"Previous Hero Fly age exact");near(h,p.runPower(),rp,"Previous Hero Fly Run/Power exact");near(h,p.swimFly(),sf,"Previous Hero Fly Swim/Fly exact");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void heroRunRegression(GameTestHelper h){
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++)for(float age:new float[]{0,.5f,1}){
      var s=new ChaoState();s.adult=true;s.primaryType=ChaoState.RUN_TYPE;s.align=1;s.ageTicks=1000;s.adultAgeTicks=300;s.setEvolutionStrength(age*1.2f);s=ChaoState.decode(s.encode());axis(s,rp*960,sf*960);
      String encoded=s.encode();var old=com.chaogarden.core.HeroRunMorphology066.sample(s);
      h.assertTrue(old.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Completed Hero Run066 uses its own renderer policy");near(h,old.maturity(),age,"Previous Hero Run age exact");near(h,old.runPower(),rp,"Previous Hero Run signed Run/Power exact");near(h,old.swimFly(),sf,"Previous Hero Run signed Swim/Fly exact");h.assertTrue(s.encode().equals(encoded),"New Power sampling cannot mutate existing Hero Run data");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void neutralRegression(GameTestHelper h){
    var s=new ChaoState();s.adult=true;s.primaryType=ChaoState.NORMAL;s.align=0;s.setEvolutionStrength(.6f);s=ChaoState.decode(s.encode());axis(s,-960,960);
    var p=NeutralMorphology056.sample(s);h.assertTrue(p.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Existing Neutral Normal path remains independently selected");near(h,p.maturity(),.5f,"Neutral maturity unchanged");near(h,p.runPower(),-1,"Neutral Run influence unchanged");near(h,p.swimFly(),1,"Neutral compatible Fly unchanged");syncAndNbt(h,actor(h,s));h.succeed();
  }
  private static void flyRegression(GameTestHelper h){
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++){
      var s=new ChaoState();s.adult=true;s.align=0;s.primaryType=ChaoState.FLY_TYPE;s.setEvolutionStrength(.6f);s=ChaoState.decode(s.encode());axis(s,rp*960,sf*960);
      var p=com.chaogarden.core.NeutralFlyMorphology061.sample(s);h.assertTrue(p.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Completed Neutral Fly-first stays on its own renderer policy");near(h,p.maturity(),.5f,"Existing Fly-first age unchanged");near(h,p.runPower(),rp,"Existing signed Fly-first Run/Power unchanged");near(h,p.swimFly(),sf,"Neutral Fly-first retains its complete signed Swim/Fly coordinate");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void runRegression(GameTestHelper h){
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++){
      var s=new ChaoState();s.adult=true;s.align=0;s.primaryType=ChaoState.RUN_TYPE;s.setEvolutionStrength(.6f);s=ChaoState.decode(s.encode());axis(s,rp*960,sf*960);
      var p=com.chaogarden.core.NeutralRunMorphology062.sample(s);h.assertTrue(p.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Completed Neutral Run-first stays on its own renderer policy");near(h,p.maturity(),.5f,"Existing Run-first age remains exact");near(h,p.runPower(),rp,"Existing signed Run-first Run/Power remains exact");near(h,p.swimFly(),sf,"Existing signed Run-first Swim/Fly remains exact");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void allCombinedTiers(GameTestHelper h){
    for(var tier:DriveRules.Tier.values())for(int selected=0;selected<4;selected++){
      var s=adult();axis(s,480,-240);int chronology=s.ageTicks,adultAge=s.adultAgeTicks;float age=s.evolutionStrength();String lineage=s.lineageId();
      h.assertTrue(DriveRules.apply(s,tier,DriveRules.typed(tier)?selected:-1,new Random(6400+tier.ordinal()*4+selected)),"Real combined drive tier applies: "+tier);
      var input=HeroPowerMorphology067.sample(s);
      near(h,input.runPower(),Math.clamp((DriveRules.total(s,ChaoState.POWER)-DriveRules.total(s,ChaoState.RUN))/960f,-1,1),"Each actual tier derives Run/Power from current bars");
      near(h,input.swimFly(),Math.clamp((DriveRules.total(s,ChaoState.FLY)-DriveRules.total(s,ChaoState.SWIM))/960f,-1,1),"Each actual tier derives full signed Swim/Fly from current bars");
      h.assertTrue(s.ageTicks==chronology&&s.adultAgeTicks==adultAge&&s.evolutionStrength()==age&&s.lineageId().equals(lineage)&&s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==1,"Combined tier changes no lifetime or saved Hero Power identity");
      syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void powerRegression(GameTestHelper h){
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++){
      var s=new ChaoState();s.adult=true;s.align=0;s.primaryType=ChaoState.POWER_TYPE;s.setEvolutionStrength(.6f);s=ChaoState.decode(s.encode());axis(s,rp*960,sf*960);
      var old=com.chaogarden.core.NeutralPowerMorphology063.sample(s);h.assertTrue(old.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Latest delivered Neutral Power-first remains separately selected");
      near(h,old.maturity(),.5f,"Previous Power maturity unchanged");near(h,old.runPower(),rp,"Previous Power Run/Power unchanged");near(h,old.swimFly(),sf,"Previous Power Swim/Fly unchanged");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void heroSwimRegression(GameTestHelper h){
    for(int rp=-1;rp<=1;rp++)for(int sf=-1;sf<=1;sf++)for(float age:new float[]{0,.5f,1}){
      var s=new ChaoState();s.adult=true;s.align=1;s.primaryType=ChaoState.SWIM_TYPE;s.setEvolutionStrength(age*1.2f);s=ChaoState.decode(s.encode());axis(s,rp*960,sf*960);
      String saved=s.encode();var old=com.chaogarden.core.HeroSwimMorphology064.sample(s);
      h.assertTrue(old.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Delivered Hero Swim stays separately selected");
      near(h,old.maturity(),age,"Existing Hero Swim age remains independent");near(h,old.runPower(),rp,"Existing Hero Swim signed Run/Power remains exact");near(h,old.swimFly(),sf,"Existing Hero Swim signed Swim/Fly remains exact");
      h.assertTrue(saved.equals(s.encode()),"New-family sampling is read-only for existing Hero Swim saves");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void selectionFailures(GameTestHelper h){
    var c=actor(h,adult());String name="HeroPower67 duplicate "+UUID.randomUUID();c.setCustomName(Component.literal(name));var p=creative(h,c);
    var duplicate=actor(h,adult());duplicate.setCustomName(Component.literal(name));duplicate.moveTo(c.getX()+6,c.getY(),c.getZ());String before=c.state().encode(),other=duplicate.state().encode();
    h.assertTrue(command(p,c,"100 Run 10")==0,"Actual ambiguous loaded name refuses to select the first Run Chao");
    p.teleportTo(c.getX()+3,c.getY(),c.getZ());
    h.assertTrue(com.chaogarden.EditingCommands056.edit(p.createCommandSourceStack().withPermission(0),"~",100,"Run",10)==0,"Equally near Hero Power Chao are rejected rather than chosen by entity order");
    p.teleportTo(c.getX()+1,c.getY(),c.getZ());
    var source=p.createCommandSourceStack().withPermission(0);
    h.assertTrue(com.chaogarden.EditingCommands056.edit(source,"missing "+UUID.randomUUID(),100,"Run",10)==0,"Missing loaded name is rejected");
    h.assertTrue(com.chaogarden.EditingCommands056.edit(source,"",100,"Run",10)==0,"Empty target is rejected");
    duplicate.setCustomName(Component.literal("OtherHeroPower67 "+UUID.randomUUID()));
    for(String arguments:List.of("100 Unknown 10","101 Run 10","100 Run 100","100 Run -1")){
      boolean denied=false;try{denied=p.server.getCommands().getDispatcher().execute("chao \""+c.getName().getString()+"\" "+arguments,source)==0;}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){denied=true;}
      h.assertTrue(denied,"Invalid native argument is rejected: "+arguments);
    }
    p.teleportTo(c.getX(),c.getY()+200,c.getZ());
    h.assertTrue(com.chaogarden.EditingCommands056.edit(p.createCommandSourceStack().withPermission(0),"~",100,"Run",10)==0,"Nearest target refuses when no Chao is within 12 blocks");
    h.assertTrue(c.state().encode().equals(before)&&duplicate.state().encode().equals(other),"Ambiguous/missing/invalid edits change neither Hero Power Chao");
    p.teleportTo(c.getX()+1,c.getY(),c.getZ());p.setGameMode(GameType.SURVIVAL);
    try{h.assertTrue(p.server.getCommands().getDispatcher().execute("chao \""+c.getName().getString()+"\" 100 Power 5",p.createCommandSourceStack().withPermission(2))==1,"A Survival operator at permission2 can perform the intended admin test edit");}catch(com.mojang.brigadier.exceptions.CommandSyntaxException invalid){throw new IllegalStateException(invalid);}
    h.assertTrue(c.state().lockedPrimaryType()==ChaoState.POWER_TYPE&&c.state().lockedAlignment()==1,"Authorized admin edit retains the locked Hero Power identity");near(h,HeroPowerMorphology067.sample(c.state()).runPower(),500f/960,"Admin edit reaches current-bar morphology");
    syncAndNbt(h,c);h.succeed();
  }
  private static ServerPlayer creative(GameTestHelper h,ChaoEntity c){
    var p=TestConnections.makeSurvivalServerPlayer(h);p.setGameMode(GameType.CREATIVE);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(ChaoGarden.item("chao_analyzer")));
    c.owner=p.getUUID();p.teleportTo(c.getX()+1,c.getY(),c.getZ());
    cleanup(h,()->{if(p.server.getPlayerList().getPlayer(p.getUUID())==p)p.server.getPlayerList().remove(p);});return p;
  }
  private static int command(ServerPlayer p,ChaoEntity c,String arguments){
    try{return p.server.getCommands().getDispatcher().execute("chao \""+c.getName().getString()+"\" "+arguments,p.createCommandSourceStack().withPermission(0));}
    catch(com.mojang.brigadier.exceptions.CommandSyntaxException e){throw new IllegalStateException(e);}
  }
  private static void commands(GameTestHelper h){
    var c=actor(h,adult());c.setCustomName(Component.literal("HeroPower67 "+UUID.randomUUID()));var p=creative(h,c);var s=c.state();
    var decoy=actor(h,adult());decoy.setCustomName(Component.literal("OtherHeroPower67 "+UUID.randomUUID()));decoy.moveTo(c.getX()+6,c.getY(),c.getZ());String untouched=decoy.state().encode();
    for(int alignment:new int[]{-100,0}){String before=s.encode();h.assertTrue(command(p,c,alignment+" Run 99")==0&&s.encode().equals(before),"Native command rejects conflicting locked adult alignment atomically");}
    for(String stat:List.of("Power","Fly"))h.assertTrue(command(p,c,"100 "+stat+" 10")==1,"Actual Creative command accepts locked Hero alignment and selected stat");
    var a=HeroPowerMorphology067.sample(s);near(h,a.runPower(),1,"Actual command Power drives current morphology");near(h,a.swimFly(),1,"Actual compatible Fly shares same corner");
    h.assertTrue(s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==1&&s.adult,"Command preserves Hero Power-first identity");
    int chronological=s.adultAgeTicks;h.assertTrue(command(p,c,"100 Power 0")==1,"Actual command reduces stat");near(h,HeroPowerMorphology067.sample(s).runPower(),0,"Command reduction recedes Power");near(h,HeroPowerMorphology067.sample(s).swimFly(),1,"Independent Fly survives");
    h.assertTrue(decoy.state().encode().equals(untouched),"Quoted native name selection changes only the intended Power-first adult");
    try{
      h.assertTrue(p.server.getCommands().getDispatcher().execute("chao ~ 100 Run 10",p.createCommandSourceStack().withPermission(0))==1,"Nearest selector accepts the actual nearby Power-first adult");
      h.assertTrue(p.server.getCommands().getDispatcher().execute("chao ~ 100 Swim 20",p.createCommandSourceStack().withPermission(0))==1,"Native excess opposing Swim command applies to current bars");
    }catch(com.mojang.brigadier.exceptions.CommandSyntaxException invalid){throw new IllegalStateException(invalid);}
    near(h,HeroPowerMorphology067.sample(s).runPower(),-1,"Nearest native edit develops Run independently");near(h,HeroPowerMorphology067.sample(s).swimFly(),-1,"Excess Swim develops the opposite signed secondary axis");
    h.assertTrue(s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.typeName().equals("Power/Swim+Run")&&decoy.state().encode().equals(untouched),"Opposing nearest edit preserves first Power identity and the other loaded Chao");
    var beforeHidden=HeroPowerMorphology067.sample(s);
    h.assertTrue(command(p,c,"100 Intelligence 99")==1&&command(p,c,"100 Luck 99")==1,"Native hidden-stat commands use their existing0..99level units");
    h.assertTrue(s.hiddenLevels[ChaoState.HIDDEN_INTELLIGENCE]==99&&s.hiddenLevels[ChaoState.HIDDEN_LUCK]==99&&s.intelligence<=4000&&s.luck<=4000&&HeroPowerMorphology067.sample(s).equals(beforeHidden),"Hidden earned points remain separate0..4000values and change no Hero Power morphology axes");
    String before=s.encode();p.setGameMode(GameType.SURVIVAL);boolean denied=false;try{int result=p.server.getCommands().getDispatcher().execute("chao \""+c.getName().getString()+"\" 100 Power 99",p.createCommandSourceStack().withPermission(0));denied=result==0;}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){denied=true;}
    h.assertTrue(denied&&s.encode().equals(before),"Survival without admin permission cannot mutate through command dispatcher");
    h.assertTrue(s.adultAgeTicks==chronological&&s.evolutionStrength()==1.2f,"Command never changes chronology or biological growth");syncAndNbt(h,c);h.succeed();
  }
  private static void maturityPayload(GameTestHelper h){
    var c=actor(h,adult());var p=creative(h,c);var s=c.state();axis(s,-960,960);int calendar=s.ageTicks,life=s.adultAgeTicks;
    h.assertTrue(ChaoCareNetwork.editMaturity(p,new ChaoCareNetwork.MaturityEdit(c.getUUID().toString(),250)),"Real Creative Analyzer maturity handler accepts the younger growth fraction");
    var a=HeroPowerMorphology067.sample(s);near(h,a.maturity(),.25f,"Authoritative maturity controls Hero Power growth");near(h,a.runPower(),-1,"Maturity does not erase Run training");near(h,a.swimFly(),1,"Maturity does not erase compatible Fly training");
    h.assertTrue(s.ageTicks==calendar&&s.adultAgeTicks==life&&s.adult&&!s.dead&&s.cocoonTicks==0&&s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==1,"Maturity drag changes neither lifetime nor first identity and cannot invoke a cocoon");
    String before=s.encode();p.setGameMode(GameType.SURVIVAL);h.assertFalse(ChaoCareNetwork.editMaturity(p,new ChaoCareNetwork.MaturityEdit(c.getUUID().toString(),1000)),"Survival remains unable to edit Hero Power growth");h.assertTrue(s.encode().equals(before),"Denied maturity request is read-only");
    p.setGameMode(GameType.CREATIVE);h.assertTrue(ChaoCareNetwork.editMaturity(p,new ChaoCareNetwork.MaturityEdit(c.getUUID().toString(),1000)),"Full adult growth can be restored without new first evolution");near(h,HeroPowerMorphology067.sample(s).maturity(),1,"Mature target restores independently");syncAndNbt(h,c);h.succeed();
  }
  private static void analyzerPayload(GameTestHelper h){
    var c=actor(h,adult());var p=creative(h,c);var s=c.state();String before=s.encode();
    for(int alignment:new int[]{-100,100})h.assertFalse(ChaoCareNetwork.editAlignment(p,new ChaoCareNetwork.AlignmentEdit(c.getUUID().toString(),alignment)),"Creative alignment remains read-only after first evolution");
    h.assertTrue(s.encode().equals(before),"Denied alignment cannot rewrite first Power identity");
    h.assertTrue(ChaoCareNetwork.editStats(p,new ChaoCareNetwork.StatEdit(c.getUUID().toString(),ChaoState.FLY,AnalyzerStatRules.LEVEL,10)),"Actual Creative Analyzer stat payload updates current bars");near(h,HeroPowerMorphology067.sample(s).swimFly(),1,"Analyzer payload reaches current later Fly influence");
    before=s.encode();p.setGameMode(GameType.SURVIVAL);h.assertFalse(ChaoCareNetwork.editStats(p,new ChaoCareNetwork.StatEdit(c.getUUID().toString(),ChaoState.RUN,AnalyzerStatRules.LEVEL,99)),"Survival modified client cannot use stat payload");h.assertFalse(ChaoCareNetwork.editAlignment(p,new ChaoCareNetwork.AlignmentEdit(c.getUUID().toString(),100)),"Survival modified client cannot use alignment payload");h.assertTrue(s.encode().equals(before),"Denied Analyzer edits remain read-only");syncAndNbt(h,c);h.succeed();
  }
  private static void colors(GameTestHelper h){
    var s=adult();axis(s,-960,480);var reference=HeroPowerMorphology067.sample(s);
    for(int color=0;color<ChaoState.COLORS.length;color++)for(boolean shine:new boolean[]{false,true})for(boolean tone:new boolean[]{false,true}){
      s.expressedColor=color;s.shiny=shine;s.twoTone=tone;h.assertTrue(HeroPowerMorphology067.sample(s).equals(reference),"Color, one/two-tone and shiny choices share the exact same shape inputs");
    }
    for(int jewel=0;jewel<ChaoState.JEWELS.length;jewel++){s.expressedJewel=jewel;h.assertTrue(HeroPowerMorphology067.sample(s).equals(reference),"Jewel finish never changes the Hero Power morphology");}
    syncAndNbt(h,actor(h,s));h.succeed();
  }
  /** A genuine old Neutral fixture stays literal. The Hero Power migration case is
   * explicitly synthetic: supported expanded-care21 layout + explicitly substituted Hero Power identity.
   * It does not claim that a saved older Hero Power world was located. */
  private static void legacy(GameTestHelper h,boolean synthetic){
    try(var input=HeroPowerMorphologyGameTests067.class.getResourceAsStream("/data/chao_morph52/legacy_states.json")){
      h.assertTrue(input!=null,"Retained historical world data is available");var d=JsonParser.parseReader(new InputStreamReader(input,StandardCharsets.UTF_8)).getAsJsonObject();var fixture=d.getAsJsonArray("states").get(synthetic?1:0).getAsJsonObject();
      String original=fixture.get("encoded").getAsString(),expected=synthetic?"495d2d4175ff38709f5041a3e88d5cd4dde4823c07847a72bb36ef475887692c":"bba10bc1858289535b28f115b2ba03c32c9ecf9e52822e05786c421111d8fdc0";
      h.assertTrue(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(original.getBytes(StandardCharsets.UTF_8))).equals(expected),"Original historical fixture bytes are unchanged");
      String encoded=original;
      if(synthetic){
        String[] fields=original.split(";",-1),axes=fields[13].split(",",-1),extra=fields[21].split(",",-1);
        axes[0]=Float.toHexString(1);fields[13]=String.join(",",axes);String[] values=fields[11].split(",",-1);values[13]=Integer.toString(ChaoState.POWER_TYPE);fields[11]=String.join(",",values);fields[21]=String.join(",",java.util.Arrays.copyOf(extra,21));encoded=String.join(";",fields);
        h.assertTrue(fields[21].split(",",-1).length==21,"Synthetic pre-lock Hero Power care layout is explicit, without first-evolution lock fields");
      }
      var s=ChaoState.decode(encoded);
      h.assertTrue(s.adult&&s.lockedPrimaryType()==(synthetic?ChaoState.POWER_TYPE:ChaoState.NORMAL),"Supported old layout retains the explicitly supplied first identity");
      if(synthetic){h.assertTrue(s.lockedAlignment()==1&&HeroPowerMorphology067.sample(s).enabled(),"Synthetic older Hero Power initializes its existing alignment lock without re-evolution");}
      else{h.assertTrue(s.lockedAlignment()==0&&NeutralMorphology056.sample(s).enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Genuine old Neutral remains Neutral and on the delivered056 path");}
      String normalized=s.encode();var sample=HeroPowerMorphology067.sample(s);h.assertTrue(normalized.equals(s.encode())&&sample.equals(HeroPowerMorphology067.sample(s)),"Repeated sampling changes no migrated saved state");syncAndNbt(h,actor(h,s));h.succeed();
    }catch(Exception e){throw new IllegalStateException("Cannot exercise supported saved layout",e);}
  }

  private static void baby(GameTestHelper h){
    for(float align:new float[]{0,.5f,1})for(float age:new float[]{0,.5f,.99f})for(int run:new int[]{0,240,480}){
      var s=new ChaoState();s.align=align;s.setEvolutionStrength(age);DriveRules.setTotal(s,ChaoState.RUN,run,new Random(66));
      s.setTrait("hero_power67.baby_sync_fixture","non-default transport witness");String encoded=s.encode();
      var p=HeroRunMorphology052.sample(s);h.assertTrue(p.enabled()&&!HeroPowerMorphology067.sample(s).enabled(),"Baby stays on approved052/055 policy");near(h,p.babyGrowth(),Math.min(1,run/480f)*age,"Baby training times age remains exact");
      h.assertTrue(s.encode().equals(encoded),"Adult sampling mutates no baby state");syncAndNbt(h,actor(h,s));
    }h.succeed();
  }
  private static void heldDrive(GameTestHelper h,int stat){
    var s=adult();s.hunger=70;s.setEvolutionStrength(.9f);axis(s,stat==ChaoState.RUN?-470:0,stat==ChaoState.SWIM?-470:0);
    var p=h.makeMockPlayer(GameType.SURVIVAL);p.getAbilities().instabuild=false;var c=actor(h,s);c.owner=p.getUUID();
    var drive=new ItemStack(ChaoGarden.item(stat==ChaoState.RUN?"run_drive":"swim_drive"));
    p.setItemInHand(InteractionHand.MAIN_HAND,drive);c.mobInteract(p,InteractionHand.MAIN_HAND);
    h.assertTrue(drive.isEmpty()&&s.driveCount==0,"Actual offered drive is transferred and considered before benefits commit");
    h.runAtTickTime(140,()->{
      var sample=HeroPowerMorphology067.sample(s);String expected=stat==ChaoState.RUN?"Power/Run":"Power/Swim";
      h.assertTrue(s.driveCount==1&&HeroRunMorphology052.totalTraining(s,stat)==494&&s.typeName().equals(expected),"Real considered drive crosses the current-bar secondary threshold on the correct axis");
      near(h,stat==ChaoState.RUN?sample.runPower():sample.swimFly(),-494f/960,"Held drive reaches the same067 target as other mutation routes");
      h.assertTrue(s.lockedPrimaryType()==ChaoState.POWER_TYPE&&s.lockedAlignment()==1&&s.cocoonTicks==0&&s.secondaryTypes().length==1&&c.getMainHandItem().isEmpty(),"Actual ordinary drive preserves first identity, consumes once and creates no extra cocoon/opposed pair");
      syncAndNbt(h,c);h.succeed();
    });
  }
}
