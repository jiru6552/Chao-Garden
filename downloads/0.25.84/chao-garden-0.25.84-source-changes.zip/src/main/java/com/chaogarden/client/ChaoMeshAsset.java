package com.chaogarden.client;

import com.google.gson.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.io.IOException;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.joml.Vector3f;
import org.joml.Matrix4f;

/** Rigged, low-poly geometry exported from the matching editable Blockbench project. */
final class ChaoMeshAsset {
  static final class Pose {
    float x, y, z, rx, ry, rz, sx = 1, sy = 1, sz = 1;
    float proportionY;
    // Forearm reach in model pixels; hand geometry keeps its authored size.
    float reach;
    boolean visible = true;

    void reset() {
      x = y = z = rx = ry = rz = 0;
      proportionY = reach = 0;
      sx = sy = sz = 1;
      visible = true;
    }
  }

  private record Face(int[] indices, float[][] uv, float[][] gameplayUv,float[][] heroRunUv, Vector3f normal) {}

  private record Mesh(
      String name,
      String material,
      float[][] vertices,
      float[][][] morphVertices,
      float[][][] heroRunVertices,
      float[][][] heroRunLegacyVertices,
      float[][][] pathVertices054,
      BlockyRunBox055 box055,
      BlockyRunBox055 box056,
      boolean compatibleAxes055,
      List<Face> faces,
      Vector3f[] vertexNormals) {}

  private static final class Bone {
    final String name, parent;
    final float[] pivot, rotation;
    float[][] heroRunPivots,heroRunRotations;
    float[][] pathPivots054,pathRotations054;
    float[][] pathPivots055;
    final List<Mesh> meshes;
    final List<Bone> children = new ArrayList<>();

    Bone(String name, String parent, float[] pivot, float[] rotation, List<Mesh> meshes) {
      this.name = name;
      this.parent = parent;
      this.pivot = pivot;
      this.rotation = rotation;
      this.meshes = meshes;
    }
  }

  private final List<Bone> roots;
  private final LinkedHashMap<String, Bone> bones;
  private final float textureWidth, textureHeight;
  private List<String> headDecorations = List.of();
  private List<String> eyeBones = List.of();
  private final Map<String, Float> forwardReaches = new HashMap<>();
  private final float[] developmentWeights = {0,0,0,0,1,0,0,0,0};
  private float developmentStrength=1;
  private final float[] heroRunWeights={1,0,0,0,0,0};
  private boolean heroRunActive,heroRunAdult,heroRunNaturalTwoTone,babyRun053;
  private boolean unified054;
  private boolean blocky055;
  private boolean neutral056,heroNormal057,neutralSwim059,darkNormal060,neutralFly061,neutralRun062,neutralPower063,heroSwim064,heroFly065,heroRun066,heroPower067,darkSwim068,darkFly069,darkRun070,darkPower071;
  private final float[] pathWeights056={1,0,0,0,0,0,0,0,0,0};
  private int pathRevision056;
  private final Map<Mesh,PathFrame054> pathFrames056=new IdentityHashMap<>();
  private final float[] pathWeights055={1,0,0,0,0,0,0};
  private int pathRevision055;
  private final Map<Mesh,PathFrame054> pathFrames055=new IdentityHashMap<>();
  private final Map<Mesh,BlockyRunBox055> babyPowerBoxes084=new IdentityHashMap<>();
  private final float[] babyPowerWeights084={1,0,0,0,0,0,0,0,0,0};
  private float babyPowerGrowth084;
  private float babyPowerTuftRetraction084;
  private final float[] pathWeights054={1,0,0,0,0,0,0};
  private int pathRevision054;
  private static final class PathFrame054 {
    int revision=-1;
    float[][] vertices;
    final Map<Face,Vector3f> normals=new IdentityHashMap<>();
  }
  private final Map<Mesh,PathFrame054> pathFrames054=new IdentityHashMap<>();
  private float heroRunMaturity,heroRunSwimFly,heroRunPower;
  private int lensColor,expression;
  private final Map<String,float[]> uvOverrides=new HashMap<>();
  private final Map<String,float[]> attachmentLandmarks=new HashMap<>();
  private final Map<String,List<String>> attachmentExtraBones=new HashMap<>();
  private float[] activeUvOverride;
  private String naturalHeroCore;
  private float[] naturalHeroCoreUv;
  private boolean naturalHeroCoreActive;
  private float proportionMarkerYoung;
  private float[] proportionMarkerTargets = new float[9];

  private ChaoMeshAsset(float width, float height, LinkedHashMap<String, Bone> bones) {
    textureWidth = width;
    textureHeight = height;
    this.bones = bones;
    eyeBones=bones.values().stream()
        .filter(bone->bone.meshes.stream().anyMatch(mesh->mesh.material.equals("lens")))
        .map(bone->bone.name).toList();
    roots = new ArrayList<>();
    for(Bone bone:bones.values()) {
      var ancestors=new HashSet<String>();
      for(Bone at=bone;at!=null;at=at.parent==null?null:bones.get(at.parent))
        if(!ancestors.add(at.name))throw new IllegalStateException("Cyclic mesh bone "+at.name);
      for(float value:bone.pivot)if(!Float.isFinite(value))throw new IllegalStateException("Non-finite mesh pivot");
      for(float value:bone.rotation)if(!Float.isFinite(value))throw new IllegalStateException("Non-finite mesh rotation");
    }
    for (Bone b : bones.values()) {
      if (b.parent == null || b.parent.isBlank()) roots.add(b);
      else {
        Bone parent = bones.get(b.parent);
        if (parent == null) throw new IllegalStateException("Unknown mesh bone " + b.parent);
        parent.children.add(b);
      }
    }
  }

  static ChaoMeshAsset load(String file) {
    var id =
        ResourceLocation.fromNamespaceAndPath("chao_garden", "models/entity/" + file + ".json");
    try (var reader = Minecraft.getInstance().getResourceManager().openAsReader(id)) {
      var result=parse(JsonParser.parseReader(reader).getAsJsonObject());
      if(result.blocky055) {
        var powerId=ResourceLocation.fromNamespaceAndPath("chao_garden","baby_power084.json");
        try(var powerReader=Minecraft.getInstance().getResourceManager().openAsReader(powerId)) {
          result.babyPowerTargets084(JsonParser.parseReader(powerReader).getAsJsonObject());
        }
      }
      return result;
    } catch (IOException | RuntimeException error) {
      throw new IllegalStateException("Cannot load Chao mesh " + id, error);
    }
  }

  /** A small authored sidecar extends separate baby features, never the skull. */
  void babyPowerTargets084(JsonObject sidecar) {
    if(!blocky055)throw new IllegalStateException("Baby Power targets require the approved fixed-head baby rig");
    var featureBone=bones.get("gradual_head_021");
    if(featureBone==null)throw new IllegalStateException("Missing baby feature attachment");
    for(var entry:sidecar.getAsJsonObject("features").entrySet()) {
      Mesh found=null;
      for(var mesh:featureBone.meshes)if(mesh.name.equals(entry.getKey())){found=mesh;break;}
      if(found==null||found.box055==null)throw new IllegalStateException("Unknown separate baby Power feature: "+entry.getKey());
      babyPowerBoxes084.put(found,found.box055.append(entry.getValue().getAsJsonObject(),3));
    }
    if(babyPowerBoxes084.isEmpty())throw new IllegalStateException("Empty baby Power sidecar");
    babyPowerTuftRetraction084=sidecar.get("legacy_tuft_retraction_y").getAsFloat();
    if(!Float.isFinite(babyPowerTuftRetraction084)||babyPowerTuftRetraction084<0||babyPowerTuftRetraction084>4)
      throw new IllegalStateException("Invalid baby Power decoration retraction");
    pathRevision055++;forwardReaches.clear();
  }

  static ChaoMeshAsset parse(JsonObject data) {
      var bones = new LinkedHashMap<String, Bone>();
      for (JsonElement element : data.getAsJsonArray("bones")) {
        JsonObject bone = element.getAsJsonObject();
        String name = bone.get("name").getAsString();
        String parent =
            !bone.has("parent") || bone.get("parent").isJsonNull()
                ? null
                : bone.get("parent").getAsString();
        float[] pivot = vector(bone.getAsJsonArray("pivot"), 3);
        List<Mesh> meshes = new ArrayList<>();
        if (bone.has("meshes"))
          for (JsonElement me : bone.getAsJsonArray("meshes")) {
            JsonObject mesh = me.getAsJsonObject();
            float[][] vertices = vectors(mesh.getAsJsonArray("vertices"), 3);
            float[][][] morphs=null;
            if(mesh.has("morph_vertices")) {
              var values=mesh.getAsJsonArray("morph_vertices");
              if(values.size()!=9)throw new IllegalStateException("Expected nine development endpoints");
              morphs=new float[9][][];
              for(int target=0;target<9;target++) {
                morphs[target]=vectors(values.get(target).getAsJsonArray(),3);
                if(morphs[target].length!=vertices.length)throw new IllegalStateException("Development topology changed");
                for(float[] point:morphs[target])for(float value:point)
                  if(!Float.isFinite(value))throw new IllegalStateException("Non-finite development vertex");
              }
            }
            float[][][] heroRun=endpointVectors(mesh,"hero_run_vertices_052",5,vertices.length);
            float[][][] heroRunLegacy=endpointVectors(mesh,"hero_run_legacy_vertices_052",9,vertices.length);
            float[][][] path054=endpointVectors(mesh,"morphology_vertices_054",7,vertices.length);
            List<Face> faces = new ArrayList<>();
            for (JsonElement fe : mesh.getAsJsonArray("faces")) {
              JsonObject face = fe.getAsJsonObject();
              JsonArray indices = face.getAsJsonArray("v");
              int[] vi = new int[indices.size()];
              for (int i = 0; i < vi.length; i++) vi[i] = indices.get(i).getAsInt();
              if (vi.length < 3) continue;
              for (int index : vi)
                if (index < 0 || index >= vertices.length)
                  throw new IllegalStateException("Invalid mesh vertex");
              float[][] uv = vectors(face.getAsJsonArray("uv"), 2);
              if (uv.length != vi.length)
                throw new IllegalStateException("Mesh UV/vertex count differs");
              Vector3f a = new Vector3f(vertices[vi[1]]).sub(new Vector3f(vertices[vi[0]]));
              Vector3f b = new Vector3f(vertices[vi[2]]).sub(new Vector3f(vertices[vi[0]]));
              Vector3f normal = a.cross(b);
              if (normal.lengthSquared() < .0000001f) normal.set(0, 0, -1);
              else normal.normalize();
              float[][] gameplayUv=uv;
              if(name.startsWith("emotion_question__")||name.startsWith("emotion_dizzy__")) {
                gameplayUv=new float[uv.length][2];
                for(float[] point:gameplayUv){point[0]=60.5f;point[1]=1.5f;}
              }
              float[][] heroRunUv=face.has("hero_run_uv_052")?vectors(face.getAsJsonArray("hero_run_uv_052"),2):null;
              if(heroRunUv!=null) {
                if(heroRunUv.length!=vi.length)throw new IllegalStateException("Morphology UV/vertex count differs");
                for(var point:heroRunUv)for(float value:point)if(!Float.isFinite(value))throw new IllegalStateException("Non-finite morphology UV");
              }
              faces.add(new Face(vi, uv, gameplayUv,heroRunUv, normal));
            }
            meshes.add(
                new Mesh(
                    mesh.has("name") ? mesh.get("name").getAsString() : name,
                    mesh.has("material") ? mesh.get("material").getAsString() : "body",
                    vertices,
                    morphs,
                    heroRun,heroRunLegacy,path054,
                    mesh.has("blocky_box_055")?BlockyRunBox055.parse(mesh.getAsJsonObject("blocky_box_055"),vertices):null,
                    mesh.has("neutral_box_056")?BlockyRunBox055.parse(mesh.getAsJsonObject("neutral_box_056"),vertices,10)
                        :mesh.has("hero_normal_box_057")?BlockyRunBox055.parse(mesh.getAsJsonObject("hero_normal_box_057"),vertices,10)
                        :mesh.has("neutral_swim_box_059")?BlockyRunBox055.parse(mesh.getAsJsonObject("neutral_swim_box_059"),vertices,10)
                        :mesh.has("dark_normal_box_060")?BlockyRunBox055.parse(mesh.getAsJsonObject("dark_normal_box_060"),vertices,10)
                        :mesh.has("neutral_fly_box_061")?BlockyRunBox055.parse(mesh.getAsJsonObject("neutral_fly_box_061"),vertices,10)
                        :mesh.has("neutral_run_box_062")?BlockyRunBox055.parse(mesh.getAsJsonObject("neutral_run_box_062"),vertices,10)
                        :mesh.has("neutral_power_box_063")?BlockyRunBox055.parse(mesh.getAsJsonObject("neutral_power_box_063"),vertices,10)
                        :mesh.has("hero_swim_box_064")?BlockyRunBox055.parse(mesh.getAsJsonObject("hero_swim_box_064"),vertices,10)
                        :mesh.has("hero_fly_box_065")?BlockyRunBox055.parse(mesh.getAsJsonObject("hero_fly_box_065"),vertices,10)
                        :mesh.has("hero_run_box_066")?BlockyRunBox055.parse(mesh.getAsJsonObject("hero_run_box_066"),vertices,10)
                        :mesh.has("hero_power_box_067")?BlockyRunBox055.parse(mesh.getAsJsonObject("hero_power_box_067"),vertices,10)
                        :mesh.has("dark_swim_box_068")?BlockyRunBox055.parse(mesh.getAsJsonObject("dark_swim_box_068"),vertices,10)
                        :mesh.has("dark_fly_box_069")?BlockyRunBox055.parse(mesh.getAsJsonObject("dark_fly_box_069"),vertices,10)
                        :mesh.has("dark_run_box_070")?BlockyRunBox055.parse(mesh.getAsJsonObject("dark_run_box_070"),vertices,10)
                        :mesh.has("dark_power_box_071")?BlockyRunBox055.parse(mesh.getAsJsonObject("dark_power_box_071"),vertices,10):null,
                    name.startsWith("body__")||name.startsWith("arm_")||name.startsWith("foot_")||name.startsWith("wing_")||name.startsWith("tail__"),
                    List.copyOf(faces),
                    mesh.has("shading") && mesh.get("shading").getAsString().equals("flat")
                        ? null
                        : smoothNormals(vertices, faces)));
          }
        float[] rotation =
            bone.has("rotation") ? vector(bone.getAsJsonArray("rotation"), 3) : new float[3];
        for (int i = 0; i < 3; i++) rotation[i] *= (float) Math.PI / 180f;
        if(bones.put(name, new Bone(name, parent, pivot, rotation, List.copyOf(meshes)))!=null)
          throw new IllegalStateException("Duplicate mesh bone "+name);
      }
      var result = new ChaoMeshAsset(
          data.get("texture_width").getAsFloat(), data.get("texture_height").getAsFloat(), bones);
      if (data.has("head_decorations")) {
        var values = new ArrayList<String>();
        for (var value : data.getAsJsonArray("head_decorations")) values.add(value.getAsString());
        result.headDecorations = List.copyOf(values);
      }
      if(data.has("attachment_landmarks"))for(var entry:data.getAsJsonObject("attachment_landmarks").entrySet()) {
        var values=entry.getValue().getAsJsonArray();float[] landmark=vector(values,values.size());
        for(float value:landmark)if(!Float.isFinite(value))throw new IllegalStateException("Non-finite attachment landmark");
        result.attachmentLandmarks.put(entry.getKey(),landmark);
      }
      result.babyRun053=data.has("baby_run_prototype_053");
      result.unified054=data.has("hero_run_prototype_054");
      result.blocky055=data.has("blocky_run_path_055");
      result.neutral056=data.has("neutral_path_056");
      result.heroNormal057=data.has("hero_normal_path_057");
      result.neutralSwim059=data.has("neutral_swim_path_059");
      result.darkNormal060=data.has("dark_normal_path_060");
      result.neutralFly061=data.has("neutral_fly_path_061");
      result.neutralRun062=data.has("neutral_run_path_062");
      result.neutralPower063=data.has("neutral_power_path_063");
      result.heroSwim064=data.has("hero_swim_path_064");
      result.heroFly065=data.has("hero_fly_path_065");
      result.heroRun066=data.has("hero_run_path_066");
      result.heroPower067=data.has("hero_power_path_067");
      result.darkSwim068=data.has("dark_swim_path_068");
      result.darkFly069=data.has("dark_fly_path_069");
      result.darkRun070=data.has("dark_run_path_070");
      result.darkPower071=data.has("dark_power_path_071");
      if(data.has("attachment_extra_bones"))for(var entry:data.getAsJsonObject("attachment_extra_bones").entrySet()) {
        var extra=new ArrayList<String>();
        for(var value:entry.getValue().getAsJsonArray()) {
          String name=value.getAsString();
          if(!bones.containsKey(name))throw new IllegalStateException("Unknown attachment envelope bone "+name);
          extra.add(name);
        }
        result.attachmentExtraBones.put(entry.getKey(),List.copyOf(extra));
      }
      if(data.has("natural_hero_core")) {
        var special=data.getAsJsonObject("natural_hero_core");result.naturalHeroCore=special.get("bone").getAsString();
        if(!bones.containsKey(result.naturalHeroCore))throw new IllegalStateException("Unknown natural Hero core");
        result.naturalHeroCoreUv=vector(special.getAsJsonArray("uv"),2);
      }
      if(data.has("proportion_adjustment_022")) {
        var adjustment=data.getAsJsonObject("proportion_adjustment_022");
        result.proportionMarkerYoung=adjustment.get("marker_young_delta").getAsFloat();
        var targets=adjustment.getAsJsonArray("marker_target_deltas");
        if(targets.size()!=9)throw new IllegalStateException("Expected nine crown marker offsets");
        for(int i=0;i<9;i++)result.proportionMarkerTargets[i]=targets.get(i).getAsFloat();
        if(!Float.isFinite(result.proportionMarkerYoung))throw new IllegalStateException("Non-finite crown marker offset");
        for(float offset:result.proportionMarkerTargets)if(!Float.isFinite(offset))throw new IllegalStateException("Non-finite crown marker target");
      }
      for(var element:data.getAsJsonArray("bones")) {
        var value=element.getAsJsonObject();var bone=bones.get(value.get("name").getAsString());
        if(value.has("hero_run_pivots_052"))bone.heroRunPivots=endpointVectors(value,"hero_run_pivots_052",5,3,true);
        if(value.has("hero_run_rotations_052")) {
          bone.heroRunRotations=endpointVectors(value,"hero_run_rotations_052",5,3,true);
          for(var target:bone.heroRunRotations)for(int axis=0;axis<3;axis++)target[axis]*=(float)Math.PI/180f;
        }
        if(value.has("morphology_pivots_054"))bone.pathPivots054=endpointVectors(value,"morphology_pivots_054",7,3,true);
        if(value.has("morphology_pivots_055"))bone.pathPivots055=endpointVectors(value,"morphology_pivots_055",7,3,true);
        if(value.has("morphology_rotations_054")) {
          bone.pathRotations054=endpointVectors(value,"morphology_rotations_054",7,3,true);
          for(var target:bone.pathRotations054)for(int axis=0;axis<3;axis++)target[axis]*=(float)Math.PI/180f;
        }
      }
      return result;
  }

  private static float[][][] endpointVectors(JsonObject data,String key,int count,int vertexCount) {
    if(!data.has(key))return null;
    var values=data.getAsJsonArray(key);if(values.size()!=count)throw new IllegalStateException("Invalid morphology endpoint count: "+key);
    float[][][] result=new float[count][][];
    for(int i=0;i<count;i++) {
      result[i]=vectors(values.get(i).getAsJsonArray(),3);
      if(result[i].length!=vertexCount)throw new IllegalStateException("Morphology topology differs: "+key);
      for(var vertex:result[i])for(float coordinate:vertex)if(!Float.isFinite(coordinate))throw new IllegalStateException("Non-finite morphology endpoint");
    }
    return result;
  }
  private static float[][] endpointVectors(JsonObject data,String key,int count,int dimensions,boolean vectors) {
    var values=data.getAsJsonArray(key);if(values.size()!=count)throw new IllegalStateException("Invalid morphology joint endpoints: "+key);
    float[][] result=new float[count][];
    for(int i=0;i<count;i++){result[i]=vector(values.get(i).getAsJsonArray(),dimensions);for(float v:result[i])if(!Float.isFinite(v))throw new IllegalStateException("Non-finite morphology joint");}
    return result;
  }

  private static Vector3f[] smoothNormals(float[][] vertices, List<Face> faces) {
    Vector3f[] normals = new Vector3f[vertices.length];
    for (int i = 0; i < normals.length; i++) normals[i] = new Vector3f();
    for (Face face : faces) {
      Vector3f base = new Vector3f(vertices[face.indices[0]]);
      Vector3f weighted =
          new Vector3f(vertices[face.indices[1]])
              .sub(base)
              .cross(new Vector3f(vertices[face.indices[2]]).sub(base));
      for (int index : face.indices) normals[index].add(weighted);
    }
    for (Vector3f normal : normals) {
      if (normal.lengthSquared() > .00000001f) normal.normalize();
      else normal.set(0, 0, -1);
    }
    return normals;
  }

  private static float[] vector(JsonArray a, int size) {
    float[] out = new float[size];
    for (int i = 0; i < size; i++) out[i] = a.get(i).getAsFloat();
    return out;
  }

  private static float[][] vectors(JsonArray a, int size) {
    float[][] out = new float[a.size()][];
    for (int i = 0; i < a.size(); i++) out[i] = vector(a.get(i).getAsJsonArray(), size);
    return out;
  }


  /** Legacy inspection overload samples the fully aged endpoint lattice. */
  void development(float swimFly,float runPower) { development(swimFly,runPower,1); }

  /** Age and reversible opposing training axes are independent blend dimensions. */
  void development(float swimFly,float runPower,float strength) {
    float sf=Float.isFinite(swimFly)?Math.max(-1,Math.min(1,swimFly)):0;
    float rp=Float.isFinite(runPower)?Math.max(-1,Math.min(1,runPower)):0;
    float age=Float.isFinite(strength)?Math.max(0,Math.min(1,strength)):0;
    boolean changed=developmentStrength!=age;developmentStrength=age;
    for(int y=0;y<3;y++)for(int x=0;x<3;x++) {
      int at=y*3+x;float weight=Math.max(0,1-Math.abs(sf-(y-1)))*Math.max(0,1-Math.abs(rp-(x-1)));
      changed|=developmentWeights[at]!=weight;developmentWeights[at]=weight;
    }
    if(changed)forwardReaches.clear();
  }

  private float coordinate(Mesh mesh,int vertex,int axis) {
    if(neutral056||heroNormal057||neutralSwim059||darkNormal060||neutralFly061||neutralRun062||neutralPower063||heroSwim064||heroFly065||heroRun066||heroPower067||darkSwim068||darkFly069||darkRun070||darkPower071)return pathFrame056(mesh).vertices[vertex][axis];
    if(blocky055)return pathFrame055(mesh).vertices[vertex][axis];
    if(unified054&&heroRunActive&&mesh.pathVertices054!=null)
      return pathFrame054(mesh).vertices[vertex][axis];
    float young=mesh.vertices[vertex][axis],legacy=young;
    if(mesh.morphVertices!=null&&developmentStrength!=0) {
      float aged=0;for(int target=0;target<9;target++)aged+=mesh.morphVertices[target][vertex][axis]*developmentWeights[target];
      legacy=young+(aged-young)*developmentStrength;
    }
    if(!heroRunActive||mesh.heroRunVertices==null)return legacy;
    // The corrected baby owns canonical index-preserving targets.  Blending
    // the old donor-based deformation underneath would reintroduce crossed
    // limbs at intermediate Run values even with a sound maximum endpoint.
    float value=(heroRunAdult||babyRun053?young:legacy)*heroRunWeights[0];
    for(int i=0;i<5;i++)value+=mesh.heroRunVertices[i][vertex][axis]*heroRunWeights[i+1];
    if(heroRunAdult&&mesh.heroRunLegacyVertices!=null) {
      float inherited=0;
      for(int y=0;y<3;y++)for(int x=0;x<3;x++) {
        float w=Math.max(0,1-Math.abs(heroRunSwimFly-(y-1)))*Math.max(0,1-Math.abs(heroRunPower-(x-1)));
        inherited+=mesh.heroRunLegacyVertices[y*3+x][vertex][axis]*w;
      }
      value+=(inherited-mesh.heroRunLegacyVertices[4][vertex][axis])*heroRunMaturity;
    }
    return value;
  }

  /** Cache deformed positions/normals once per weight revision. Rendering,
   * contacts and accessories therefore sample the same actual surface. */
  private PathFrame054 pathFrame054(Mesh mesh) {
    var frame=pathFrames054.computeIfAbsent(mesh,ignored->new PathFrame054());
    if(frame.revision==pathRevision054)return frame;
    if(frame.vertices==null)frame.vertices=new float[mesh.vertices.length][3];
    for(int i=0;i<frame.vertices.length;i++)for(int axis=0;axis<3;axis++) {
      float value=0;
      for(int t=0;t<7;t++)value+=mesh.pathVertices054[t][i][axis]*pathWeights054[t];
      frame.vertices[i][axis]=value;
    }
    for(Face face:mesh.faces) {
      var normal=frame.normals.computeIfAbsent(face,ignored->new Vector3f());
      float[] a=frame.vertices[face.indices[0]];normal.set(0,0,0);
      for(int edge=1;edge<face.indices.length-1;edge++) {
        float[] b=frame.vertices[face.indices[edge]],c=frame.vertices[face.indices[edge+1]];
        float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
        normal.set(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);
        if(normal.lengthSquared()>=1e-18f)break;
      }
      if(normal.lengthSquared()<1e-18f)normal.set(face.normal);else normal.normalize();
    }
    frame.revision=pathRevision054;return frame;
  }

  /** All emitters and attachment samplers share the same rigid-box surface.
   * The canonical skull/face never enter legacy or prototype deformation. */
  private PathFrame054 pathFrame055(Mesh mesh) {
    var frame=pathFrames055.computeIfAbsent(mesh,ignored->new PathFrame054());
    if(frame.revision==pathRevision055)return frame;
    if(frame.vertices==null)frame.vertices=new float[mesh.vertices.length][3];
    var powerBox=babyPowerGrowth084>0?babyPowerBoxes084.get(mesh):null;
    if(powerBox!=null)powerBox.evaluate(babyPowerWeights084,frame.vertices);
    else if(mesh.box055!=null)mesh.box055.evaluate(pathWeights055,frame.vertices);
    else for(int i=0;i<mesh.vertices.length;i++)System.arraycopy(mesh.vertices[i],0,frame.vertices[i],0,3);
    // Preserve compatible Swim/Fly and opposing Power details on the existing
    // body/limb rig only. Bounded deltas keep the approved simple proportions.
    if(heroRunActive&&heroRunAdult&&mesh.compatibleAxes055&&mesh.morphVertices!=null) {
      for(int i=0;i<frame.vertices.length;i++)for(int axis=0;axis<3;axis++) {
        float inherited=0;
        for(int y=0;y<3;y++)for(int x=0;x<3;x++) {
          float weight=Math.max(0,1-Math.abs(heroRunSwimFly-(y-1)))*Math.max(0,1-Math.abs(heroRunPower-(x-1)));
          inherited+=mesh.morphVertices[y*3+x][i][axis]*weight;
        }
        float delta=Math.clamp(inherited-mesh.morphVertices[4][i][axis],-.25f,.25f)*heroRunMaturity;
        frame.vertices[i][axis]+=delta;
      }
    }
    for(Face face:mesh.faces) {
      var normal=frame.normals.computeIfAbsent(face,ignored->new Vector3f());
      float[] a=frame.vertices[face.indices[0]];normal.set(0,0,0);
      for(int edge=1;edge<face.indices.length-1;edge++) {
        float[] b=frame.vertices[face.indices[edge]],c=frame.vertices[face.indices[edge+1]];
        float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
        normal.set(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);
        if(normal.lengthSquared()>=1e-18f)break;
      }
      if(normal.lengthSquared()<1e-18f)normal.set(face.normal);else normal.normalize();
    }
    frame.revision=pathRevision055;return frame;
  }

  /** Ten-target first-type surfaces share the established rigid-box evaluator.
   * Each Neutral/Hero family asset owns its own cache and weight instances. */
  private PathFrame054 pathFrame056(Mesh mesh) {
    var frame=pathFrames056.computeIfAbsent(mesh,ignored->new PathFrame054());
    if(frame.revision==pathRevision056)return frame;
    if(frame.vertices==null)frame.vertices=new float[mesh.vertices.length][3];
    if(mesh.box056!=null)mesh.box056.evaluate(pathWeights056,frame.vertices);
    else for(int i=0;i<mesh.vertices.length;i++)System.arraycopy(mesh.vertices[i],0,frame.vertices[i],0,3);
    for(Face face:mesh.faces) {
      var normal=frame.normals.computeIfAbsent(face,ignored->new Vector3f());
      float[] a=frame.vertices[face.indices[0]];normal.set(0,0,0);
      for(int edge=1;edge<face.indices.length-1;edge++) {
        float[] b=frame.vertices[face.indices[edge]],c=frame.vertices[face.indices[edge+1]];
        float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
        normal.set(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);
        if(normal.lengthSquared()>=1e-18f)break;
      }
      if(normal.lengthSquared()<1e-18f)normal.set(face.normal);else normal.normalize();
    }
    frame.revision=pathRevision056;return frame;
  }

  void neutralDevelopment(com.chaogarden.core.NeutralMorphology056.Sample sample) {
    float[] next=com.chaogarden.core.NeutralMorphology056.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean neutralPrototype056(){return neutral056;}

  void heroNormalDevelopment(com.chaogarden.core.HeroNormalMorphology057.Sample sample) {
    float[] next=com.chaogarden.core.HeroNormalMorphology057.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean heroNormalPrototype057(){return heroNormal057;}

  void neutralSwimDevelopment(com.chaogarden.core.NeutralSwimMorphology059.Sample sample) {
    float[] next=com.chaogarden.core.NeutralSwimMorphology059.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean neutralSwimPrototype059(){return neutralSwim059;}

  void darkNormalDevelopment(com.chaogarden.core.DarkNormalMorphology060.Sample sample) {
    float[] next=com.chaogarden.core.DarkNormalMorphology060.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean darkNormalPrototype060(){return darkNormal060;}

  void neutralFlyDevelopment(com.chaogarden.core.NeutralFlyMorphology061.Sample sample) {
    float[] next=com.chaogarden.core.NeutralFlyMorphology061.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean neutralFlyPrototype061(){return neutralFly061;}

  void neutralRunDevelopment(com.chaogarden.core.NeutralRunMorphology062.Sample sample) {
    float[] next=com.chaogarden.core.NeutralRunMorphology062.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean neutralRunPrototype062(){return neutralRun062;}

  void neutralPowerDevelopment(com.chaogarden.core.NeutralPowerMorphology063.Sample sample) {
    float[] next=com.chaogarden.core.NeutralPowerMorphology063.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean neutralPowerPrototype063(){return neutralPower063;}

  void heroSwimDevelopment(com.chaogarden.core.HeroSwimMorphology064.Sample sample) {
    float[] next=com.chaogarden.core.HeroSwimMorphology064.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean heroSwimPrototype064(){return heroSwim064;}

  void heroFlyDevelopment(com.chaogarden.core.HeroFlyMorphology065.Sample sample) {
    float[] next=com.chaogarden.core.HeroFlyMorphology065.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean heroFlyPrototype065(){return heroFly065;}


  /** Complete adult Run-first family; the approved055 baby path remains separate. */
  void heroRunDevelopment066(com.chaogarden.core.HeroRunMorphology066.Sample sample) {
    float[] next=com.chaogarden.core.HeroRunMorphology066.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean heroRunPrototype066(){return heroRun066;}

  /** Complete Power-first adult family on the retained canonical rig. */
  void heroPowerDevelopment067(com.chaogarden.core.HeroPowerMorphology067.Sample sample) {
    float[] next=com.chaogarden.core.HeroPowerMorphology067.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean heroPowerPrototype067(){return heroPower067;}

  /** Complete Dark/Swim-first adult family on the retained canonical rig. */
  void darkSwimDevelopment068(com.chaogarden.core.DarkSwimMorphology068.Sample sample) {
    float[] next=com.chaogarden.core.DarkSwimMorphology068.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean darkSwimPrototype068(){return darkSwim068;}

  /** Complete Dark/Fly-first adult family on the retained canonical rig. */
  void darkFlyDevelopment069(com.chaogarden.core.DarkFlyMorphology069.Sample sample) {
    float[] next=com.chaogarden.core.DarkFlyMorphology069.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean darkFlyPrototype069(){return darkFly069;}

  /** Complete Dark/Run-first family uses the same rigid-box sampler. */
  void darkRunDevelopment070(com.chaogarden.core.DarkRunMorphology070.Sample sample) {
    float[] next=com.chaogarden.core.DarkRunMorphology070.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean darkRunPrototype070(){return darkRun070;}

  /** Complete Dark/Power-first family uses the retained rigid-box sampler. */
  void darkPowerDevelopment071(com.chaogarden.core.DarkPowerMorphology071.Sample sample) {
    float[] next=com.chaogarden.core.DarkPowerMorphology071.weights(sample);
    if(!Arrays.equals(pathWeights056,next)){pathRevision056++;forwardReaches.clear();}
    System.arraycopy(next,0,pathWeights056,0,next.length);
  }
  boolean darkPowerPrototype071(){return darkPower071;}

  /** One matched surface/joint sampler serves rendering and every attachment. */
  void heroRunDevelopment(com.chaogarden.core.HeroRunMorphology052.Sample sample,float swimFly,float runPower) {
    float[] next=new float[6];boolean enabled=sample!=null&&sample.enabled();
    float[] pathNext=new float[7];
    if(!enabled)pathNext[0]=1;
    else if(sample.adult()) {
      float maturity=Math.clamp(sample.maturity(),0,1),growth=Math.clamp(sample.adultGrowth(),0,maturity);
      pathNext[4]=1-maturity;pathNext[5]=maturity-growth;pathNext[6]=growth;
    } else {
      float hero=Math.clamp(sample.babyHero(),0,1),run=Math.clamp(sample.babyRun(),0,1);
      pathNext[0]=(1-hero)*(1-run);pathNext[1]=hero*(1-run);pathNext[2]=(1-hero)*run;pathNext[3]=hero*run;
    }
    if(!enabled)next[0]=1;
    else if(sample.adult()) {
      float maturity=Math.clamp(sample.maturity(),0,1),growth=Math.clamp(sample.adultGrowth(),0,maturity);
      next[3]=1-maturity;next[4]=maturity-growth;next[5]=growth;
    } else if(babyRun053) {
      float hero=Math.clamp(sample.babyHero(),0,1),run=Math.clamp(sample.babyRun(),0,1);
      // Run anatomy has a complete Neutral endpoint. Alignment is a separate
      // matched corner, not a multiplier which can suppress Run development.
      next[0]=(1-hero)*(1-run);next[1]=hero*(1-run);
      next[2]=(1-hero)*run;next[3]=hero*run;
    } else {
      float hero=Math.clamp(sample.babyHero(),0,1),run=Math.clamp(sample.babyRun(),0,1);
      next[0]=1-hero;next[1]=hero*(1-run);next[3]=hero*run;
    }
    boolean pathChanged=heroRunActive!=enabled||!Arrays.equals(pathWeights054,pathNext);
    boolean changed=pathChanged||heroRunActive!=enabled||heroRunAdult!=(sample!=null&&sample.adult())||!Arrays.equals(heroRunWeights,next)
        ||heroRunSwimFly!=swimFly||heroRunPower!=Math.max(0,runPower);
    heroRunActive=enabled;heroRunAdult=sample!=null&&sample.adult();heroRunMaturity=sample==null?0:sample.maturity();
    heroRunSwimFly=Math.clamp(swimFly,-1,1);heroRunPower=Math.clamp(runPower,0,1);
    if(pathChanged)pathRevision054++;
    System.arraycopy(pathNext,0,pathWeights054,0,7);
    System.arraycopy(next,0,heroRunWeights,0,6);if(changed)forwardReaches.clear();
    float[] boxNext=new float[7];
    if(!enabled)boxNext[0]=1;
    else if(sample.adult()) {
      float maturity=Math.clamp(sample.maturity(),0,1),growth=Math.clamp(sample.adultGrowth(),0,maturity);
      boxNext[4]=1-maturity;boxNext[5]=maturity-growth;boxNext[6]=growth;
    } else {
      float hero=Math.clamp(sample.babyHero(),0,1),run=Math.clamp(sample.babyGrowth(),0,1);
      boxNext[0]=(1-hero)*(1-run);boxNext[1]=hero*(1-run);boxNext[2]=(1-hero)*run;boxNext[3]=hero*run;
    }
    if(changed||!Arrays.equals(pathWeights055,boxNext)){pathRevision055++;forwardReaches.clear();}
    System.arraycopy(boxNext,0,pathWeights055,0,7);
  }
  void heroRunTwoTone(boolean enabled){heroRunNaturalTwoTone=enabled;}
  /** Both emitters and all attachment samplers use these same rigid transforms. */
  void babyPowerDevelopment084(float growth,float alignment) {
    if(!blocky055)return;
    float power=heroRunActive&&!heroRunAdult&&!babyPowerBoxes084.isEmpty()
        &&Float.isFinite(growth)?Math.clamp(growth,0,1):0;
    float signed=Float.isFinite(alignment)?Math.clamp(alignment,-1,1):0;
    float hero=Math.clamp(signed/.5f,0,1),dark=Math.clamp(-signed/.5f,0,1);
    boolean changed=babyPowerGrowth084!=power;
    for(int i=0;i<7;i++) {
      float value=pathWeights055[i]*(1-power);
      changed|=babyPowerWeights084[i]!=value;babyPowerWeights084[i]=value;
    }
    float[] extra={power*(1-hero-dark),power*hero,power*dark};
    for(int i=0;i<3;i++){changed|=babyPowerWeights084[7+i]!=extra[i];babyPowerWeights084[7+i]=extra[i];}
    babyPowerGrowth084=power;
    if(changed){pathRevision055++;forwardReaches.clear();}
  }
  boolean heroRunPrototype(){return blocky055||unified054||bones.values().stream().anyMatch(b->b.heroRunPivots!=null);}
  boolean fixedHeadBox055(){return blocky055||neutral056||heroNormal057||neutralSwim059||darkNormal060||neutralFly061||neutralRun062||neutralPower063||heroSwim064||heroFly065||heroRun066||heroPower067||darkSwim068||darkFly069||darkRun070||darkPower071;}
  private float pivot(Bone bone,int axis){
    float value=blocky055?pathJoint055(bone.pivot,bone.pathPivots055,axis):unified054?pathJoint054(bone.pivot,bone.pathPivots054,axis):jointCoordinate(bone.pivot,bone.heroRunPivots,axis);
    // This mesh-only decoration already retracts for approved Hero/Run. The
    // Power feature surface uses the same continuous hiding mechanism.
    if(blocky055&&axis==1&&bone.name.equals("blocky_legacy_tuft_055")&&babyPowerGrowth084>0)
      value+=(babyPowerTuftRetraction084-value)*babyPowerGrowth084;
    return value;
  }
  private float pathJoint055(float[] base,float[][] targets,int axis) {
    if(targets==null)return base[axis];float value=0;
    for(int i=0;i<7;i++)value+=targets[i][axis]*pathWeights055[i];return value;
  }
  private float rotation(Bone bone,int axis){return unified054?pathJoint054(bone.rotation,bone.pathRotations054,axis):jointCoordinate(bone.rotation,bone.heroRunRotations,axis);}
  private float pathJoint054(float[] base,float[][] targets,int axis) {
    if(!heroRunActive||targets==null)return base[axis];float value=0;
    for(int i=0;i<7;i++)value+=targets[i][axis]*pathWeights054[i];return value;
  }
  private float jointCoordinate(float[] base,float[][] targets,int axis) {
    if(!heroRunActive||targets==null)return base[axis];float value=base[axis]*heroRunWeights[0];
    for(int i=0;i<5;i++)value+=targets[i][axis]*heroRunWeights[i+1];return value;
  }

  void naturalHeroCore(boolean enabled) {
    naturalHeroCoreActive=enabled&&naturalHeroCore!=null;
    if(naturalHeroCore!=null){if(naturalHeroCoreActive)uvOverrides.put(naturalHeroCore,naturalHeroCoreUv);else uvOverrides.remove(naturalHeroCore);}
  }
  boolean naturalHeroCoreActive(){return naturalHeroCoreActive;}

  /** Follows the normalized crown using the same independent age/axis blend. */
  float proportionMarkerOffset() {
    float aged=0;
    for(int i=0;i<9;i++)aged+=proportionMarkerTargets[i]*developmentWeights[i];
    return proportionMarkerYoung+(aged-proportionMarkerYoung)*developmentStrength;
  }

  void lens(int color) { lensColor=color; }
  void expression(int value) { expression=value; }
  void clearUvOverrides(){uvOverrides.clear();}
  void overrideBoneUv(String name,float u,float v){uvOverrides.put(name,new float[]{u,v});}

  /** Development probe fingerprint evaluates the very same vertices as rendering. */
  long shapeSignature() {
    long hash=0xcbf29ce484222325L;
    for(Bone bone:bones.values())for(Mesh mesh:bone.meshes)for(int i=0;i<mesh.vertices.length;i++)
      for(int axis=0;axis<3;axis++) {
        float value=coordinate(mesh,i,axis);
        hash=(hash^Float.floatToIntBits(value))*0x100000001b3L;
      }
    return hash;
  }

  Map<String, Pose> createPoses() {
    Map<String, Pose> out = new LinkedHashMap<>();
    bones.keySet().forEach(n -> out.put(n, new Pose()));
    return out;
  }

  float pivot(String name, int axis) {
    Bone bone = bones.get(name);
    return bone == null ? 0 : pivot(bone,axis);
  }

  /** Authored toe reach in the ankle's local frame, cached for gait fitting. */
  float forwardReach(String name) {
    return forwardReaches.computeIfAbsent(name, key -> {
      Bone bone = bones.get(key);
      if (bone == null) return 0f;
      float[] minimum = {0};
      for (Mesh mesh : bone.meshes)
        for (int i=0;i<mesh.vertices.length;i++)minimum[0]=Math.min(minimum[0],coordinate(mesh,i,2));
      for (Bone child : bone.children) forwardReach(child, new Matrix4f(), minimum);
      return -minimum[0];
    });
  }

  private void forwardReach(Bone bone, Matrix4f parent, float[] minimum) {
    var transform = new Matrix4f(parent).translate(pivot(bone,0), pivot(bone,1), pivot(bone,2))
        .rotateZ(rotation(bone,2)).rotateY(rotation(bone,1)).rotateX(rotation(bone,0));
    var point = new Vector3f();
    for (Mesh mesh : bone.meshes) for (int i=0;i<mesh.vertices.length;i++) {
      transform.transformPosition(coordinate(mesh,i,0),coordinate(mesh,i,1),coordinate(mesh,i,2),point);
      minimum[0] = Math.min(minimum[0], point.z);
    }
    for (Bone child : bone.children) forwardReach(child, transform, minimum);
  }

  void hideHeadDecorations(Map<String,Pose> poses) {
    for (String name : headDecorations) setSubtreeVisible(name, poses, false);
  }

  List<String> headDecorations() { return headDecorations; }

  void setSubtreeVisible(String name, Map<String, Pose> poses, boolean visible) {
    Bone bone = bones.get(name);
    if (bone != null) setSubtreeVisible(bone, poses, visible);
  }

  private static void setSubtreeVisible(Bone bone, Map<String, Pose> poses, boolean visible) {
    poses.get(bone.name).visible = visible;
    for (Bone child : bone.children) setSubtreeVisible(child, poses, visible);
  }

  void render(
      PoseStack stack,
      VertexConsumer consumer,
      int light,
      int overlay,
      int color,
      Map<String, Pose> poses) {
    render(stack,consumer,light,overlay,color,poses,false);
  }

  void render(PoseStack stack,VertexConsumer consumer,int light,int overlay,int color,
              Map<String,Pose> poses,boolean gameplayUv) {
    Vector3f normal=new Vector3f(),vertex=new Vector3f();
    for(Bone root:roots)renderBone(root,stack,consumer,light,overlay,color,poses,normal,vertex,gameplayUv);
  }

  /** Apply an attachment's complete ancestor chain using the same transforms as rendering. */
  void transformBone(String name, PoseStack stack, Map<String,Pose> poses) {
    Bone bone=bones.get(name);
    if(bone==null)return;
    var chain=new ArrayDeque<Bone>();
    for(Bone at=bone;at!=null;at=at.parent==null?null:bones.get(at.parent))chain.push(at);
    while(!chain.isEmpty())applyTransform(chain.pop(),stack,poses);
  }

  /** Copy a sampled joint to a separate attachment rig without losing its
   * morphed bind pose. Procedural fields stay relative to the target bind pose. */
  void copyJointPoseTo(String name,ChaoMeshAsset target,Pose from,Pose to) {
    to.x=from.x;to.y=from.y;to.z=from.z;to.rx=from.rx;to.ry=from.ry;to.rz=from.rz;
    to.sx=from.sx;to.sy=from.sy;to.sz=from.sz;to.reach=from.reach;to.visible=true;
    if(!heroRunActive||!heroRunPrototype())return;
    Bone source=bones.get(name),destination=target.bones.get(name);
    if(source==null||destination==null)return;
    to.x+=pivot(source,0)-target.pivot(destination,0);
    to.y+=pivot(source,1)-target.pivot(destination,1);
    to.z+=pivot(source,2)-target.pivot(destination,2);
    to.rx+=rotation(source,0)-target.rotation(destination,0);
    to.ry+=rotation(source,1)-target.rotation(destination,1);
    to.rz+=rotation(source,2)-target.rotation(destination,2);
  }

  /** Actual deformed palm, including the hand cube's local transform; arm-local pixels. */
  float[] rattlePalm(Map<String,Pose> poses) { return toyPalm(poses,false); }
  float[] toyPalm(Map<String,Pose> poses,boolean left) {
    String name=left?"arm_left":"arm_right";
    Bone arm=bones.get(name), hand=bones.get(name+"__cube_1");
    if(arm==null||hand==null||!poses.get(arm.name).visible||!poses.get(hand.name).visible)return null;
    float[] bounds=localBounds(hand,arm,poses);
    if(bounds==null) {
      // Authored Chaos forms end at the visible arm; their old hand node is
      // intentionally empty. Place the grip inside that actual distal tip.
      Bone tip=bones.get(name+"__cube_0");
      if(tip==null||!poses.get(tip.name).visible)return null;
      bounds=localBounds(tip,arm,poses);if(bounds==null)return null;
      float inset=Math.min(.25f,(bounds[3]-bounds[0])*.15f);
      return new float[]{left?bounds[3]-inset:bounds[0]+inset,
          (bounds[1]+bounds[4])*.5f,(bounds[2]+bounds[5])*.5f};
    }
    return new float[]{(bounds[0]+bounds[3])*.5f,(bounds[1]+bounds[4])*.5f,(bounds[2]+bounds[5])*.5f};
  }

  /** Measured visible hand when a terminal material layer supplies it. */
  float[] visiblePalm(Map<String,Pose> poses,boolean left) {
    String name=left?"arm_left":"arm_right";Bone hand=bones.get("chaos_hand_"+name),arm=bones.get(name);
    float[] b=hand==null||arm==null?null:localBounds(hand,arm,poses);
    return b==null?toyPalm(poses,left):new float[]{(b[0]+b[3])*.5f,(b[1]+b[4])*.5f,(b[2]+b[5])*.5f};
  }
  float[] visibleHandBounds(Map<String,Pose> poses,boolean left) {
    String name=left?"arm_left":"arm_right";Bone hand=bones.get("chaos_hand_"+name),arm=bones.get(name);
    float[] b=hand==null||arm==null?null:localBounds(hand,arm,poses);
    return b==null?toyHandBounds(poses,left):b;
  }

  /** Rendered palm volume in the arm's local space, for attachment fitting and QA. */
  float[] toyHandBounds(Map<String,Pose> poses,boolean left){
    String name=left?"arm_left":"arm_right";Bone arm=bones.get(name),hand=bones.get(name+"__cube_1");
    if(arm==null||hand==null)return null;float[] bounds=localBounds(hand,arm,poses);
    return bounds!=null?bounds:localBounds(bones.get(name+"__cube_0"),arm,poses);
  }
  float[] animalHandBounds(int animal,Map<String,Pose> poses,boolean left){
    String side=left?"left":"right";Bone hand=bones.get("animal_0_"+animal+"_"+side),arm=bones.get("arm_"+side);
    return hand==null||arm==null?null:localBounds(hand,arm,poses,null,Set.of("gene_hand","paw","hoof","claw"));
  }

  /** Replacement hand centre in the same arm-local space as the skin socket. */
  float[] animalPalm(int animal,Map<String,Pose> poses) { return animalPalm(animal,poses,false); }
  float[] animalPalm(int animal,Map<String,Pose> poses,boolean left) {
    String side=left?"left":"right";
    Bone hand=bones.get("animal_0_"+animal+"_"+side),arm=bones.get("arm_"+side);
    if(hand==null||arm==null||!poses.get(hand.name).visible)return null;
    float[] bounds=localBounds(hand,arm,poses,null,Set.of("gene_hand","paw","hoof","claw"));
    return bounds==null?null:new float[]{(bounds[0]+bounds[3])*.5f,(bounds[1]+bounds[4])*.5f,(bounds[2]+bounds[5])*.5f};
  }

  /** Complete visible geometry below a joint, including authored Chaos feet. */
  float[] partBounds(String anchor,Map<String,Pose> poses) {
    Bone joint=bones.get(anchor);if(joint==null)return null;float[] result=null;
    for(Bone bone:bones.values()) {
      boolean belongs=false,visible=true;
      for(Bone at=bone;at!=null;at=at.parent==null?null:bones.get(at.parent)) {
        if(!poses.get(at.name).visible)visible=false;
        if(at==joint){belongs=true;break;}
      }
      if(!belongs||!visible)continue;
      float[] b=localBounds(bone,joint,poses,null);if(b==null)continue;
      if(result==null)result=b;else for(int a=0;a<3;a++){result[a]=Math.min(result[a],b[a]);result[a+3]=Math.max(result[a+3],b[a+3]);}
    }
    return result;
  }

  /** Current skin bounds in the requested joint's local pixels, not model/world coordinates. */
  float[] attachmentBounds(String anchor,Map<String,Pose> poses) {
    Bone joint=bones.get(anchor);if(joint==null)return null;
    Bone core=null;double largest=-1;
    for(Bone candidate:bones.values()) {
      if(!candidate.name.startsWith(anchor+"__cube_"))continue;
      // Sleeves cover the upper arm, never the larger hand at cube1.
      if(anchor.startsWith("arm_")&&!candidate.name.equals(anchor+"__cube_0"))continue;
      float[] bounds=localBounds(candidate,joint,poses);
      if(bounds==null)continue;
      double volume=(bounds[3]-bounds[0])*(bounds[4]-bounds[1])*(bounds[5]-bounds[2]);
      if(volume>largest){largest=volume;core=candidate;}
    }
    float[] bounds=core==null?null:localBounds(core,joint,poses);
    for(String name:attachmentExtraBones.getOrDefault(anchor,List.of())) {
      if(babyRun053||unified054) {
        Pose extraPose=poses.get(name);
        if(extraPose!=null&&!extraPose.visible)continue;
      }
      float[] extra=localBounds(bones.get(name),joint,poses);if(extra==null)continue;
      if(bounds==null)bounds=extra;
      else for(int axis=0;axis<3;axis++) {
        bounds[axis]=Math.min(bounds[axis],extra[axis]);bounds[axis+3]=Math.max(bounds[axis+3],extra[axis+3]);
      }
    }
    return bounds;
  }

  /** Mouth centre measured from this form's actual expression geometry. */
  float[] attachmentMouth(Map<String,Pose> poses) {
    Bone skull=bones.get("skull");if(skull==null)return null;
    for(String name:List.of("expression_mouth_6","expression_mouth_1","character_robot_mouth")) {
      Bone mouth=bones.get(name);if(mouth==null)continue;
      float[] b=localBounds(mouth,skull,poses);
      if(b!=null)return new float[]{(b[0]+b[3])*.5f,(b[1]+b[4])*.5f,b[2]};
    }
    // Chaos forms have no separate mouth mesh; use their authored face plane.
    float[] eyes=attachmentEyes(poses);
    return eyes==null?null:new float[]{eyes[0],eyes[1]+1.6f,eyes[2]-.15f};
  }

  /** Eye centre, front plane and half-spacing in skull-local pixels. */
  void eyesVisible(Map<String,Pose> poses,boolean visible) {
    for(String name:eyeBones)setSubtreeVisible(name,poses,visible);
  }

  /** Eye centre, front plane and half-spacing in skull-local pixels. */
  float[] attachmentEyes(Map<String,Pose> poses) {
    var authored=attachmentLandmarks.get("eyes");
    if(authored!=null&&authored.length==4)return authored.clone();
    Bone joint=bones.get("skull");if(joint==null)return null;
    var eyes=new ArrayList<float[]>();
    for(Bone bone:bones.values()) {
      if(bone.meshes.stream().noneMatch(mesh->mesh.material.equals("lens")))continue;
      float[] bounds=localBounds(bone,joint,poses,"lens");if(bounds!=null)eyes.add(bounds);
    }
    if(eyes.isEmpty())return null;
    float x=0,y=0,z=Float.POSITIVE_INFINITY;
    for(float[] bounds:eyes){x+=(bounds[0]+bounds[3])*.5f;y+=(bounds[1]+bounds[4])*.5f;z=Math.min(z,bounds[2]);}
    x/=eyes.size();y/=eyes.size();float half=0;
    for(float[] bounds:eyes)half+=Math.abs((bounds[0]+bounds[3])*.5f-x);
    return new float[]{x,y,z,half/eyes.size()};
  }

  private float[] localBounds(Bone core,Bone joint,Map<String,Pose> poses) {
    return localBounds(core,joint,poses,null);
  }

  private float[] localBounds(Bone core,Bone joint,Map<String,Pose> poses,String material) {
    return localBounds(core,joint,poses,material,null);
  }

  private float[] localBounds(Bone core,Bone joint,Map<String,Pose> poses,String material,Set<String> meshNames) {
    var chain=new ArrayDeque<Bone>();
    for(Bone at=core;at!=joint;at=at.parent==null?null:bones.get(at.parent)) {
      if(at==null)return null;chain.push(at);
    }
    Matrix4f matrix=new Matrix4f();
    while(!chain.isEmpty()) {
      Bone bone=chain.pop();Pose p=poses.get(bone.name);if(p==null)p=new Pose();
      matrix.translate(pivot(bone,0)+p.x,pivot(bone,1)+p.y,pivot(bone,2)+p.z)
          .rotateZ(rotation(bone,2)+p.rz).rotateY(rotation(bone,1)+p.ry).rotateX(rotation(bone,0)+p.rx)
          .scale(p.sx,p.sy,p.sz);
    }
    float[] bounds={Float.POSITIVE_INFINITY,Float.POSITIVE_INFINITY,Float.POSITIVE_INFINITY,
        Float.NEGATIVE_INFINITY,Float.NEGATIVE_INFINITY,Float.NEGATIVE_INFINITY};
    boolean any=false;Vector3f point=new Vector3f();
    for(Mesh mesh:core.meshes) {
      if(material!=null&&!mesh.material.equals(material))continue;
      if(meshNames!=null&&!meshNames.contains(mesh.name))continue;
      Matrix4f fitted=new Matrix4f(matrix);
      Matrix4f reach=armReachTransform(core,mesh,poses);if(reach!=null)fitted.mul(reach);
      for(int i=0;i<mesh.vertices.length;i++) {
      float x=coordinate(mesh,i,0),y=coordinate(mesh,i,1),z=coordinate(mesh,i,2);
      fitted.transformPosition(x,y,z,point);any=true;
      for(int axis=0;axis<3;axis++) {
        float value=axis==0?point.x:axis==1?point.y:point.z;
        bounds[axis]=Math.min(bounds[axis],value);bounds[axis+3]=Math.max(bounds[axis+3],value);
      }
    }
    }
    return any?bounds:null;
  }

  /** Extend only the forearm; move the separate palm without changing its shape. */
  private Matrix4f armReachTransform(Bone bone,Mesh mesh,Map<String,Pose> poses) {
    Bone arm=bone;var chain=new ArrayDeque<Bone>();
    while(arm!=null&&!arm.name.equals("arm_left")&&!arm.name.equals("arm_right")) {
      chain.push(arm);arm=arm.parent==null?null:bones.get(arm.parent);
    }
    if(arm==null||poses.get(arm.name).reach<=0)return null;
    boolean hand=bone.name.equals(arm.name+"__cube_1")||bone.name.equals("chaos_hand_"+arm.name)||Set.of("gene_hand","paw","hoof","claw").contains(mesh.name);
    boolean forearm=bone.name.equals(arm.name+"__cube_0")||mesh.name.equals("gene_arm_connector")||mesh.name.equals("arm");
    if(!hand&&!forearm)return null;
    Matrix4f toArm=new Matrix4f();
    while(!chain.isEmpty()) {
      Bone at=chain.pop();Pose p=poses.get(at.name);
      toArm.translate(pivot(at,0)+p.x,pivot(at,1)+p.y,pivot(at,2)+p.z)
          .rotateZ(rotation(at,2)+p.rz).rotateY(rotation(at,1)+p.ry).rotateX(rotation(at,0)+p.rx).scale(p.sx,p.sy,p.sz);
    }
    float reach=poses.get(arm.name).reach;Matrix4f stretch=new Matrix4f();
    if(hand)stretch.translate(arm.name.equals("arm_left")?reach:-reach,0,0);
    else {
      float end=0;Vector3f v=new Vector3f();
      for(int i=0;i<mesh.vertices.length;i++) {toArm.transformPosition(coordinate(mesh,i,0),coordinate(mesh,i,1),coordinate(mesh,i,2),v);end=Math.max(end,Math.abs(v.x));}
      if(end<.01f)return null;stretch.scale(1+reach/end,1,1);
    }
    return new Matrix4f(toArm).invert().mul(stretch).mul(toArm);
  }

  private void applyTransform(Bone bone,PoseStack stack,Map<String,Pose> poses) {
    Pose p=poses.get(bone.name);
    stack.translate((pivot(bone,0)+p.x)/16f,(pivot(bone,1)+p.y)/16f,(pivot(bone,2)+p.z)/16f);
    float rz=p.rz+rotation(bone,2),ry=p.ry+rotation(bone,1),rx=p.rx+rotation(bone,0);
    if(rz!=0)stack.mulPose(Axis.ZP.rotation(rz));
    if(ry!=0)stack.mulPose(Axis.YP.rotation(ry));
    if(rx!=0)stack.mulPose(Axis.XP.rotation(rx));
    if(p.sx!=1||p.sy!=1||p.sz!=1)stack.scale(p.sx,p.sy,p.sz);
  }

  private void renderBone(
      Bone bone,
      PoseStack stack,
      VertexConsumer consumer,
      int light,
      int overlay,
      int color,
      Map<String, Pose> poses,
      Vector3f normal,
      Vector3f vertex,
      boolean gameplayUv) {
    Pose p = poses.get(bone.name);
    if ((!p.visible && bone.children.isEmpty()) || p.sx == 0 || p.sy == 0 || p.sz == 0) return;
    stack.pushPose();
    applyTransform(bone,stack,poses);
    if (p.visible) {
      for (Mesh mesh : bone.meshes) {
        activeUvOverride=uvOverrides.get(bone.name);
        if(mesh.material.equals("lens") && lensColor==0)continue;
        if(mesh.material.startsWith("expression_") && !mesh.material.equals("expression_"+expression))continue;
        stack.pushPose();
        Matrix4f reach=armReachTransform(bone,mesh,poses);
        if(reach!=null){reach.m30(reach.m30()/16).m31(reach.m31()/16).m32(reach.m32()/16);stack.mulPose(reach);}
        var matrix=stack.last();
        int meshColor=mesh.material.equals("lens")?lensColor:color;
        int meshLight = isLuminous(mesh.material) ? 0x00f000f0 : light;
        for (Face face : mesh.faces) {
          if(neutral056||heroNormal057||neutralSwim059||darkNormal060||neutralFly061||neutralRun062||neutralPower063||heroSwim064||heroFly065||heroRun066||heroPower067||darkSwim068||darkFly069||darkRun070||darkPower071) {
            matrix.transformNormal(pathFrame056(mesh).normals.get(face),normal);
          } else if(blocky055) {
            matrix.transformNormal(pathFrame055(mesh).normals.get(face),normal);
          } else if(unified054&&heroRunActive&&mesh.pathVertices054!=null) {
            matrix.transformNormal(pathFrame054(mesh).normals.get(face),normal);
          } else if(heroRunActive&&(mesh.name.equals("source_informed_rear_point")||mesh.name.equals("closed_swept_quill"))) {
            int a=face.indices[0],b=face.indices[1],c=face.indices[2];
            var edge=new Vector3f(coordinate(mesh,b,0)-coordinate(mesh,a,0),coordinate(mesh,b,1)-coordinate(mesh,a,1),coordinate(mesh,b,2)-coordinate(mesh,a,2));
            var next=new Vector3f(coordinate(mesh,c,0)-coordinate(mesh,a,0),coordinate(mesh,c,1)-coordinate(mesh,a,1),coordinate(mesh,c,2)-coordinate(mesh,a,2));
            edge.cross(next);if(edge.lengthSquared()<.00000001f)edge.set(face.normal);else edge.normalize();
            matrix.transformNormal(edge,normal);
          }else matrix.transformNormal(face.normal, normal);
          // Minecraft entity buffers use quads. A repeated last vertex encodes a triangle.
          if (face.indices.length <= 4)
            emitFace(
                face,
                mesh,
                0,
                1,
                2,
                face.indices.length == 4 ? 3 : 2,
                matrix,
                consumer,
                meshLight,
                overlay,
                meshColor,
                normal,
                vertex,
                gameplayUv);
          else
            for (int i = 1; i < face.indices.length - 1; i++)
              emitFace(
                  face, mesh, 0, i, i + 1, i + 1, matrix, consumer, meshLight, overlay, meshColor,
                  normal, vertex, gameplayUv);
        }
        stack.popPose();
      }
    }
    // A replacement limb can remain visible when its parent's base mesh is hidden.
    for (Bone child : bone.children)
      renderBone(child, stack, consumer, light, overlay, color, poses, normal, vertex, gameplayUv);
    stack.popPose();
  }

  private static boolean isLuminous(String material) {
    return material.equals("orb")
        || material.equals("halo")
        || material.equals("dark_orb")
        || material.equals("heart")
        || material.equals("flame");
  }

  private void emitFace(
      Face face,
      Mesh mesh,
      int a,
      int b,
      int c,
      int d,
      PoseStack.Pose pose,
      VertexConsumer consumer,
      int light,
      int overlay,
      int color,
      Vector3f normal,
      Vector3f vertex,
      boolean gameplayUv) {
    emitVertex(face, mesh, a, pose, consumer, light, overlay, color, normal, vertex, gameplayUv);
    emitVertex(face, mesh, b, pose, consumer, light, overlay, color, normal, vertex, gameplayUv);
    emitVertex(face, mesh, c, pose, consumer, light, overlay, color, normal, vertex, gameplayUv);
    emitVertex(face, mesh, d, pose, consumer, light, overlay, color, normal, vertex, gameplayUv);
  }

  private void emitVertex(
      Face face,
      Mesh mesh,
      int index,
      PoseStack.Pose pose,
      VertexConsumer consumer,
      int light,
      int overlay,
      int color,
      Vector3f normal,
      Vector3f vertex,
      boolean gameplayUv) {
    float[] v = mesh.vertices[face.indices[index]];
    if (mesh.vertexNormals != null&&!blocky055&&!neutral056&&!heroNormal057&&!neutralSwim059&&!darkNormal060&&!neutralFly061&&!neutralRun062&&!neutralPower063&&!heroSwim064&&!heroFly065&&!heroRun066&&!heroPower067&&!darkSwim068&&!darkFly069&&!darkRun070&&!darkPower071&&!(unified054&&heroRunActive&&mesh.pathVertices054!=null))
      pose.transformNormal(mesh.vertexNormals[face.indices[index]], normal);
    int at=face.indices[index];
    pose.pose().transformPosition(coordinate(mesh,at,0)/16f,coordinate(mesh,at,1)/16f,coordinate(mesh,at,2)/16f,vertex);
    float[] uv = activeUvOverride!=null?activeUvOverride:heroRunActive&&heroRunNaturalTwoTone&&face.heroRunUv!=null?face.heroRunUv[index]:(gameplayUv?face.gameplayUv:face.uv)[index];
    consumer.addVertex(
        vertex.x,
        vertex.y,
        vertex.z,
        color,
        uv[0] / textureWidth,
        uv[1] / textureHeight,
        overlay,
        light,
        normal.x,
        normal.y,
        normal.z);
  }
}
