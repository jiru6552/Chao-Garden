#!/usr/bin/env python3
"""Apply the explicit source-file deletions after extracting this overlay.

This edits source files only. It does not inspect or modify Minecraft saves.
Modified files are refused rather than deleting local customizations silently.
"""
from pathlib import Path
import argparse,hashlib,json
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('project_root',type=Path,help='The full Chao Garden source project')
parser.add_argument('--verify-only',action='store_true')
args=parser.parse_args();root=args.project_root.resolve()
if not (root/'gradle.properties').is_file() or not (root/'src/main').is_dir():
    raise SystemExit('This is not a full Chao Garden source project')
manifest=json.loads(Path(__file__).with_name('SOURCE_MANIFEST.json').read_text())
pending=[]
for name in manifest['deleted_files']:
    rel=Path(name)
    if rel.is_absolute() or '..' in rel.parts:raise SystemExit('Unsafe deletion path: '+name)
    path=root/rel
    if path.is_symlink() or root not in path.resolve().parents:raise SystemExit('Unsafe source symlink: '+name)
    if not path.exists():continue
    if not path.is_file():raise SystemExit('Refusing to remove a directory: '+name)
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual not in manifest['deleted_file_previous_sha256'][name]:
        raise SystemExit('Source has local edits; review this deletion manually: '+name)
    pending.append(path)
for path in pending:
    print(('Would remove ' if args.verify_only else 'Removing ')+str(path.relative_to(root)))
    if not args.verify_only:path.unlink()
print('Verified' if args.verify_only else 'Applied',len(pending),'explicit source deletions')
